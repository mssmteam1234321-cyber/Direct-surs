//
// Created by vastrakai on 7/12/2024.
//

#pragma once

#include "JSON.hpp"
#include <SDK/Minecraft/Network/Packets/ModalFormResponsePacket.hpp>
