//
// Created by vastrakai on 7/3/2024.
//

#pragma once



struct BlockMovementSlowdownMultiplierComponent {
    glm::vec3 mBlockMovementSlowdownMultiplier;
};