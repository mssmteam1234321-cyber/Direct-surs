//
// Created by vastrakai on 7/22/2024.
//

#pragma once

class CameraPresetComponent {
public:
    int mCameraPreset;
};