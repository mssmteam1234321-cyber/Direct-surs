//
// Created by vastrakai on 11/10/2024.
//

#pragma once

struct ItemUseSlowdownModifierComponent {
    float mMultiplier = 1.0f;
};