//
// Created by vastrakai on 6/28/2024.
//

#pragma once

class ActorOwnerComponent
{
public:
    class Actor* mActor;
};