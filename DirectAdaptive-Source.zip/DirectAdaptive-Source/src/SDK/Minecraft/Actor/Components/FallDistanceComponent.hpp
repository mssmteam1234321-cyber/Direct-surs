//
// Created by vastrakai on 7/11/2024.
//

#pragma once

struct FallDistanceComponent
{
    float mFallDistance;
};
