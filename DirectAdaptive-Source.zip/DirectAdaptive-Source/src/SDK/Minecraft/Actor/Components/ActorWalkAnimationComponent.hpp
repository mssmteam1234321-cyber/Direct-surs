//
// Created by vastrakai on 7/23/2024.
//

#pragma once
// idfk if this is even correct lol i dont care either
struct ActorWalkAnimationComponent {
    float mWalkAnimSpeed;
    float mSwing;
    float mSwingOld;
    float mSwingAmount;
};