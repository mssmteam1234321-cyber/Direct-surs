//
// Created by vastrakai on 7/6/2024.
//

#pragma once

struct ActorEquipmentComponent {
    class SimpleContainer* mOffhandContainer;
    class SimpleContainer* mArmorContainer;
};