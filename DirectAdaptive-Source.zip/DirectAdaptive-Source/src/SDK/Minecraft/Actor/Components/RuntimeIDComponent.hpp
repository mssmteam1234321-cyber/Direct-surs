//
// Created by vastrakai on 6/28/2024.
//

#pragma once


#include <cstdint>

struct RuntimeIDComponent {
    int64_t mRuntimeID;
};
