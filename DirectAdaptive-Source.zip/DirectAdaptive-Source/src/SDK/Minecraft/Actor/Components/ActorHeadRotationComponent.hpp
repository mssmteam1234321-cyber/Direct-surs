//
// Created by vastrakai on 7/8/2024.
//

#pragma once

struct ActorHeadRotationComponent {
    float mHeadRot;
    float mOldHeadRot;
};