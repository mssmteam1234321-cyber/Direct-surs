//
// Created by vastrakai on 8/4/2024.
//

#pragma once

struct MobHurtTimeComponent
{
    int mHurtTime;
};