//
// Created by vastrakai on 7/7/2024.
//

#pragma once


struct RenderPositionComponent {
    glm::vec3 mPosition;
};