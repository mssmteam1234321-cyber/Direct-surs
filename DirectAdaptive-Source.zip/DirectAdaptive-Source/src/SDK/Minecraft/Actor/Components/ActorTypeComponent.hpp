//
// Created by vastrakai on 6/28/2024.
//

#pragma once

#include <SDK/Minecraft/Actor/ActorType.hpp>

struct ActorTypeComponent
{
    ActorType mType;
};