//
// Created by vastrakai on 8/3/2024.
//

#pragma once

struct MaxAutoStepComponent {
    float mMaxStepHeight;
};