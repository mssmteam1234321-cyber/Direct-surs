//
// Created by vastrakai on 7/8/2024.
//

#pragma once
#include <cstdint>

struct ActorUniqueIDComponent {
    uint64_t mUniqueID;
};