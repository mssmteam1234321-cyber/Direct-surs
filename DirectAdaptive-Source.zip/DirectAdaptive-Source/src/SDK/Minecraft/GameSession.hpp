#pragma once
//
// Created by vastrakai on 6/25/2024.
//


class GameSession {
public:
    void* getEventCallback();
};