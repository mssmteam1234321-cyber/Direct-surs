#pragma once
#include <vector>
#include <string>
#include <unordered_map>
#include <d3d11.h>
#include <glm/vec2.hpp>
#include <Features/Events/WindowResizeEvent.hpp>
#include <imgui.h>
#include <Features/FeatureManager.hpp>
#include <Features/Modules/Setting.hpp>
#include <thread>
#include <mutex>
#include <atomic>
#include <chrono>
#include <cmath>

// Simple theme system
// Monoton Theme Colors


class Module;
class MultiBindSetting;

class ModernGui
{
public:
    struct CategoryPosition
    {
        float x = 0.f, y = 0.f;
        bool isDragging = false, isExtended = true, wasExtended = false;
        float yOffset = 0;
        float scrollEase = 0;
        float openAnimProgress = 1.0f;
        float backgroundHeight = 0.f;

        glm::vec2 dragVelocity = glm::vec2(0, 0);
        glm::vec2 dragAcceleration = glm::vec2(0, 0);
        bool isDraggingScrollbar = false;
        float dragStartY = 0.0f;
        float scrollStartValue = 0.0f;
    };

    //                                        
    struct FallingLeaf {
        float x, y;           // Позиция
        float velocityX, velocityY; // Скорость
        float rotation;       // Угол поворота
        float rotationSpeed;  // Скорость вращения
        float scale;          // Размер
        float alpha;          // Прозрачность
        float swayAmplitude;  // Амплитуда покачивания
        float swayPhase;      // Фаза покачивания
        float swaySpeed;      // Скорость покачивания
        ImColor color;        // Цвет листа
        int leafType;         // Тип листа (для разных текстур)
    };

    struct PerformanceCache {
        std::unordered_map<std::string, ID3D11ShaderResourceView*> textureCache;
        std::unordered_map<std::string, std::pair<int, int>> textureDimensions;
        std::unordered_map<Module*, float> arrowAnims;
        std::unordered_map<Module*, float> moduleColorAnims;
        std::unordered_map<int, std::vector<std::shared_ptr<Module>>> sortedModsCache;
        std::unordered_map<int, std::vector<std::shared_ptr<Module>>> filteredModsCache;
        std::unordered_map<Module*, float> settingsHeightCache;
        std::vector<std::shared_ptr<Module>>* modulesCache = nullptr;
        bool modulesCacheValid = false;
        bool lowercaseCacheValid = false;
        bool cachedLowercase = false;
        std::string lastSearchStr;
        bool cacheInitialized = false;
        std::unordered_map<Module*, std::string> lowerNames;
        std::unordered_map<Setting*, std::string> lowerSettingNames;
        std::unordered_map<EnumSetting*, std::vector<std::string>> lowerEnumValues;
    };

    struct AsyncFilterState {
        std::thread worker;
        std::mutex mtx;
        std::atomic<bool> stop{ false };
        bool running = false;
        bool inputDirty = false;
        std::string inputSearch;
        bool hasOutput = false;
        std::string outputSearch;
        std::unordered_map<int, std::vector<std::shared_ptr<Module>>> filteredOutput;
    };

    const float catWidth = 250.f;
    const float catHeight = 30.f;
    const float catTotalHeight = 600.f;
    const float catGap = 5.f;
    const float moduleGap = 6.f;
    const float maxCategoryHeight = 700.f;

    const float moduleWidth = 310.f;
    const float moduleHeight = 42.f;
    const float modulePadding = 8.f;

    const float innerWidth = 230.f;
    const float innerHeight = 550.f;

    int lastDragged = -1;
    std::vector<CategoryPosition> catPositions;
    std::shared_ptr<Module> lastMod = nullptr;
    bool isBinding = false;
    bool isBoolSettingBinding = false;
    bool isMultiBindSettingBinding = false;
    BoolSetting* lastBoolSetting = nullptr;
    MultiBindSetting* lastMultiBindSetting = nullptr;
    std::string lastMultiBindItemName = "";
    ColorSetting* lastColorSetting = nullptr;
    bool displayConfigsMenu = false;
    bool displaySpooferMenu = false;
    bool displayIRCMenu = false;
    bool displayColorPicker = false;
    char configNameBuffer[64] = "";
    bool resetPosition = false;
    uint64_t lastReset = 0;
    PerformanceCache perfCache;
    AsyncFilterState asyncFilter;

    std::vector<FallingLeaf> fallingLeaves;
    bool leavesInitialized = false;
    static const int MAX_LEAVES = 55;
    float leafSpawnTimer = 0.0f;

    // IRC Chat structures
    struct IRCMessage {
        std::string sender;
        std::string text;
        uint64_t timestamp;
        bool isOwn;
    };

    struct IRCDialog {
        std::string title;
        bool isGroup;
        std::vector<IRCMessage> messages;
    };

    std::vector<IRCMessage> globalChatMessages;
    std::vector<IRCMessage> friendsChatMessages;
    std::vector<IRCDialog> ircDialogs;
    int selectedIrcDialog = 0;
    char ircMessageBuffer[256] = "";
    int currentIRCTab = 0; // 0 = Friends, 1 = Global, 2 = Settings
    std::string ircBackgroundTexture = "default";
    bool ircConnected = false;
    std::string currentRoom = "global";

    struct Snowflake {
        float x, y;
        float vx, vy;
        float radius;
        float alpha;
        float swayPhase;
        float swaySpeed;
        float swayAmp;
    };
    std::vector<Snowflake> snowflakes;
    bool snowInitialized = false;
    static const int MAX_SNOW = 160;
    float snowSpawnTimer = 0.0f;

    bool welcomeAnimationActive = false;
    float welcomeAnimationTime = 0.0f;
    float welcomeAnimationDuration = 4.0f;
    bool hasShownWelcome = false;

    ImColor textColor = ImColor(255, 255, 255);
    ImColor darkBlack = ImColor(15, 15, 15);
    ImColor mainColor = ImColor(15, 15, 15);
    ImColor grayColor = ImColor(23, 24, 23);
    ImColor enumBackGround = ImColor(20, 20, 20);
    ImColor categoryBackground = ImColor(23, 24, 23);
    ImColor moduleBackground = ImColor(23, 24, 23);
    ImColor settingBackground = ImColor(25, 25, 25);
    ImColor enumBackground = ImColor(20, 20, 20);



    ImVec4 scaleToPoint(const ImVec4& _this, const ImVec4& point, float amount);
    bool isMouseOver(const ImVec4& rect);
    ImVec4 getCenter(ImVec4& vec);
    bool isMouseOverGuiElement();
    void render(float animation, float inScale, int& scrollDirection, char* h, float blur, float midclickRounding, bool isPressingShift);

    void onWindowResizeEvent(class WindowResizeEvent& event);
    void clearCache();
    void initializeCache();
    void startAsyncFilter();
    void stopAsyncFilter();
    void initializeLeaves();
    void updateLeaves(float deltaTime);
    void renderLeaves(ImDrawList* drawList, float animation);
    void startWelcomeAnimation();
    void renderWelcomeAnimation(ImDrawList* drawList, ImVec2 screenSize);
    void resetWelcomeAnimation(); // Для тестирования
    static char searchBuffer[128];
    static bool searchFocused;
    void handleSearchInput(unsigned int key, bool down);

    void initializeSnow();
    void updateSnow(float deltaTime);
    void renderSnow(ImDrawList* drawList, float animation);

private:
    void DrawRightRoundedInput(ImVec2 pos, ImVec2 size, float rounding, char* buffer, size_t buf_size, float alpha, float appear);
    void drawShineBand(ImDrawList* dl, ID3D11ShaderResourceView* tex, const ImVec2& pMin, const ImVec2& pMax, float alpha);
    ID3D11ShaderResourceView* getTextureCached(const std::string& key, int& w, int& h);

    struct ScrollBarState {
        bool isDragging = false;
        float dragStartY = 0;
        float contentStartScroll = 0;
    };

    std::vector<ScrollBarState> scrollStates;
    float calculateColumnX(int columnIndex, float screenWidth) const {
        float totalWidth = (catWidth * 4) + (catGap * 3);
        float startX = (screenWidth - totalWidth) / 2;
        return startX + (columnIndex * (catWidth + catGap));
    }
};

extern ModernGui modernGui;
