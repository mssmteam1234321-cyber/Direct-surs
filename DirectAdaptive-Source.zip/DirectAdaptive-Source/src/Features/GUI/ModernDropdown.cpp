﻿#include "ModernDropdown.hpp"
#include <imgui.h>
#include <Features/Modules/ModuleCategory.hpp>
#include <Features/Modules/Visual/ClickGui.hpp>
#include <Utils/FontHelper.hpp>
#include <Utils/MiscUtils/ImRenderUtils.hpp>
#include <Utils/MiscUtils/D2D.hpp>
#include <Utils/MiscUtils/MathUtils.hpp>
#include <Features/Modules/Setting.hpp>
#include <Features/Modules/Visual/Interface.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <Utils/Keyboard.hpp>
#include <Utils/StringUtils.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>
#include <Hook/Hooks/RenderHooks/D3DHook.hpp>
#include <Features/Configs/ConfigManager.hpp>
#include <Utils/FileUtils.hpp>
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>
#include <unordered_map>
#include <Features/Modules/Misc/EditionFaker.hpp>
#include <Features/Modules/Misc/DeviceSpoof.hpp>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <Features/Auth/AuthManager.hpp>
#include <Features/IRC/IrcClient.hpp>

ModernGui modernGui;

ImVec4 ModernGui::scaleToPoint(const ImVec4& _this, const ImVec4& point, float amount)
{
    return { point.x + (_this.x - point.x) * amount, point.y + (_this.y - point.y) * amount,
        point.z + (_this.z - point.z) * amount, point.w + (_this.w - point.w) * amount };
}

bool ModernGui::isMouseOver(const ImVec4& rect)
{
    ImVec2 mousePos = ImGui::GetIO().MousePos;
    return mousePos.x >= rect.x && mousePos.y >= rect.y && mousePos.x < rect.z && mousePos.y < rect.w;
}

ImVec4 ModernGui::getCenter(ImVec4& vec)
{
    float centerX = (vec.x + vec.z) / 2.0f;
    float centerY = (vec.y + vec.w) / 2.0f;
    return { centerX, centerY, centerX, centerY };
}

void ModernGui::render(float animation, float inScale, int& scrollDirection, char* h, float blur, float midclickRounding, bool isPressingShift)
{
    ImFont* fontGuard = ImGui::GetFont();
    if (!fontGuard) return;
    static bool randInitialized = false;
    if (!randInitialized) {
        srand(static_cast<unsigned int>(time(nullptr)));
        randInitialized = true;
    }
    static float mainGuiAnim = 1.0f;
    static bool wasConfigsOpen = false;
    static bool wasSpooferOpen = false;
    static float configsCloseDelay = 0.0f;
    static bool wasDragging = false;
    static std::unordered_map<size_t, float> hoverScales;
    static std::unordered_map<Module*, float> prevCAnim;
    static std::unordered_map<Module*, uint64_t> closingRoundHoldUntil;
    static uint64_t colorTimeBase = NOW;
    static std::unordered_map<size_t, float> enumHoverAnim;
    static std::unordered_map<size_t, float> enumSelectAnim;
    static std::unordered_map<Module*, float> staffTextAnim;
    colorTimeBase = NOW;
    auto getCachedThemedColor = [&](int key) -> ImColor {
        return ColorUtils::getThemedColor(key, colorTimeBase);
        };
    if (displayConfigsMenu && !wasConfigsOpen) {
        wasConfigsOpen = true;
    }
    if (!displayConfigsMenu && wasConfigsOpen) {
        wasConfigsOpen = false;
        configsCloseDelay = 0.3f;
    }
    if (displaySpooferMenu && !wasSpooferOpen) {
        wasSpooferOpen = true;
    }
    if (!displaySpooferMenu && wasSpooferOpen) {
        wasSpooferOpen = false;
        configsCloseDelay = 0.3f;
    }
    if (configsCloseDelay > 0.0f) {
        configsCloseDelay -= ImRenderUtils::getDeltaTime();
        if (configsCloseDelay <= 0.0f) {
            configsCloseDelay = 0.0f;
        }
    }
    float targetMainGui = (!displayConfigsMenu && !displaySpooferMenu && configsCloseDelay <= 0.0f) ? 1.0f : 0.0f;
    if (abs(targetMainGui - mainGuiAnim) > 0.001f) {
        float speed = (targetMainGui < mainGuiAnim) ? 28.0f : 20.0f;
        mainGuiAnim = MathUtils::animate(targetMainGui, mainGuiAnim, ImRenderUtils::getDeltaTime() * speed);
    }
    float globalFade = animation;
    animation *= mainGuiAnim;
    ImRenderUtils::pushGlobalAlpha(globalFade);
    struct GlobalAlphaScope { ~GlobalAlphaScope() { ImRenderUtils::popGlobalAlpha(); } } _gaScope;
    if (!perfCache.cacheInitialized) {
        initializeCache();
    }
    static auto interfaceMod = gFeatureManager->mModuleManager->getModule<Interface>();
    if (!perfCache.lowercaseCacheValid) {
        perfCache.cachedLowercase = interfaceMod->mNamingStyle.mValue == NamingStyle::Lowercase || interfaceMod->mNamingStyle.mValue == NamingStyle::LowercaseSpaced;
        perfCache.lowercaseCacheValid = true;
    }
    bool lowercase = perfCache.cachedLowercase;
    if (interfaceMod) {
        auto fontType = interfaceMod->mFont.as<Interface::FontType>();
        FontHelper::pushPrefFont(true, true, false);
    }
    else {
        FontHelper::pushPrefFont(true, true, true);
    }
    ImVec2 screen = ImRenderUtils::getScreenSize();
    auto drawList = ImGui::GetBackgroundDrawList();
    auto clickGuiMod = gFeatureManager->mModuleManager->getModule<ClickGui>();
    auto drawBorderSides = [&](const ImVec4& r, float alphaFactor, bool left, bool right, bool top, bool bottom, float thickness, ImDrawList* dl)
        {
            ImColor blurBg = Interface::getBlurBgColor();
            float darken = 0.70f;
            int rCol = (int)(blurBg.Value.x * 255.0f * darken);
            int gCol = (int)(blurBg.Value.y * 255.0f * darken);
            int bCol = (int)(blurBg.Value.z * 255.0f * darken);
            int aCol = (int)(120.0f * alphaFactor * ImRenderUtils::getGlobalAlpha());
            ImU32 col = IM_COL32(rCol, gCol, bCol, aCol);
            if (left)  dl->AddRectFilled(ImVec2(std::floor(r.x), std::floor(r.y)), ImVec2(std::floor(r.x + thickness), std::floor(r.w)), col);
            if (right) dl->AddRectFilled(ImVec2(std::floor(r.z - thickness), std::floor(r.y)), ImVec2(std::floor(r.z), std::floor(r.w)), col);
            if (top)   dl->AddRectFilled(ImVec2(std::floor(r.x), std::floor(r.y)), ImVec2(std::floor(r.z), std::floor(r.y + thickness)), col);
            if (bottom)dl->AddRectFilled(ImVec2(std::floor(r.x), std::floor(r.w - thickness)), ImVec2(std::floor(r.z), std::floor(r.w)), col);
        };
    bool guiEnabled = (clickGuiMod && clickGuiMod->mEnabled);
    bool overlayActive = guiEnabled || displayConfigsMenu || displaySpooferMenu || (animation > 0.001f);
    bool closingPhase = (!guiEnabled && animation > 0.001f);
    bool closingFadeOnly = closingPhase && (animation < 0.35f);
    static bool lowPerformanceMode = false;
    static float fpsCheckTimer = 0.0f;
    fpsCheckTimer += ImRenderUtils::getDeltaTime();
    if (fpsCheckTimer > 1.0f) {
        float fps = ImGui::GetIO().Framerate;
        lowPerformanceMode = (fps < 45.0f);
        fpsCheckTimer = 0.0f;
    }
    if (welcomeAnimationActive) {
        FontHelper::popPrefFont();
        return;
    }
    if (!overlayActive) {
        FontHelper::popPrefFont();
        return;
    }



    
    
#if 1
    if (!snowInitialized) {
        initializeSnow();
    }
    updateSnow(ImRenderUtils::getDeltaTime());
    renderSnow(ImGui::GetBackgroundDrawList(), animation);

    if (resetPosition && NOW - lastReset > 100)
    {
        catPositions.clear();
        ImVec2 screen = ImRenderUtils::getScreenSize();
        auto categories = ModuleCategoryNames;
        if (catPositions.empty())
        {
            float centerX = screen.x / 2.f;
            float centerY = screen.y / 2.f;
            float xPos = centerX - (categories.size() * (catWidth + catGap) / 2);
            float yPos = centerY - (catTotalHeight / 2);

            for (std::string& category : categories)
            {
                CategoryPosition pos;
                pos.x = xPos;
                pos.y = yPos;
                pos.x = std::round(pos.x / 2) * 2;
                pos.y = std::round(pos.y / 2) * 2;

                xPos += catWidth + catGap;
                catPositions.push_back(pos);
            }
        }
        resetPosition = false;
    }

    if ((guiEnabled || animation > 0.001f) && !displayConfigsMenu && !displaySpooferMenu) {
        if (!lowPerformanceMode) {
            D2D::addBlurOptimized(drawList, 2.0f * animation, ImVec4(0, 0, screen.x, screen.y), 0.0f);
        }
    }
    if (closingPhase) {
        FontHelper::popPrefFont();
        return;
    }


    static std::vector<std::string> categories = ModuleCategoryNames;
    if (!perfCache.modulesCacheValid) {
        perfCache.modulesCache = &gFeatureManager->mModuleManager->getModules();
        perfCache.modulesCacheValid = true;
    }
    auto& modules = *perfCache.modulesCache;
    static auto* clickGui = gFeatureManager->mModuleManager->getModule<ClickGui>();
    bool isEnabled = clickGui->mEnabled;
    std::string tooltip = "";
    float textSize = 1.f;
    float textHeight = ImGui::GetFont()->CalcTextSizeA(textSize * 18, FLT_MAX, -1, "").y;
    int screenWidth = (int)screen.x;
    int screenHeight = 10;
    float windowWidth = 220.0f;
    float windowHeight = 190.0f;
    float yOffset = 50.0f;
    float windowX = (screenWidth - windowWidth) * 0.5f;
    float windowY = screenHeight;
    static float colorPickerAnim = 0.0f;
    float cpTarget = (displayColorPicker && isEnabled) ? 1.0f : 0.0f;
    {
        float speed = (cpTarget < colorPickerAnim) ? 24.0f : 10.0f;
        colorPickerAnim = MathUtils::animate(cpTarget, colorPickerAnim, ImRenderUtils::getDeltaTime() * speed);
    }
    if ((displayColorPicker || colorPickerAnim > 0.01f) && isEnabled)
    {
        static auto interfaceMod = gFeatureManager->mModuleManager->getModule<Interface>();
        if (interfaceMod) {
            FontHelper::pushPrefFont(false, true, false);
        }
        else {
            FontHelper::pushPrefFont(false, true, true);
        }
        ColorSetting* colorSetting = lastColorSetting;
        float t_cp = colorPickerAnim;
        float ease_cp = 1.0f - powf(1.0f - t_cp, 3.0f);
        drawList->AddRectFilled(ImVec2(0, 0), ImVec2(screen.x, screen.y), IM_COL32(0, 0, 0, (int)(255 * ease_cp * 0.62f * ImRenderUtils::getGlobalAlpha())));
        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(ImVec2(screen.x, screen.y));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, 0.0f);
        ImGui::Begin("##ColorPickerOverlay", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus);
        ImGui::InvisibleButton("##color_overlay_catcher", ImVec2(screen.x, screen.y));
        ImGui::End();
        ImGui::PopStyleVar(3);
        float baseY = screen.y / 2 - 50;
        float yShift = MathUtils::lerp(25.0f, 0.0f, ease_cp);
        float windowY = baseY + yShift;
        float scale = MathUtils::lerp(0.85f, 1.0f, ease_cp);
        float windowW = 220.0f * scale;
        float windowH = 195.0f * scale;
        float windowX = screen.x / 2 - windowW / 2;
        ImGui::SetNextWindowPos(ImVec2(windowX, windowY));
        ImGui::SetNextWindowSize(ImVec2(windowW, windowH));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 12.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_cp * ImRenderUtils::getGlobalAlpha());
        ImColor __cpBg = Interface::getBlurBgColor();
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(__cpBg.Value.x, __cpBg.Value.y, __cpBg.Value.z, __cpBg.Value.w));

        ImGui::Begin("Color Picker", &displayColorPicker, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar);
        {
            ImVec2 __cpPos = ImGui::GetWindowPos();
            ImVec2 __cpSize = ImGui::GetWindowSize();
            D2D::addBlurOptimized(ImGui::GetBackgroundDrawList(), 8.0f, ImVec4(__cpPos.x, __cpPos.y, __cpPos.x + __cpSize.x, __cpPos.y + __cpSize.y), 12.0f);
            ImVec4 color = colorSetting->getAsImColor().Value;
            ImVec2 windowSize = ImGui::GetWindowSize();
            float pickerSize = 200.0f * scale;
            float centerX = (windowSize.x - pickerSize) * 0.5f;
            float centerY = 10.0f * scale;
            ImGui::SetCursorPos(ImVec2(centerX, centerY));
            ImGui::SetNextItemWidth(pickerSize);
            ImGui::ColorPicker4("Color", colorSetting->mValue, ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_NoAlpha | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_PickerHueBar);
        }
        ImGui::End();
        ImGui::PopStyleColor(1);
        ImGui::PopStyleVar(3);
        FontHelper::popPrefFont();

        if (ImGui::IsMouseClicked(0) && !ImRenderUtils::isMouseOver(ImVec4(windowX - 20, windowY - 20, windowX + windowW + 20, windowY + windowH + 20)))
        {
            displayColorPicker = false;
        }
    }
    if (!isEnabled) displayColorPicker = false;
    if (catPositions.empty() && isEnabled)
    {
        float centerX = screen.x / 2.f;
        float xPos = centerX - (categories.size() * (catWidth + catGap) / 2);
        for (std::string& category : categories)
        {
            CategoryPosition pos;
            pos.x = xPos;
            pos.y = catGap * 2;
            pos.x = std::round(pos.x / 2) * 2;
            pos.y = std::round(pos.y / 2) * 2;
            xPos += catWidth + catGap;
            catPositions.push_back(pos);
        }
    }

    if (!catPositions.empty())
    {
        {
            static float cfgModalAnim = 0.0f;
            float cfgTarget = (displayConfigsMenu && isEnabled) ? 1.0f : 0.0f;
            {
                float speed = (cfgTarget < cfgModalAnim) ? 22.0f : 10.0f;
                cfgModalAnim = MathUtils::animate(cfgTarget, cfgModalAnim, ImRenderUtils::getDeltaTime() * speed);
            }

            if (cfgModalAnim > 0.01f)
            {
                float t_cfg = cfgModalAnim;
                float ease_cfg = 1.0f - powf(1.0f - t_cfg, 3.0f);
                drawList->AddRectFilled(ImVec2(0, 0), ImVec2(screen.x, screen.y), IM_COL32(0, 0, 0, int(255 * 0.38f * ease_cfg * ImRenderUtils::getGlobalAlpha())));
                ImVec2 modalSize(440, 340);
                float yShift_cfg = 0.0f;
                ImVec2 modalPos(screen.x / 2 - modalSize.x / 2, screen.y / 2 - modalSize.y / 2 + yShift_cfg);
                float s_cfg = 1.70158f;
                float easeBack_cfg = 1.0f + (s_cfg + 1.0f) * powf(t_cfg - 1.0f, 3.0f) + s_cfg * powf(t_cfg - 1.0f, 2.0f);
                bool closing_cfg = (cfgTarget < cfgModalAnim);
                float scale = MathUtils::lerp(0.75f, 1.0f, closing_cfg ? ease_cfg : easeBack_cfg);
                ImVec2 scaledSize(modalSize.x * scale, modalSize.y * scale);
                ImVec2 scaledPos(modalPos.x + (modalSize.x - scaledSize.x) * 0.5f, modalPos.y + (modalSize.y - scaledSize.y) * 0.5f);
                ImVec4 cfgModalRect(scaledPos.x, scaledPos.y, scaledPos.x + scaledSize.x, scaledPos.y + scaledSize.y);
                ImGui::SetNextWindowPos(scaledPos);
                ImGui::SetNextWindowSize(scaledSize);
                ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
                ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 18.0f);
                ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_cfg * ImRenderUtils::getGlobalAlpha());
                ImColor __cfgBg = Interface::getBlurBgColor();
                ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(__cfgBg.Value.x, __cfgBg.Value.y, __cfgBg.Value.z, __cfgBg.Value.w));
                ImGui::Begin("Configs##modal", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar);
                {
                    ImVec2 winPos = ImGui::GetWindowPos();
                    ImVec2 winSize = ImGui::GetWindowSize();
                    D2D::addBlurOptimized(ImGui::GetBackgroundDrawList(), 8.0f, ImVec4(winPos.x, winPos.y, winPos.x + winSize.x, winPos.y + winSize.y), 18.0f);


                    static char configSearchBuffer[128] = "";
                    ImVec2 searchSize(190.0f, 30.0f);
                    ImVec2 createBtnSize(30.0f, 30.0f);


                    float headerYOffset = MathUtils::lerp(-8.0f, 0.0f, ease_cfg);
                    float headerAlpha = ease_cfg;

                    if (interfaceMod) {
                        FontHelper::pushPrefFont(true, true, false);
                    }
                    else {
                        if (interfaceMod) {
                            FontHelper::pushPrefFont(true, true, false);
                        }
                        else {
                            FontHelper::pushPrefFont(true, true, true);
                        }
                    }
                    ImGui::SetWindowFontScale(0.33f);

                    float searchMargin = 15.0f;
                    ImVec2 searchPos(winPos.x + winSize.x - searchSize.x - searchMargin, winPos.y + 12.0f + headerYOffset);


                    ImVec2 createBtnPos(searchPos.x - createBtnSize.x - 8.0f, searchPos.y);

                    {
                        ImDrawList* drawList = ImGui::GetWindowDrawList();


                        ImVec4 btnRect(createBtnPos.x, createBtnPos.y,
                            createBtnPos.x + createBtnSize.x, createBtnPos.y + createBtnSize.y);
                        bool isHovered = ImRenderUtils::isMouseOver(btnRect);


                        static float hoverAnimation = 0.0f;
                        float targetHover = isHovered ? 1.0f : 0.0f;
                        hoverAnimation = MathUtils::animate(targetHover, hoverAnimation, ImRenderUtils::getDeltaTime() * 8.0f);

                        ImColor baseBg = Interface::getBlurBgColor();
                        ImColor bgColor = baseBg;
                        float brighten = hoverAnimation * 0.15f;
                        bgColor.Value.x = std::min(1.0f, bgColor.Value.x + brighten);
                        bgColor.Value.y = std::min(1.0f, bgColor.Value.y + brighten);
                        bgColor.Value.z = std::min(1.0f, bgColor.Value.z + brighten);
                        bgColor.Value.w *= headerAlpha;
                        bgColor.Value.w *= 0.80f;
                        bgColor.Value.w *= ImRenderUtils::getGlobalAlpha();
                        drawList->AddRectFilled(
                            createBtnPos,
                            ImVec2(createBtnPos.x + createBtnSize.x, createBtnPos.y + createBtnSize.y),
                            bgColor,
                            12.0f,
                            ImDrawFlags_RoundCornersAll
                        );


                        if (hoverAnimation > 0.01f) {
                            drawList->AddRectFilled(
                                createBtnPos,
                                ImVec2(createBtnPos.x + createBtnSize.x, createBtnPos.y + createBtnSize.y),
                                IM_COL32(255, 255, 255, (int)(hoverAnimation * 25 * headerAlpha * ImRenderUtils::getGlobalAlpha())),
                                12.0f,
                                ImDrawFlags_RoundCornersAll
                            );
                        }


                        ID3D11ShaderResourceView* crossTex = nullptr;
                        int crossW = 0, crossH = 0;
                        auto itCross = perfCache.textureCache.find("cross");
                        if (itCross != perfCache.textureCache.end()) {
                            crossTex = itCross->second;
                            auto dims = perfCache.textureDimensions["cross"];
                            crossW = dims.first; crossH = dims.second;
                        }

                        if (crossTex) {
                            float baseIconSize = 16.0f;
                            float iconSize = baseIconSize + hoverAnimation * 2.0f;
                            ImVec2 iconPos(
                                createBtnPos.x + (createBtnSize.x - iconSize) / 2.0f,
                                createBtnPos.y + (createBtnSize.y - iconSize) / 2.0f
                            );

                            ImColor tcol = Interface::getTextColor();
                            drawList->AddImage(
                                (ImTextureID)crossTex,
                                iconPos,
                                ImVec2(iconPos.x + iconSize, iconPos.y + iconSize),
                                ImVec2(0, 0),
                                ImVec2(1, 1),
                                IM_COL32((int)(tcol.Value.x * 255.0f), (int)(tcol.Value.y * 255.0f), (int)(tcol.Value.z * 255.0f), (int)(((200 + hoverAnimation * 55) * headerAlpha) * ImRenderUtils::getGlobalAlpha()))
                            );
                            drawShineBand(drawList, crossTex, iconPos, ImVec2(iconPos.x + iconSize, iconPos.y + iconSize), headerAlpha);
                        }

                        if (isHovered && ImGui::IsMouseClicked(0)) {
                            static int userCounter = 1;
                            std::string newConfigName = "user" + std::to_string(userCounter);


                            while (FileUtils::fileExists(ConfigManager::getConfigPath() + "/" + newConfigName + ".json")) {
                                userCounter++;
                                newConfigName = "user" + std::to_string(userCounter);
                            }


                            ConfigManager::saveConfig(newConfigName);
                            userCounter++;

                            ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f);
                        }
                    }


                    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, headerAlpha * ImRenderUtils::getGlobalAlpha());
                    DrawRightRoundedInput(searchPos, searchSize, 12.0f, configSearchBuffer, sizeof(configSearchBuffer), headerAlpha, headerAlpha);
                    ImGui::PopStyleVar();


                    ImGui::SetWindowFontScale(1.0f);
                    FontHelper::popPrefFont();

                    float contentTop = winPos.y + 50.0f;
                    float contentLeft = winPos.x + 18.0f;
                    float contentRight = winPos.x + winSize.x - 18.0f;
                    float contentWidth = contentRight - contentLeft;
                    float contentHeight = winSize.y - 72.0f;


                    static float configScrollY = 0.0f;
                    static float configScrollTarget = 0.0f;
                    static float configScrollVelocity = 0.0f;
                    static bool isDraggingConfigScroll = false;
                    static float configDragStartY = 0.0f;
                    static float configScrollStartValue = 0.0f;
                    static float lastScrollTime = 0.0f;

                    static std::vector<std::string> allConfigs;
                    static uint64_t lastConfigRead = 0;

                    static bool needClearConfigs = false;
                    if (needClearConfigs) {
                        allConfigs.clear();
                        lastConfigRead = 0;
                        needClearConfigs = false;
                    }

                    if (allConfigs.empty() || NOW - lastConfigRead > 2000) {
                        std::vector<std::string> files = FileUtils::listFiles(ConfigManager::getConfigPath());
                        allConfigs.clear();
                        allConfigs.reserve(files.size());
                        for (const auto& f : files) {
                            if (f.size() > 5 && f.substr(f.size() - 5) == ".json") {
                                allConfigs.push_back(f.substr(0, f.size() - 5));
                            }
                        }
                        lastConfigRead = NOW;
                    }

                    std::vector<std::string> configs;
                    if (strlen(configSearchBuffer) == 0) {
                        configs = allConfigs;
                    }
                    else {
                        std::string q = StringUtils::toLower(configSearchBuffer);
                        for (const auto& name : allConfigs) {
                            if (StringUtils::containsIgnoreCase(name, q)) {
                                configs.push_back(name);
                            }
                        }
                    }

                    float gridTop = contentTop + 20.0f;
                    float cardW = contentWidth;
                    float cardH = 55.0f;
                    float gap = 15.0f;
                    float cardXOffset = 0.0f;

                    float totalConfigHeight = configs.size() * (cardH + gap) - gap;
                    float maxScroll = std::max(0.0f, totalConfigHeight - contentHeight);

                    if (ImRenderUtils::isMouseOver(ImVec4(contentLeft, contentTop, contentRight, contentTop + contentHeight))) {
                        if (scrollDirection > 0) {
                            configScrollTarget = std::min(maxScroll, configScrollTarget + 25.0f);
                            configScrollVelocity = 0.0f;
                        }
                        else if (scrollDirection < 0) {
                            configScrollTarget = std::max(0.0f, configScrollTarget - 25.0f);
                            configScrollVelocity = 0.0f;
                        }
                    }

                    configScrollTarget = std::clamp(configScrollTarget, 0.0f, maxScroll);

                    float deltaTime = ImRenderUtils::getDeltaTime();
                    float smoothFactor = 12.0f;
                    float damping = 0.85f;

                    if (NOW - lastScrollTime > 100) {
                        configScrollVelocity *= damping;
                        configScrollTarget += configScrollVelocity * deltaTime * 60.0f;
                        configScrollTarget = std::clamp(configScrollTarget, 0.0f, maxScroll);
                    }

                    configScrollY = MathUtils::animate(configScrollTarget, configScrollY, deltaTime * smoothFactor);


                    if (scrollDirection != 0) {
                        lastScrollTime = NOW;
                    }

                    ImDrawList* wdl = ImGui::GetWindowDrawList();
                    wdl->PushClipRect(
                        ImVec2(contentLeft, contentTop),
                        ImVec2(contentRight, contentTop + contentHeight + 100.0f),
                        true
                    );

                    float y = gridTop - configScrollY;
                    for (size_t idx = 0; idx < configs.size(); ++idx) {
                        float delay = 0.04f * (float)idx;
                        float denom = std::max(0.0001f, 1.0f - delay);
                        float appear = std::clamp((cfgModalAnim - delay) / denom, 0.0f, 1.0f);
                        float appearYOffset = MathUtils::lerp(10.0f, 0.0f, appear);
                        ImVec4 cardRect(contentLeft + cardXOffset, y + appearYOffset, contentLeft + cardXOffset + cardW, y + appearYOffset + cardH);

                        if (cardRect.y + cardH >= contentTop && cardRect.y <= contentTop + contentHeight) {
                            float alpha = appear;
                            float blurIntensity = 0.0f;


                            bool isCardHovered = ImRenderUtils::isMouseOver(cardRect);
                            float targetScale = isCardHovered ? 1.015f : 1.0f;
                            if (hoverScales.find(idx) == hoverScales.end()) {
                                hoverScales[idx] = 1.0f;
                            }
                            if (abs(targetScale - hoverScales[idx]) > 0.001f) {
                                hoverScales[idx] = MathUtils::animate(targetScale, hoverScales[idx], ImRenderUtils::getDeltaTime() * 8.0f);
                            }
                            float scale = hoverScales[idx] * MathUtils::lerp(0.94f, 1.0f, appear) * MathUtils::lerp(0.94f, 1.0f, appear);

                            float scaledWidth = cardW * scale;
                            float scaledHeight = cardH * scale;
                            float scaledX = cardRect.x + (cardW - scaledWidth) / 2.0f;
                            float scaledY = cardRect.y + (cardH - scaledHeight) / 2.0f;
                            ImVec4 scaledCardRect(scaledX, scaledY, scaledX + scaledWidth, scaledY + scaledHeight);
                            ImColor cardBg = Interface::getBlurBgColor();
                            ImRenderUtils::fillRectangle(scaledCardRect, cardBg, alpha * 0.80f, 10.0f * scale, ImGui::GetWindowDrawList(), ImDrawFlags_RoundCornersAll);


                            ImColor themeColor = getCachedThemedColor(0);
                            themeColor.Value.w *= alpha;
                            ImVec4 themeLine(scaledCardRect.x, scaledCardRect.y, scaledCardRect.x + 12.0f * scale, scaledCardRect.w);
                            ImRenderUtils::fillRectangle(themeLine, themeColor, alpha, 10.0f * scale, ImGui::GetWindowDrawList(), ImDrawFlags_RoundCornersLeft);


                            std::string cfgName = configs[idx];
                            float nameH = ImGui::GetFont()->CalcTextSizeA(18, FLT_MAX, -1, cfgName.c_str()).y;
                            ImColor nameColor = getCachedThemedColor(0);

                            float totalTextHeight = nameH + (nameH * 0.85f) + 6.0f * scale;
                            float centerY = scaledCardRect.y + (scaledCardRect.w - scaledCardRect.y - totalTextHeight) / 2.0f;

                            ImRenderUtils::drawText(ImVec2(scaledCardRect.x + 30.0f * scale, centerY), cfgName, nameColor, 1.0f, alpha, false, 0, ImGui::GetWindowDrawList());

                            std::string descriptionText = "Default Description";
                            ImColor descriptionColor = ImColor(107, 107, 107);
                            float descScale = 0.85f;
                            ImRenderUtils::drawText(ImVec2(scaledCardRect.x + 30.0f * scale, centerY + nameH + 6.0f * scale), descriptionText, descriptionColor, descScale, alpha, false, 0, ImGui::GetWindowDrawList());

                            float btnW = 45.0f * scale;
                            float btnH = 28.0f * scale;

                            float cardCenterY = (scaledCardRect.y + scaledCardRect.w) / 2.0f;
                            float btnY = cardCenterY - btnH / 2.0f;
                            ImVec4 loadBtn(scaledCardRect.z - (btnW * 2 + 4.0f * scale), btnY, scaledCardRect.z - (btnW + 4.0f * scale), btnY + btnH);
                            ImVec4 saveBtn(scaledCardRect.z - btnW, btnY, scaledCardRect.z, btnY + btnH);
                            bool hLoad = ImRenderUtils::isMouseOver(loadBtn);
                            bool hSave = ImRenderUtils::isMouseOver(saveBtn);

                            static float loadHoverAnim = 0.0f;
                            static float saveHoverAnim = 0.0f;

                            loadHoverAnim = MathUtils::animate(hLoad ? 1.0f : 0.0f, loadHoverAnim, ImRenderUtils::getDeltaTime() * 8.0f);
                            saveHoverAnim = MathUtils::animate(hSave ? 1.0f : 0.0f, saveHoverAnim, ImRenderUtils::getDeltaTime() * 8.0f);

                            ImColor loadBtnColorNormal = Interface::getBlurBgColor();
                            ImColor __whiteLighten = ImColor(255, 255, 255);
                            ImColor loadBtnColorHover = MathUtils::lerpImColor(loadBtnColorNormal, __whiteLighten, 0.15f);
                            ImColor saveBtnColorNormal = Interface::getBlurBgColor();
                            ImColor saveBtnColorHover = MathUtils::lerpImColor(saveBtnColorNormal, __whiteLighten, 0.15f);
                            ImColor loadBtnColor = MathUtils::lerpImColor(loadBtnColorNormal, loadBtnColorHover, loadHoverAnim);
                            ImColor saveBtnColor = MathUtils::lerpImColor(saveBtnColorNormal, saveBtnColorHover, saveHoverAnim);
                            ID3D11ShaderResourceView* loadTex = nullptr;
                            ID3D11ShaderResourceView* saveTex = nullptr;
                            int loadW = 0, loadH = 0, saveW = 0, saveH = 0;
                            auto itLoad = perfCache.textureCache.find("load");
                            if (itLoad != perfCache.textureCache.end()) {
                                loadTex = itLoad->second;
                                auto d = perfCache.textureDimensions["load"]; loadW = d.first; loadH = d.second;
                            }
                            auto itSave = perfCache.textureCache.find("save");
                            if (itSave != perfCache.textureCache.end()) {
                                saveTex = itSave->second;
                                auto d = perfCache.textureDimensions["save"]; saveW = d.first; saveH = d.second;
                            }

                            float iconSize = 18.0f * scale;

                            if (loadTex && saveTex) {
                                float loadIconAlpha = MathUtils::lerp(160.0f, 255.0f, loadHoverAnim) * alpha;
                                float saveIconAlpha = MathUtils::lerp(160.0f, 255.0f, saveHoverAnim) * alpha;
                                ImVec2 loadIconPos(
                                    loadBtn.x + (btnW - iconSize) / 2.0f,
                                    loadBtn.y + (btnH - iconSize) / 2.0f
                                );

                                ImColor tcol = Interface::getTextColor();
                                ImGui::GetWindowDrawList()->AddImage(
                                    (ImTextureID)loadTex,
                                    loadIconPos,
                                    ImVec2(loadIconPos.x + iconSize, loadIconPos.y + iconSize),
                                    ImVec2(0, 0), ImVec2(1, 1),
                                    IM_COL32((int)(tcol.Value.x * 255.0f), (int)(tcol.Value.y * 255.0f), (int)(tcol.Value.z * 255.0f), (int)(loadIconAlpha * ImRenderUtils::getGlobalAlpha()))
                                );
                                drawShineBand(ImGui::GetWindowDrawList(), loadTex, loadIconPos, ImVec2(loadIconPos.x + iconSize, loadIconPos.y + iconSize), alpha);
                                ImVec2 saveIconPos(
                                    saveBtn.x + (btnW - iconSize) / 2.0f,
                                    saveBtn.y + (btnH - iconSize) / 2.0f
                                );

                                ImGui::GetWindowDrawList()->AddImage(
                                    (ImTextureID)saveTex,
                                    saveIconPos,
                                    ImVec2(saveIconPos.x + iconSize, saveIconPos.y + iconSize),
                                    ImVec2(0, 0), ImVec2(1, 1),
                                    IM_COL32((int)(tcol.Value.x * 255.0f), (int)(tcol.Value.y * 255.0f), (int)(tcol.Value.z * 255.0f), (int)(saveIconAlpha * ImRenderUtils::getGlobalAlpha()))
                                );
                                drawShineBand(ImGui::GetWindowDrawList(), saveTex, saveIconPos, ImVec2(saveIconPos.x + iconSize, saveIconPos.y + iconSize), alpha);
                            }

                            if (hLoad && ImGui::IsMouseClicked(0)) {
                                ConfigManager::loadConfig(cfgName);
                            }
                            if (hSave && ImGui::IsMouseClicked(0)) {
                                ConfigManager::saveConfig(cfgName);
                            }
                        }

                        y += cardH + gap;
                    }

                    wdl->PopClipRect();
                }

                ImGui::End();
                ImGui::PopStyleColor(1);
                ImGui::PopStyleVar(3);

                if (ease_cfg > 0.8f && ImGui::IsMouseClicked(0) && !ImRenderUtils::isMouseOver(cfgModalRect)) {
                    displayConfigsMenu = false;
                }

                FontHelper::popPrefFont();
                return;
            }
        }

        
        {
            static float spoofModalAnim = 0.0f;
            float spoofTarget = (displaySpooferMenu && isEnabled) ? 1.0f : 0.0f;
            {
                float speed = (spoofTarget < spoofModalAnim) ? 22.0f : 10.0f;
                spoofModalAnim = MathUtils::animate(spoofTarget, spoofModalAnim, ImRenderUtils::getDeltaTime() * speed);
            }

            if (spoofModalAnim > 0.01f)
            {
                float t_spoof = spoofModalAnim;
                float ease_spoof = 1.0f - powf(1.0f - t_spoof, 3.0f);
                drawList->AddRectFilled(ImVec2(0, 0), ImVec2(screen.x, screen.y), IM_COL32(0, 0, 0, int(255 * 0.38f * ease_spoof * ImRenderUtils::getGlobalAlpha())));
                ImVec2 modalSize(340, 280);
                float yShift_spoof = 0.0f;
                ImVec2 modalPos(screen.x / 2 - modalSize.x / 2, screen.y / 2 - modalSize.y / 2 + yShift_spoof);
                float s_spoof = 1.70158f;
                float easeBack_spoof = 1.0f + (s_spoof + 1.0f) * powf(t_spoof - 1.0f, 3.0f) + s_spoof * powf(t_spoof - 1.0f, 2.0f);
                bool closing_spoof = (spoofTarget < spoofModalAnim);
                float scale = MathUtils::lerp(0.75f, 1.0f, closing_spoof ? ease_spoof : easeBack_spoof);
                ImVec2 scaledSize(modalSize.x * scale, modalSize.y * scale);
                ImVec2 scaledPos(modalPos.x + (modalSize.x - scaledSize.x) * 0.5f, modalPos.y + (modalSize.y - scaledSize.y) * 0.5f);
                ImVec4 spModalRect(scaledPos.x, scaledPos.y, scaledPos.x + scaledSize.x, scaledPos.y + scaledSize.y);
                ImGui::SetNextWindowPos(scaledPos);
                ImGui::SetNextWindowSize(scaledSize);
                ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
                ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 18.0f);
                ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_spoof * ImRenderUtils::getGlobalAlpha());
                ImColor __spBg = Interface::getBlurBgColor();
                ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(__spBg.Value.x, __spBg.Value.y, __spBg.Value.z, __spBg.Value.w));
                ImGui::Begin("Spoofer##modal", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar);
                {
                    ImVec2 winPos = ImGui::GetWindowPos();
                    ImVec2 winSize = ImGui::GetWindowSize();
                    D2D::addBlurOptimized(ImGui::GetBackgroundDrawList(), 8.0f, ImVec4(winPos.x, winPos.y, winPos.x + winSize.x, winPos.y + winSize.y), 18.0f);

                    static char deviceIdBuffer[128] = "";
                    static char selfSignedIdBuffer[128] = "";
                    static char deviceModelBuffer[128] = "";
                    static char skinIdBuffer[128] = "";
                    static char clientRandomIdBuffer[128] = "";
                    static bool needLoadBuffers = true;
                    static float lastSpoofAnim = 0.0f;
                    if (lastSpoofAnim > 0.5f && spoofModalAnim < 0.5f) {
                        needLoadBuffers = true;
                    }
                    lastSpoofAnim = spoofModalAnim;
                    if (needLoadBuffers && spoofModalAnim > 0.5f) {
                        if (!DeviceSpoof::HasGeneratedValues) {
                            DeviceSpoof::loadSpooferConfig();
                        }
                        strcpy_s(deviceIdBuffer, DeviceSpoof::CustomDeviceId.c_str());
                        strcpy_s(selfSignedIdBuffer, DeviceSpoof::CustomSelfSignedId.c_str());
                        strcpy_s(deviceModelBuffer, DeviceSpoof::CustomDeviceModel.c_str());
                        strcpy_s(skinIdBuffer, DeviceSpoof::CustomSkinId.c_str());
                        strcpy_s(clientRandomIdBuffer, DeviceSpoof::CustomClientRandomId.c_str());
                        needLoadBuffers = false;
                    }

                    float padding = 20.0f;
                    float fieldHeight = 24.0f;
                    float fieldGap = 8.0f;
                    float buttonHeight = 28.0f;
                    float inputWidth = 280.0f;
                    float inputX = (winSize.x - inputWidth) / 2.0f;
                    ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0, 0, 0, 0));
                    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0, 0, 0, 0));
                    ImGui::PushStyleColor(ImGuiCol_FrameBgActive, ImVec4(0, 0, 0, 0));
                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
                    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 8.0f);
                    ImGui::PushItemWidth(inputWidth);

                    ImGui::SetWindowFontScale(0.35f);

                    ImGui::SetCursorPos(ImVec2(inputX, padding + 8.0f));
                    ImGui::InputText("##deviceId", deviceIdBuffer, sizeof(deviceIdBuffer));

                    ImGui::SetCursorPos(ImVec2(inputX, ImGui::GetCursorPosY() + fieldGap));
                    ImGui::InputText("##selfSignedId", selfSignedIdBuffer, sizeof(selfSignedIdBuffer));

                    ImGui::SetCursorPos(ImVec2(inputX, ImGui::GetCursorPosY() + fieldGap));
                    ImGui::InputText("##deviceModel", deviceModelBuffer, sizeof(deviceModelBuffer));

                    ImGui::SetCursorPos(ImVec2(inputX, ImGui::GetCursorPosY() + fieldGap));
                    ImGui::InputText("##skinId", skinIdBuffer, sizeof(skinIdBuffer));

                    ImGui::SetCursorPos(ImVec2(inputX, ImGui::GetCursorPosY() + fieldGap));
                    ImGui::InputText("##clientRandomId", clientRandomIdBuffer, sizeof(clientRandomIdBuffer));

                    ImGui::SetWindowFontScale(1.0f);

                    ImGui::PopItemWidth();
                    ImGui::PopStyleVar();
                    ImGui::PopStyleColor(4);
                    float buttonWidth = 280.0f;
                    float buttonGap = 8.0f;
                    float buttonsStartY = winSize.y - (buttonHeight * 2 + buttonGap + padding);
                    float buttonX = (ImGui::GetWindowWidth() - buttonWidth) / 2.0f;

                    static float genBtnHover = 0.0f;
                    static float saveBtnHover = 0.0f;
                    static float saveBtnScale = 1.0f;
                    static float genBtnScale = 1.0f;
                    ImVec2 saveBtnPos = ImVec2(winPos.x + buttonX, winPos.y + buttonsStartY);
                    ImVec4 saveBtnRect(saveBtnPos.x, saveBtnPos.y, saveBtnPos.x + buttonWidth, saveBtnPos.y + buttonHeight);
                    bool isSaveHovered = ImRenderUtils::isMouseOver(saveBtnRect);
                    bool isSavePressed = isSaveHovered && ImGui::IsMouseDown(0);
                    saveBtnHover = MathUtils::animate(isSaveHovered ? 1.0f : 0.0f, saveBtnHover, ImRenderUtils::getDeltaTime() * 8.0f);
                    float saveBtnTargetScale = 1.0f;
                    if (isSavePressed) {
                        saveBtnTargetScale = 1.08f;
                    }
                    else if (isSaveHovered) {
                        saveBtnTargetScale = 1.03f;
                    }
                    saveBtnScale = MathUtils::animate(saveBtnTargetScale, saveBtnScale, ImRenderUtils::getDeltaTime() * 12.0f);
                    ImColor themeColor = getCachedThemedColor(0);
                    ImColor saveBtnColor = themeColor;
                    saveBtnColor.Value.w = ease_spoof;
                    saveBtnColor.Value.w *= 0.80f;
                    saveBtnColor.Value.w *= ImRenderUtils::getGlobalAlpha();

                    if (saveBtnHover > 0.01f) {
                        float brighten = 1.0f + saveBtnHover * 0.2f;
                        saveBtnColor.Value.x = std::min(1.0f, saveBtnColor.Value.x * brighten);
                        saveBtnColor.Value.y = std::min(1.0f, saveBtnColor.Value.y * brighten);
                        saveBtnColor.Value.z = std::min(1.0f, saveBtnColor.Value.z * brighten);
                    }

                    ImDrawList* dl = ImGui::GetWindowDrawList();
                    float rounding = 8.0f;

                    float scaledSaveBtnWidth = buttonWidth * saveBtnScale;
                    float scaledSaveBtnHeight = buttonHeight * saveBtnScale;
                    ImVec2 scaledSaveBtnPos(
                        saveBtnPos.x - (scaledSaveBtnWidth - buttonWidth) * 0.5f,
                        saveBtnPos.y - (scaledSaveBtnHeight - buttonHeight) * 0.5f
                    );

                    dl->AddRectFilled(
                        scaledSaveBtnPos,
                        ImVec2(scaledSaveBtnPos.x + scaledSaveBtnWidth, scaledSaveBtnPos.y + scaledSaveBtnHeight),
                        saveBtnColor,
                        rounding * saveBtnScale
                    );

                    ImGui::SetWindowFontScale(0.42f);
                    std::string saveLabel = "Save";
                    float saveTextW = ImGui::CalcTextSize(saveLabel.c_str()).x;
                    float saveTextH = ImGui::GetFontSize();
                    ImVec2 saveTextPos(scaledSaveBtnPos.x + (scaledSaveBtnWidth - saveTextW) / 2.0f, scaledSaveBtnPos.y + (scaledSaveBtnHeight - saveTextH) / 2.0f);
                    ImRenderUtils::drawText(saveTextPos, saveLabel, Interface::getTextColor(), 1.0f, ease_spoof, false, 0, ImGui::GetWindowDrawList());
                    ImGui::SetWindowFontScale(1.0f);

                    if (isSaveHovered && ImGui::IsMouseClicked(0)) {
                        DeviceSpoof::CustomDeviceId = deviceIdBuffer;
                        DeviceSpoof::CustomSelfSignedId = selfSignedIdBuffer;
                        DeviceSpoof::CustomDeviceModel = deviceModelBuffer;
                        DeviceSpoof::CustomSkinId = skinIdBuffer;
                        DeviceSpoof::CustomClientRandomId = clientRandomIdBuffer;
                        DeviceSpoof::saveSpooferConfig();
                        ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f);
                    }

                    ImVec2 genBtnPos = ImVec2(winPos.x + buttonX, winPos.y + buttonsStartY + buttonHeight + buttonGap);
                    ImVec4 genBtnRect(genBtnPos.x, genBtnPos.y, genBtnPos.x + buttonWidth, genBtnPos.y + buttonHeight);
                    bool isGenHovered = ImRenderUtils::isMouseOver(genBtnRect);
                    bool isGenPressed = isGenHovered && ImGui::IsMouseDown(0);
                    genBtnHover = MathUtils::animate(isGenHovered ? 1.0f : 0.0f, genBtnHover, ImRenderUtils::getDeltaTime() * 8.0f);

                    float genBtnTargetScale = 1.0f;
                    if (isGenPressed) {
                        genBtnTargetScale = 1.1f;
                    }
                    else if (isGenHovered) {
                        genBtnTargetScale = 1.05f;
                    }
                    genBtnScale = MathUtils::animate(genBtnTargetScale, genBtnScale, ImRenderUtils::getDeltaTime() * 15.0f);

                    ImColor genBtnColor = themeColor;
                    genBtnColor.Value.w = ease_spoof;
                    genBtnColor.Value.w *= 0.80f;
                    genBtnColor.Value.w *= ImRenderUtils::getGlobalAlpha();

                    if (genBtnHover > 0.01f) {
                        float brighten = 1.0f + genBtnHover * 0.2f;
                        genBtnColor.Value.x = std::min(1.0f, genBtnColor.Value.x * brighten);
                        genBtnColor.Value.y = std::min(1.0f, genBtnColor.Value.y * brighten);
                        genBtnColor.Value.z = std::min(1.0f, genBtnColor.Value.z * brighten);
                    }

                    float scaledGenBtnWidth = buttonWidth * genBtnScale;
                    float scaledGenBtnHeight = buttonHeight * genBtnScale;
                    ImVec2 scaledGenBtnPos(
                        genBtnPos.x - (scaledGenBtnWidth - buttonWidth) * 0.5f,
                        genBtnPos.y - (scaledGenBtnHeight - buttonHeight) * 0.5f
                    );

                    dl->AddRectFilled(
                        scaledGenBtnPos,
                        ImVec2(scaledGenBtnPos.x + scaledGenBtnWidth, scaledGenBtnPos.y + scaledGenBtnHeight),
                        genBtnColor,
                        rounding * genBtnScale
                    );

                    ImGui::SetWindowFontScale(0.42f);
                    std::string genLabel = "Generate Random";
                    float genTextW = ImGui::CalcTextSize(genLabel.c_str()).x;
                    float genTextH = ImGui::GetFontSize();
                    ImVec2 genTextPos(scaledGenBtnPos.x + (scaledGenBtnWidth - genTextW) / 2.0f, scaledGenBtnPos.y + (scaledGenBtnHeight - genTextH) / 2.0f);
                    ImRenderUtils::drawText(genTextPos, genLabel, Interface::getTextColor(), 1.0f, ease_spoof, false, 0, ImGui::GetWindowDrawList());
                    ImGui::SetWindowFontScale(1.0f);

                    if (isGenHovered && ImGui::IsMouseClicked(0)) {
                        DeviceSpoof::generateRandomValues();
                        strcpy_s(deviceIdBuffer, DeviceSpoof::CustomDeviceId.c_str());
                        strcpy_s(selfSignedIdBuffer, DeviceSpoof::CustomSelfSignedId.c_str());
                        strcpy_s(deviceModelBuffer, DeviceSpoof::CustomDeviceModel.c_str());
                        strcpy_s(skinIdBuffer, DeviceSpoof::CustomSkinId.c_str());
                        strcpy_s(clientRandomIdBuffer, DeviceSpoof::CustomClientRandomId.c_str());
                        ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f);
                    }
                }

                ImGui::End();
                ImGui::PopStyleColor(1);
                ImGui::PopStyleVar(3);
                if (ease_spoof > 0.8f && ImGui::IsMouseClicked(0) && !ImRenderUtils::isMouseOver(spModalRect)) {
                    displaySpooferMenu = false;
                }
                FontHelper::popPrefFont();
                return;
            }
        }
        
        // IRC Menu
        {
            static float ircModalAnim = 0.0f;
            float ircTarget = (displayIRCMenu && isEnabled) ? 1.0f : 0.0f;
            {
                float speed = (ircTarget < ircModalAnim) ? 22.0f : 10.0f;
                ircModalAnim = MathUtils::animate(ircTarget, ircModalAnim, ImRenderUtils::getDeltaTime() * speed);
            }

            if (ircModalAnim > 0.01f)
            {
                float t_irc = ircModalAnim;
                float ease_irc = 1.0f - powf(1.0f - t_irc, 3.0f);
                
                // Check ESC BEFORE any ImGui windows
                if (ImGui::IsKeyPressed(ImGuiKey_Escape)) {
                    displayIRCMenu = false;
                }

                static uint64_t lastIrcGuiConnectAttempt = 0;
                if (AuthManager::getInstance().isAuthorized())
                {
                    if ((!IrcManager::mClient || IrcManager::mClient->mConnectionState == ConnectionState::Disconnected) && (NOW - lastIrcGuiConnectAttempt > 5000))
                    {
                        lastIrcGuiConnectAttempt = NOW;
                        IrcManager::init();
                    }
                }

                // Sync connection state from IRC client for status display
                ConnectionState connState = ConnectionState::Disconnected;
                if (IrcManager::mClient) {
                    connState = IrcManager::mClient->mConnectionState;
                }
                ircConnected = (connState == ConnectionState::Connected);
                
                drawList->AddRectFilled(ImVec2(0, 0), ImVec2(screen.x, screen.y), IM_COL32(0, 0, 0, int(255 * 0.48f * ease_irc * ImRenderUtils::getGlobalAlpha())));
                float modalW = std::min(screen.x * 0.85f, 1100.0f);
                float modalH = std::min(screen.y * 0.7f, 700.0f);
                ImVec2 modalSize(modalW, modalH);
                ImVec2 modalPos(screen.x / 2 - modalSize.x / 2, screen.y / 2 - modalSize.y / 2);
                float s_irc = 1.70158f;
                float easeBack_irc = 1.0f + (s_irc + 1.0f) * powf(t_irc - 1.0f, 3.0f) + s_irc * powf(t_irc - 1.0f, 2.0f);
                bool closing_irc = (ircTarget < ircModalAnim);
                float scale = MathUtils::lerp(0.75f, 1.0f, closing_irc ? ease_irc : easeBack_irc);
                ImVec2 scaledSize(modalSize.x * scale, modalSize.y * scale);
                ImVec2 scaledPos(modalPos.x + (modalSize.x - scaledSize.x) * 0.5f, modalPos.y + (modalSize.y - scaledSize.y) * 0.5f);
                ImVec4 ircModalRect(scaledPos.x, scaledPos.y, scaledPos.x + scaledSize.x, scaledPos.y + scaledSize.y);
                ImGui::SetNextWindowPos(scaledPos);
                ImGui::SetNextWindowSize(scaledSize);
                ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
                ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 18.0f);
                ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ease_irc * ImRenderUtils::getGlobalAlpha());
                ImColor __ircBg = Interface::getBlurBgColor();
                ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(__ircBg.Value.x, __ircBg.Value.y, __ircBg.Value.z, __ircBg.Value.w));
                ImGui::Begin("IRC##modal", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar);
                {
                    ImVec2 winPos = ImGui::GetWindowPos();
                    ImVec2 winSize = ImGui::GetWindowSize();
                    D2D::addBlurOptimized(ImGui::GetBackgroundDrawList(), 8.0f, ImVec4(winPos.x, winPos.y, winPos.x + winSize.x, winPos.y + winSize.y), 18.0f);

                    // Draw WhatsApp-style background pattern
                    ImDrawList* dl = ImGui::GetWindowDrawList();
                    ImColor bgPattern = ImColor(15, 20, 15, 25);
                    for (float y = 0; y < winSize.y; y += 20.0f) {
                        for (float x = 0; x < winSize.x; x += 20.0f) {
                            dl->AddCircleFilled(ImVec2(winPos.x + x, winPos.y + y), 1.5f, bgPattern);
                        }
                    }

                    float tabHeight = 45.0f;
                    float tabWidth = winSize.x / 3.0f;
                    float padding = 15.0f;

                    // Header with tabs
                    ImGui::SetWindowFontScale(0.42f);
                    static float tabAnimations[3] = {1.0f, 0.0f, 0.0f};
                    const char* tabNames[] = {"Мои друзья", "Глобальный чат", "Настройки"};
                    
                    ImColor themeColor = getCachedThemedColor(0);
                    for (int i = 0; i < 3; i++) {
                        ImVec2 tabPos(winPos.x + i * tabWidth, winPos.y);
                        ImVec4 tabRect(tabPos.x, tabPos.y, tabPos.x + tabWidth, tabPos.y + tabHeight);
                        bool isTabHovered = ImRenderUtils::isMouseOver(tabRect);
                        
                        float targetAnim = (currentIRCTab == i) ? 1.0f : (isTabHovered ? 0.3f : 0.0f);
                        tabAnimations[i] = MathUtils::animate(targetAnim, tabAnimations[i], ImRenderUtils::getDeltaTime() * 10.0f);

                        if (tabAnimations[i] > 0.01f) {
                            ImColor tabBg = themeColor;
                            tabBg.Value.w = tabAnimations[i] * 0.3f * ease_irc * ImRenderUtils::getGlobalAlpha();
                            dl->AddRectFilled(ImVec2(tabRect.x, tabRect.y), ImVec2(tabRect.z, tabRect.w), tabBg, 0.0f);
                        }

                        // Underline for active tab
                        if (currentIRCTab == i) {
                            ImColor lineColor = themeColor;
                            lineColor.Value.w = ease_irc * ImRenderUtils::getGlobalAlpha();
                            dl->AddRectFilled(
                                ImVec2(tabRect.x + 10, tabRect.w - 3),
                                ImVec2(tabRect.z - 10, tabRect.w),
                                lineColor,
                                2.0f
                            );
                        }
                        
                        std::string tabText = tabNames[i];
                        float textW = ImGui::CalcTextSize(tabText.c_str()).x;
                        float textH = ImGui::GetFontSize();
                        ImVec2 textPos(tabPos.x + (tabWidth - textW) / 2.0f, tabPos.y + (tabHeight - textH) / 2.0f);
                        
                        ImColor textCol = (currentIRCTab == i) ? themeColor : Interface::getTextColor();
                        textCol.Value.w = ease_irc;
                        ImRenderUtils::drawText(textPos, tabText, textCol, 1.0f, ease_irc, false, 0, dl);

                        if (isTabHovered && ImGui::IsMouseClicked(0)) {
                            currentIRCTab = i;
                            ClientInstance::get()->playUi("random.click", 0.5f, 1.0f);
                        }
                    }
                    ImGui::SetWindowFontScale(1.0f);

                    // Chat content area
                    float contentTop = winPos.y + tabHeight + padding;
                    float contentBottom = winPos.y + winSize.y - 60.0f;
                    float contentHeight = contentBottom - contentTop;
                    float contentLeft = winPos.x + padding;
                    float contentRight = winPos.x + winSize.x - padding;

                    dl->PushClipRect(ImVec2(contentLeft, contentTop), ImVec2(contentRight, contentBottom), true);

                    if (currentIRCTab == 0) {
                        // Мои друзья (Friends)
                        ImGui::SetWindowFontScale(0.38f);
                        float messageY = contentTop + padding;
                        
                        if (friendsChatMessages.empty()) {
                            std::string emptyText = "Нет сообщений от друзей";
                            float textW = ImGui::CalcTextSize(emptyText.c_str()).x;
                            ImVec2 textPos(contentLeft + (contentRight - contentLeft - textW) / 2.0f, contentTop + contentHeight / 2.0f);
                            ImRenderUtils::drawText(textPos, emptyText, ImColor(150, 150, 150), 1.0f, ease_irc * 0.5f, false, 0, dl);
                        } else {
                            for (const auto& msg : friendsChatMessages) {
                                float msgWidth = 300.0f;
                                float msgHeight = 50.0f;
                                float msgX = msg.isOwn ? (contentRight - msgWidth - 10) : (contentLeft + 10);
                                
                                ImVec4 msgRect(msgX, messageY, msgX + msgWidth, messageY + msgHeight);
                                ImColor msgBg = msg.isOwn ? ImColor(5, 97, 98, 180) : ImColor(32, 44, 51, 180);
                                msgBg.Value.w *= ease_irc * ImRenderUtils::getGlobalAlpha();
                                dl->AddRectFilled(ImVec2(msgRect.x, msgRect.y), ImVec2(msgRect.z, msgRect.w), msgBg, 8.0f);
                                
                                ImRenderUtils::drawText(ImVec2(msgRect.x + 10, msgRect.y + 8), msg.sender, themeColor, 0.9f, ease_irc, false, 0, dl);
                                ImRenderUtils::drawText(ImVec2(msgRect.x + 10, msgRect.y + 28), msg.text, Interface::getTextColor(), 1.0f, ease_irc, false, 0, dl);
                                
                                messageY += msgHeight + 8.0f;
                            }
                        }
                        ImGui::SetWindowFontScale(1.0f);
                    }
                    else if (currentIRCTab == 1) {
                        // Глобальный чат (Global Chat)  
                        ImGui::SetWindowFontScale(0.38f);
                        float messageY = contentTop + padding;
                        
                        if (globalChatMessages.empty()) {
                            std::string emptyText = "Глобальный чат пуст. Подключение...";
                            float textW = ImGui::CalcTextSize(emptyText.c_str()).x;
                            ImVec2 textPos(contentLeft + (contentRight - contentLeft - textW) / 2.0f, contentTop + contentHeight / 2.0f);
                            ImRenderUtils::drawText(textPos, emptyText, ImColor(150, 150, 150), 1.0f, ease_irc * 0.5f, false, 0, dl);
                        } else {
                            for (const auto& msg : globalChatMessages) {
                                float msgWidth = 350.0f;
                                float msgHeight = 50.0f;
                                float msgX = msg.isOwn ? (contentRight - msgWidth - 10) : (contentLeft + 10);
                                
                                ImVec4 msgRect(msgX, messageY, msgX + msgWidth, messageY + msgHeight);
                                ImColor msgBg = msg.isOwn ? ImColor(5, 97, 98, 180) : ImColor(32, 44, 51, 180);
                                msgBg.Value.w *= ease_irc * ImRenderUtils::getGlobalAlpha();
                                dl->AddRectFilled(ImVec2(msgRect.x, msgRect.y), ImVec2(msgRect.z, msgRect.w), msgBg, 8.0f);
                                
                                ImRenderUtils::drawText(ImVec2(msgRect.x + 10, msgRect.y + 8), msg.sender, themeColor, 0.9f, ease_irc, false, 0, dl);
                                ImRenderUtils::drawText(ImVec2(msgRect.x + 10, msgRect.y + 28), msg.text, Interface::getTextColor(), 1.0f, ease_irc, false, 0, dl);
                                
                                messageY += 58.0f;
                            }
                        }
                        ImGui::SetWindowFontScale(1.0f);
                    }
                    else if (currentIRCTab == 2) {
                        // Настройки (Settings)
                        ImGui::SetWindowFontScale(0.38f);
                        float settingY  = contentTop + padding;
                        
                        ImRenderUtils::drawText(ImVec2(contentLeft + 10, settingY), "Фон чата:", Interface::getTextColor(), 1.0f, ease_irc, false, 0, dl);
                        settingY += 30.0f;
                        
                        const char* bgStyles[] = {"WhatsApp", "Темный", "Светлый"};
                        for (int i = 0; i < 3; i++) {
                            ImVec4 btnRect(contentLeft + 10, settingY, contentLeft + 150, settingY + 35);
                            bool isHovered = ImRenderUtils::isMouseOver(btnRect);
                            
                            ImColor btnBg = Interface::getBlurBgColor();
                            if (isHovered) {
                                btnBg.Value.x = std::min(1.0f, btnBg.Value.x + 0.1f);
                                btnBg.Value.y = std::min(1.0f, btnBg.Value.y + 0.1f);
                                btnBg.Value.z = std::min(1.0f, btnBg.Value.z + 0.1f);
                            }
                            btnBg.Value.w = 0.8f * ease_irc * ImRenderUtils::getGlobalAlpha();
                            dl->AddRectFilled(ImVec2(btnRect.x, btnRect.y), ImVec2(btnRect.z, btnRect.w), btnBg, 8.0f);
                            
                            float textW = ImGui::CalcTextSize(bgStyles[i]).x;
                            ImVec2 textPos(btnRect.x + (btnRect.z - btnRect.x - textW) / 2.0f, btnRect.y + 10);
                            ImRenderUtils::drawText(textPos, bgStyles[i], Interface::getTextColor(), 1.0f, ease_irc, false, 0, dl);
                            
                            if (isHovered && ImGui::IsMouseClicked(0)) {
                                ClientInstance::get()->playUi("random.click", 0.5f, 1.0f);
                            }
                            settingY += 45.0f;
                        }
                        
                        settingY += 20.0f;
                        ImRenderUtils::drawText(ImVec2(contentLeft + 10, settingY), "Статус подключения:", Interface::getTextColor(), 1.0f, ease_irc, false, 0, dl);
                        settingY += 30.0f;
                        
                        std::string statusText = ircConnected ? "Подключено" : "Не подключено";
                        ImColor statusColor = ircConnected ? ImColor(76, 175, 80) : ImColor(244, 67, 54);
                        ImRenderUtils::drawText(ImVec2(contentLeft + 10, settingY), statusText, statusColor, 1.0f, ease_irc, false, 0, dl);
                        
                        ImGui::SetWindowFontScale(1.0f);
                    }

                    dl->PopClipRect();

                    // Message input box at bottom (only for chat tabs)
                    if (currentIRCTab <= 1) {
                        float inputHeight = 45.0f;
                        float inputY = winPos.y + winSize.y - inputHeight - padding;
                        ImVec4 inputRect(contentLeft, inputY, contentRight, inputY + inputHeight);
                        
                        ImColor inputBg = ImColor(32, 44, 51, 200);
                        inputBg.Value.w *= ease_irc * ImRenderUtils::getGlobalAlpha();
                        dl->AddRectFilled(ImVec2(inputRect.x, inputRect.y), ImVec2(inputRect.z, inputRect.w), inputBg, 22.0f);
                        
                        ImGui::SetWindowFontScale(0.35f);
                        ImGui::SetCursorPos(ImVec2(contentLeft - winPos.x + 15, inputY - winPos.y + 8));
                        ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0, 0, 0, 0));
                        ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0, 0, 0, 0));
                        ImGui::PushStyleColor(ImGuiCol_FrameBgActive, ImVec4(0, 0, 0, 0));
                        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
                        ImGui::PushItemWidth(contentRight - contentLeft - 30);
                        if (ImGui::InputText("##ircMsg", ircMessageBuffer, sizeof(ircMessageBuffer), ImGuiInputTextFlags_EnterReturnsTrue)) {
                            if (strlen(ircMessageBuffer) > 0) {
                                // Add message to chat (WebSocket send would go here)
                                IRCMessage msg;
                                msg.sender = "You";
                                msg.text = ircMessageBuffer;
                                msg.timestamp = NOW;
                                msg.isOwn = true;
                                
                                if (currentIRCTab == 0) {
                                    friendsChatMessages.push_back(msg);
                                } else {
                                    globalChatMessages.push_back(msg);
                                }
                                
                                memset(ircMessageBuffer, 0, sizeof(ircMessageBuffer));
                                ClientInstance::get()->playUi("random.pop2", 0.6f, 1.0f);
                            }
                        }
                        ImGui::PopItemWidth();
                        ImGui::PopStyleColor(4);
                        ImGui::SetWindowFontScale(1.0f);
                    }
                }

                ImGui::End();
                ImGui::PopStyleColor(1);
                ImGui::PopStyleVar(3);
                if (ease_irc > 0.8f && ImGui::IsMouseClicked(0) && !ImRenderUtils::isMouseOver(ircModalRect)) {
                    displayIRCMenu = false;
                }
                return;
            }
        }
        
        ImVec2 searchBoxSize(160.0f, 40.0f);
        float maxCatY = 0.0f;
        for (const auto& pos : catPositions) {
            if (pos.y > maxCatY) maxCatY = pos.y;
        }
        ImVec2 searchBoxPos(
            screen.x / 2.0f - searchBoxSize.x / 2.0f,
            maxCatY + catHeight + 600.0f
        );
        static float searchSlide = 0.0f;
        float targetSlide = isEnabled ? 1.0f : 0.0f;
        {
            float spd = (targetSlide < searchSlide) ? 18.0f : 6.0f;
            searchSlide = MathUtils::animate(targetSlide, searchSlide, ImRenderUtils::getDeltaTime() * spd);
        }
        float currY = MathUtils::lerp(searchBoxPos.y - 40.0f, searchBoxPos.y, searchSlide);
        float fadeAlpha = animation * searchSlide;
        ImDrawFlags roundFlags = ImDrawFlags_RoundCornersAll;
        ImVec4 searchRect(searchBoxPos.x, currY, searchBoxPos.x + searchBoxSize.x, currY + searchBoxSize.y);
        D2D::addBlurOptimized(ImGui::GetBackgroundDrawList(), 4.0f, searchRect, 12.0f);
        ImColor searchBg = Interface::getBlurBgColor();
        ImU32 searchCol = IM_COL32((int)(searchBg.Value.x * 255.0f), (int)(searchBg.Value.y * 255.0f), (int)(searchBg.Value.z * 255.0f), (int)(204 * fadeAlpha * ImRenderUtils::getGlobalAlpha()));
        ImGui::GetBackgroundDrawList()->AddRectFilled(
            ImVec2(searchRect.x, searchRect.y),
            ImVec2(searchRect.z, searchRect.w),
            searchCol,
            12.0f,
            ImDrawFlags_RoundCornersAll
        );
        float iconSize = 16.0f;
        ImVec2 iconPos(searchBoxPos.x + 8.0f, currY + searchBoxSize.y / 2.0f - iconSize / 2.0f);

        bool hasSearchText = strlen(ModernGui::searchBuffer) > 0;

        ImColor iconColorBase = Interface::getTextColor();
        ID3D11ShaderResourceView* searchIconTexture = nullptr;
        int iconWidth = 0, iconHeight = 0;

        if (perfCache.textureCache.find("find") != perfCache.textureCache.end()) {
            searchIconTexture = perfCache.textureCache["find"];
            auto dims = perfCache.textureDimensions["find"];
            iconWidth = dims.first;
            iconHeight = dims.second;
        }

        if (searchIconTexture) {
            ImU32 iconCol = IM_COL32(
                (int)(iconColorBase.Value.x * 255.0f),
                (int)(iconColorBase.Value.y * 255.0f),
                (int)(iconColorBase.Value.z * 255.0f),
                (int)(255.0f * fadeAlpha * ImRenderUtils::getGlobalAlpha())
            );
            ImGui::GetBackgroundDrawList()->AddImage(
                searchIconTexture,
                iconPos,
                ImVec2(iconPos.x + iconSize, iconPos.y + iconSize),
                ImVec2(0, 0),
                ImVec2(1, 1),
                iconCol
            );
            drawShineBand(ImGui::GetBackgroundDrawList(), searchIconTexture, iconPos, ImVec2(iconPos.x + iconSize, iconPos.y + iconSize), fadeAlpha);
        }


        ImGui::SetNextWindowPos(ImVec2(searchBoxPos.x + 30.0f, currY));
        ImGui::SetNextWindowSize(ImVec2(searchBoxSize.x - 30.0f, searchBoxSize.y));
        ImGui::Begin("##searchbox", nullptr,
            ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground);
        ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_TextSelectedBg, ImVec4(1, 1, 1, 0.15f));
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
        ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 4.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0.0f, 0.0f));
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, fadeAlpha * ImRenderUtils::getGlobalAlpha());
        ImGui::PushItemWidth(searchBoxSize.x - 48.0f);
        float fontScale = 0.40f;
        ImGui::SetWindowFontScale(fontScale);
        float textHeight = ImGui::GetFontSize();
        float yOffset = (searchBoxSize.y - textHeight) / 2.0f;
        ImGui::SetCursorPos(ImVec2(8.0f, yOffset));
        ImGui::InputTextWithHint("##search", "Module...", ModernGui::searchBuffer, sizeof(ModernGui::searchBuffer));
        ModernGui::searchFocused = ImGui::IsItemActive();
        ImGui::SetWindowFontScale(1.0f);
        ImGui::PopItemWidth();
        ImGui::PopStyleVar(3);
        ImGui::PopStyleColor(3);
        ImGui::End();

        std::string currentSearch = StringUtils::toLower(ModernGui::searchBuffer);
        if (currentSearch != perfCache.lastSearchStr) {
            perfCache.filteredModsCache.clear();
            for (auto& cp : catPositions) { cp.scrollEase = 0.0f; cp.yOffset = 0.0f; }
            perfCache.lastSearchStr = currentSearch;
        }


    }

    for (size_t i = 0; i < categories.size(); i++)
    {
        const float modWidth = 210.f;
        const float modHeight = catHeight + 12.f;
        float modulesTopPadding = 15.f;
        float moduleY = -catPositions[i].yOffset + modulesTopPadding;

        float modulePaddingX = (catWidth - modWidth) / 2.0f;

        const auto& modsInCategory = gFeatureManager->mModuleManager->getModulesInCategory(i);
        std::vector<std::shared_ptr<Module>> sortedMods;
        if (perfCache.sortedModsCache.find(i) == perfCache.sortedModsCache.end()) {
            sortedMods = modsInCategory;
            std::sort(sortedMods.begin(), sortedMods.end(),
                [](const std::shared_ptr<Module>& a, const std::shared_ptr<Module>& b) {
                    return a->getName().length() > b->getName().length();
                });
            perfCache.sortedModsCache[i] = sortedMods;
        }
        else {
            sortedMods = perfCache.sortedModsCache[i];
        }

        std::vector<std::shared_ptr<Module>> filteredMods;
        std::string searchStr = StringUtils::toLower(ModernGui::searchBuffer);
        if (searchStr != perfCache.lastSearchStr || perfCache.filteredModsCache.find(i) == perfCache.filteredModsCache.end()) {
            filteredMods.clear();
            if (searchStr.empty()) {
                filteredMods = sortedMods;
            }
            else {
                for (const auto& mod : sortedMods) {
                    std::string modName = StringUtils::toLower(mod->getName());
                    if (modName.find(searchStr) == 0) {
                        filteredMods.push_back(mod);
                    }
                }
                for (const auto& mod : sortedMods) {
                    std::string modName = StringUtils::toLower(mod->getName());
                    if (modName.find(searchStr) != std::string::npos && modName.find(searchStr) != 0) {
                        filteredMods.push_back(mod);
                    }
                }
            }
            perfCache.filteredModsCache[i] = filteredMods;
            perfCache.lastSearchStr = searchStr;
        }
        else {
            filteredMods = perfCache.filteredModsCache[i];
        }


        ImVec4 catRect = ImVec4(catPositions[i].x, catPositions[i].y,
            catPositions[i].x + catWidth, catPositions[i].y + catHeight);
        float settingsHeight = 0;
        const float innerLeft = catPositions[i].x + (catWidth - innerWidth) / 2.0f;
        const float innerTop = catPositions[i].y + catHeight + 5.0f;
        const float innerRight = innerLeft + innerWidth;
        const float innerBottom = innerTop + innerHeight;

        for (const auto& mod : sortedMods)
        {
            if (perfCache.settingsHeightCache.find(mod.get()) == perfCache.settingsHeightCache.end()) {
                float modSettingsHeight = 0;
                for (const auto& setting : mod->mSettings) {
                    std::string __sn = StringUtils::toLower(setting->mName);
                    if (setting->mIsVisible() && __sn != "visible") {
                        modSettingsHeight += modHeight;
                        if (setting->mType == SettingType::Enum) {
                            EnumSetting* enumSetting = reinterpret_cast<EnumSetting*>(setting);
                            std::vector<std::string> vals = enumSetting->mValues;
                            if (lowercase) {
                                for (auto& v : vals) v = StringUtils::toLower(v);
                            }
                            float labelScale = 0.72f;
                            float labelH = ImGui::GetFont()->CalcTextSizeA(18.0f * labelScale, FLT_MAX, -1, setting->mName.c_str()).y;
                            float innerPadX = 10.0f;
                            float innerPadY = 2.0f;
                            float gapX = 6.0f;
                            float gapY = 6.0f;
                            float hpX = 6.0f;
                            float innerWidth = modWidth - innerPadX * 2.0f;
                            float btnH = 18.0f;
                            int lines = 0;
                            float currentLineW = 0.0f;
                            for (size_t j = 0; j < vals.size(); ++j) {
                                std::string lbl = vals[j];
                                float tw = ImRenderUtils::getTextWidth(&lbl, textSize);
                                float bw = tw + hpX * 2.0f;
                                if (currentLineW == 0.0f) {
                                    currentLineW = bw;
                                }
                                else if (currentLineW + gapX + bw <= innerWidth) {
                                    currentLineW += gapX + bw;
                                }
                                else {
                                    lines++;
                                    currentLineW = bw;
                                }
                            }
                            if (currentLineW > 0.0f) lines++;
                            float buttonsH = lines * btnH + (lines > 1 ? (lines - 1) * gapY : 0.0f);
                            float needed = innerPadY + labelH + 8.0f + buttonsH + innerPadY;
                            if (needed > modHeight) modSettingsHeight += (needed - modHeight);
                        }
                        else if (setting->mType == SettingType::MultiEnum) {
                            MultiEnumSetting* me = reinterpret_cast<MultiEnumSetting*>(setting);
                            std::vector<std::string> vals = me->mValues;
                            if (lowercase) { for (auto& v : vals) v = StringUtils::toLower(v); }
                            float labelScale = 0.72f;
                            float labelH = ImGui::GetFont()->CalcTextSizeA(18.0f * labelScale, FLT_MAX, -1, setting->mName.c_str()).y;
                            float innerPadX = 10.0f;
                            float innerPadY = 2.0f;
                            float gapX = 6.0f;
                            float gapY = 6.0f;
                            float hpX = 6.0f;
                            float innerWidth = modWidth - innerPadX * 2.0f;
                            float btnH = 18.0f;
                            int lines = 0; float currentLineW = 0.0f;
                            for (size_t j = 0; j < vals.size(); ++j) {
                                std::string lbl = vals[j];
                                float tw = ImRenderUtils::getTextWidth(&lbl, textSize);
                                float bw = tw + hpX * 2.0f;
                                if (currentLineW == 0.0f) currentLineW = bw;
                                else if (currentLineW + gapX + bw <= innerWidth) currentLineW += gapX + bw;
                                else { lines++; currentLineW = bw; }
                            }
                            if (currentLineW > 0.0f) lines++;
                            float buttonsH = lines * btnH + (lines > 1 ? (lines - 1) * gapY : 0.0f);
                            float needed = innerPadY + labelH + 8.0f + buttonsH + innerPadY;
                            if (needed > modHeight) modSettingsHeight += (needed - modHeight);
                        }
                    }
                }
                perfCache.settingsHeightCache[mod.get()] = modSettingsHeight;
            }
            settingsHeight += perfCache.settingsHeightCache[mod.get()];
        }

        float catWindowHeight = catHeight + modHeight * filteredMods.size() + settingsHeight;
        ImVec4 catWindow = ImVec4(catPositions[i].x, catPositions[i].y,
            catPositions[i].x + catWidth,
            catPositions[i].y + catTotalHeight);
        {
            float targetAlpha = catPositions[i].isExtended ? 1.0f : 0.0f;
            {
                float spd = (targetAlpha < catPositions[i].openAnimProgress) ? 28.0f : 12.5f;
                catPositions[i].openAnimProgress = MathUtils::animate(targetAlpha, catPositions[i].openAnimProgress, ImRenderUtils::getDeltaTime() * spd);
            }

            if (catPositions[i].openAnimProgress > 0.001f) {
                ImVec4 categoryBackgroundRect = ImVec4(
                    catWindow.x,
                    catWindow.y + catHeight,
                    catWindow.z,
                    catWindow.y + catHeight + (catTotalHeight - catHeight)
                );

                ImColor bgColor = Interface::getBlurBgColor();
                bgColor.Value.w *= 0.80f * catPositions[i].openAnimProgress;
                
                if (!lowPerformanceMode && animation > 0.5f && catPositions[i].openAnimProgress > 0.5f) {
                    D2D::addBlurOptimized(ImGui::GetBackgroundDrawList(), 5.0f, categoryBackgroundRect, 10.0f);
                }
                ImRenderUtils::fillRectangle(categoryBackgroundRect,
                    bgColor,
                    animation * 0.80f * catPositions[i].openAnimProgress,
                    15.0f,
                    ImGui::GetBackgroundDrawList(),
                    ImDrawFlags_RoundCornersBottom);

                ImVec4 innerBackgroundRect = ImVec4(
                    categoryBackgroundRect.x + (catWidth - innerWidth) / 2,
                    categoryBackgroundRect.y + 5.f,
                    categoryBackgroundRect.x + (catWidth - innerWidth) / 2 + innerWidth,
                    categoryBackgroundRect.y + 5.f + innerHeight
                );

                ImColor innerBgColor = Interface::getBlurBgColor();
                innerBgColor.Value.w *= 0.35f * catPositions[i].openAnimProgress;
                ImRenderUtils::fillRectangle(
                    innerBackgroundRect,
                    innerBgColor,
                    animation * 0.35f * catPositions[i].openAnimProgress,
                    12.0f,
                    ImGui::GetBackgroundDrawList(),
                    ImDrawFlags_RoundCornersAll
                );

                drawList->PushClipRect(
                    ImVec2(innerBackgroundRect.x, innerBackgroundRect.y),
                    ImVec2(innerBackgroundRect.z, innerBackgroundRect.w),
                    true
                );

                float realContentHeight = modulesTopPadding;
                for (const auto& mod : sortedMods) {
                    if (mod->getCategory() == categories[i]) {
                        realContentHeight += modHeight + moduleGap;

                        if (mod->showSettings) {
                            for (const auto& setting : mod->mSettings) {
                                std::string __sn = StringUtils::toLower(setting->mName);
                                if (setting->mIsVisible() && __sn != "visible") {
                                    if (setting->mType == SettingType::Enum) {
                                        EnumSetting* enumSetting = reinterpret_cast<EnumSetting*>(setting);
                                        std::vector<std::string> vals = enumSetting->mValues;
                                        if (lowercase) { for (auto& v : vals) v = StringUtils::toLower(v); }
                                        float labelScale = 0.85f;
                                        float labelH = ImGui::GetFont()->CalcTextSizeA(18.0f * labelScale, FLT_MAX, -1, setting->mName.c_str()).y;
                                        float innerPadX = 10.0f;
                                        float innerPadY = 2.0f;
                                        float gapX = 6.0f;
                                        float gapY = 6.0f;
                                        float hpX = 4.0f;
                                        float innerWidth = modWidth - innerPadX * 2.0f;
                                        float btnH = 18.0f;
                                        float enumTextScale = textSize * 0.85f;
                                        int lines = 0; float currentLineW = 0.0f;
                                        for (size_t j = 0; j < vals.size(); ++j) {
                                            std::string lbl = vals[j];
                                            float tw = ImRenderUtils::getTextWidth(&lbl, enumTextScale);
                                            float bw = tw + hpX * 2.0f;
                                            if (currentLineW == 0.0f) currentLineW = bw;
                                            else if (currentLineW + gapX + bw <= innerWidth) currentLineW += gapX + bw;
                                            else { lines++; currentLineW = bw; }
                                        }
                                        if (currentLineW > 0.0f) lines++;
                                        float buttonsH = lines * btnH + (lines > 1 ? (lines - 1) * gapY : 0.0f);
                                        float needed = innerPadY + labelH + 8.0f + buttonsH + innerPadY;
                                        realContentHeight += std::max(modHeight, needed);
                                    }
                                    else if (setting->mType == SettingType::MultiEnum) {
                                        MultiEnumSetting* me = reinterpret_cast<MultiEnumSetting*>(setting);
                                        std::vector<std::string> vals = me->mValues;
                                        if (lowercase) { for (auto& v : vals) v = StringUtils::toLower(v); }
                                        float labelScale = 0.85f;
                                        float labelH = ImGui::GetFont()->CalcTextSizeA(18.0f * labelScale, FLT_MAX, -1, setting->mName.c_str()).y;
                                        float innerPadX = 6.0f;
                                        float innerPadY = 2.0f;
                                        float gapX = 6.0f;
                                        float gapY = 6.0f;
                                        float hpX = 4.0f;
                                        float innerWidth = modWidth - innerPadX * 2.0f;
                                        float btnH = 18.0f;
                                        float enumTextScale = textSize * 0.85f;
                                        int lines = 0; float currentLineW = 0.0f;
                                        for (size_t j = 0; j < vals.size(); ++j) {
                                            std::string lbl = vals[j];
                                            float tw = ImRenderUtils::getTextWidth(&lbl, enumTextScale);
                                            float bw = tw + hpX * 2.0f;
                                            if (currentLineW == 0.0f) currentLineW = bw;
                                            else if (currentLineW + gapX + bw <= innerWidth) currentLineW += gapX + bw;
                                            else { lines++; currentLineW = bw; }
                                        }
                                        if (currentLineW > 0.0f) lines++;
                                        float buttonsH = lines * btnH + (lines > 1 ? (lines - 1) * gapY : 0.0f);
                                        float needed = innerPadY + labelH + 8.0f + buttonsH + innerPadY;
                                        realContentHeight += std::max(modHeight, needed);
                                    }
                                    else {
                                        realContentHeight += modHeight;
                                    }
                                }
                            }
                        }
                    }
                }

                float visibleHeight = innerHeight;
                float maxScroll = std::max(0.f, realContentHeight - visibleHeight);
                float computedMaxScroll = std::max(0.f, realContentHeight - innerHeight);

                if (realContentHeight > visibleHeight)
                {
                    float scrollbarWidth = 4.0f;
                    float visibleRatio = visibleHeight / realContentHeight;
                    float scrollbarHeight = visibleHeight * visibleRatio;
                    float scrollProgress = catPositions[i].scrollEase / maxScroll;


                    ImVec4 scrollbarBg = ImVec4(
                        categoryBackgroundRect.z - scrollbarWidth - 4.0f,
                        innerBackgroundRect.y + 2.0f,
                        categoryBackgroundRect.z - 4.0f,
                        innerBackgroundRect.w - 2.0f
                    );

                    float scrollbarY = scrollbarBg.y + (scrollbarBg.w - scrollbarBg.y - scrollbarHeight) * scrollProgress;

                    ImVec4 scrollbarRect = ImVec4(
                        scrollbarBg.x,
                        scrollbarY,
                        scrollbarBg.z,
                        scrollbarY + scrollbarHeight
                    );

                    ImRenderUtils::fillRectangle(scrollbarBg,
                        Interface::getBlurBgColor(),
                        animation * 0.35f,
                        8.0f);

                    ImRenderUtils::fillRectangle(scrollbarRect,
                        getCachedThemedColor(i * 20),
                        animation,
                        8.0f);

                    if (!catPositions[i].isDraggingScrollbar && ImRenderUtils::isMouseOver(scrollbarRect) && ImGui::IsMouseClicked(0))
                    {
                        catPositions[i].isDraggingScrollbar = true;
                        catPositions[i].dragStartY = ImGui::GetIO().MousePos.y;
                        catPositions[i].scrollStartValue = catPositions[i].scrollEase;
                    }

                    if (catPositions[i].isDraggingScrollbar)
                    {
                        if (ImGui::IsMouseDown(0))
                        {
                            float dragDelta = ImGui::GetIO().MousePos.y - catPositions[i].dragStartY;
                            float scrollRange = scrollbarBg.w - scrollbarBg.y - scrollbarHeight;
                            float scrollDelta = (dragDelta / scrollRange) * maxScroll;

                            catPositions[i].scrollEase = std::clamp(catPositions[i].scrollStartValue + scrollDelta, 0.0f, maxScroll);
                        }
                        else
                        {
                            catPositions[i].isDraggingScrollbar = false;
                        }
                    }

                    if (ImRenderUtils::isMouseOver(innerBackgroundRect) && !catPositions[i].isDraggingScrollbar)
                    {
                        if (scrollDirection != 0)
                        {
                            float scrollSpeed = modHeight * 1.0f;
                            catPositions[i].scrollEase = std::clamp(
                                catPositions[i].scrollEase + scrollDirection * scrollSpeed,
                                0.0f,
                                maxScroll
                            );
                            scrollDirection = 0;
                        }
                    }
                }
                else
                {
                    catPositions[i].scrollEase = 0;
                }


            }
        }

        ImColor rgb = getCachedThemedColor(i * 20);

        if (false && ImRenderUtils::isMouseOver(catWindow) && catPositions[i].isExtended)
        {
            float contentHeight = catWindowHeight;
            float maxScroll = std::max(0.f, contentHeight - (catTotalHeight - catHeight));

            if (scrollDirection > 0)
            {
                catPositions[i].scrollEase += scrollDirection * catHeight;
                if (catPositions[i].scrollEase > maxScroll)
                    catPositions[i].scrollEase = maxScroll;
            }
            else if (scrollDirection < 0)
            {
                catPositions[i].scrollEase += scrollDirection * catHeight;
                if (catPositions[i].scrollEase < 0)
                    catPositions[i].scrollEase = 0;
            }
            scrollDirection = 0;

            if (contentHeight > (catTotalHeight - catHeight))
            {
                float scrollbarWidth = 4.0f;
                float visibleRatio = (catTotalHeight - catHeight) / contentHeight;
                float scrollbarHeight = (catWindow.w - catWindow.y - catHeight) * visibleRatio;
                float scrollProgress = catPositions[i].scrollEase / maxScroll;

                ImVec4 scrollbarBg = ImVec4(
                    catWindow.z - scrollbarWidth - 4.0f,
                    catWindow.y + catHeight + 2.0f,
                    catWindow.z - 4.0f,
                    catWindow.w - 2.0f
                );

                ImRenderUtils::fillRectangle(scrollbarBg,
                    ImColor(15, 15, 15, 100),
                    animation * 0.80f,
                    8.0f);


                float scrollbarY = catWindow.y + catHeight + 2.0f +
                    (catWindow.w - catWindow.y - scrollbarHeight - catHeight - 4.0f) * scrollProgress;

                ImVec4 scrollbarRect = ImVec4(
                    scrollbarBg.x,
                    scrollbarY,
                    scrollbarBg.z,
                    scrollbarY + scrollbarHeight
                );

                ImRenderUtils::fillRectangle(scrollbarRect,
                    getCachedThemedColor(i * 20),
                    animation,
                    8.0f);
            }
        }

        if (!catPositions[i].isExtended)
        {
            catPositions[i].scrollEase = catWindowHeight - catHeight;
            catPositions[i].wasExtended = false;
            catPositions[i].backgroundHeight = 0.f;
        }
        else if (!catPositions[i].wasExtended)
        {
            catPositions[i].scrollEase = 0;
            catPositions[i].wasExtended = true;
        }

        catPositions[i].yOffset = MathUtils::animate(catPositions[i].scrollEase, catPositions[i].yOffset,
            ImRenderUtils::getDeltaTime() * 10.5);

        ImVec4 clipRect = ImVec4(
            innerLeft,
            innerTop - 0.5f,
            innerRight,
            innerBottom + 0.5f
        );
        drawList->PushClipRect(ImVec2(clipRect.x, clipRect.y), ImVec2(clipRect.z, clipRect.w), true);

        int modIndex = 0;
        int modCount = filteredMods.size();
        bool endMod = false;
        bool moduleToggled = false;
        for (const auto& mod : filteredMods)
        {
            float modY = catPositions[i].y + catHeight + moduleY;
            float approxSettingsHeight = 0.0f;
            auto itCached = perfCache.settingsHeightCache.find(mod.get());
            if (itCached != perfCache.settingsHeightCache.end()) {
                approxSettingsHeight = itCached->second;
            }
            else {
                for (const auto& setting : mod->mSettings) {
                    std::string __sn = StringUtils::toLower(setting->mName);
                    if (setting->mIsVisible() && __sn != "visible") {
                        approxSettingsHeight += modHeight;
                        if (setting->mType == SettingType::Enum) {
                            EnumSetting* enumSetting = reinterpret_cast<EnumSetting*>(setting);
                            std::vector<std::string> vals = enumSetting->mValues;
                            if (lowercase) { for (auto& v : vals) v = StringUtils::toLower(v); }
                            float labelScale = 0.72f;
                            float labelH = ImGui::GetFont()->CalcTextSizeA(18.0f * labelScale, FLT_MAX, -1, setting->mName.c_str()).y;
                            float innerPadX = 10.0f;
                            float innerPadY = 2.0f;
                            float gapX = 6.0f;
                            float gapY = 6.0f;
                            float hpX = 6.0f;
                            float innerWidth = modWidth - innerPadX * 2.0f;
                            float btnH = 18.0f;
                            int lines = 0; float currentLineW = 0.0f;
                            for (size_t j = 0; j < vals.size(); ++j) {
                                std::string lbl = vals[j];
                                float tw = ImRenderUtils::getTextWidth(&lbl, textSize);
                                float bw = tw + hpX * 2.0f;
                                if (currentLineW == 0.0f) currentLineW = bw;
                                else if (currentLineW + gapX + bw <= innerWidth) currentLineW += gapX + bw;
                                else { lines++; currentLineW = bw; }
                            }
                            if (currentLineW > 0.0f) lines++;
                            float buttonsH = lines * btnH + (lines > 1 ? (lines - 1) * gapY : 0.0f);
                            float needed = innerPadY + labelH + 8.0f + buttonsH + innerPadY;
                            if (needed > modHeight) approxSettingsHeight += (needed - modHeight);
                        }
                        else if (setting->mType == SettingType::MultiEnum) {
                            MultiEnumSetting* me = reinterpret_cast<MultiEnumSetting*>(setting);
                            std::vector<std::string> vals = me->mValues;
                            if (lowercase) { for (auto& v : vals) v = StringUtils::toLower(v); }
                            float labelScale = 0.72f;
                            float labelH = ImGui::GetFont()->CalcTextSizeA(18.0f * labelScale, FLT_MAX, -1, setting->mName.c_str()).y;
                            float innerPadX = 10.0f;
                            float innerPadY = 2.0f;
                            float gapX = 6.0f;
                            float gapY = 6.0f;
                            float hpX = 6.0f;
                            float innerWidth = modWidth - innerPadX * 2.0f;
                            float btnH = 18.0f;
                            int lines = 0; float currentLineW = 0.0f;
                            for (size_t j = 0; j < vals.size(); ++j) {
                                std::string lbl = vals[j];
                                float tw = ImRenderUtils::getTextWidth(&lbl, textSize);
                                float bw = tw + hpX * 2.0f;
                                if (currentLineW == 0.0f) currentLineW = bw;
                                else if (currentLineW + gapX + bw <= innerWidth) currentLineW += gapX + bw;
                                else { lines++; currentLineW = bw; }
                            }
                            if (currentLineW > 0.0f) lines++;
                            float buttonsH = lines * btnH + (lines > 1 ? (lines - 1) * gapY : 0.0f);
                            float needed = innerPadY + labelH + 8.0f + buttonsH + innerPadY;
                            if (needed > modHeight) approxSettingsHeight += (needed - modHeight);
                        }
                    }
                }
            }

            float totalBlockHeight = modHeight + approxSettingsHeight * (1.0f - powf(1.0f - mod->cAnim, 3.0f));
            const float edgeSlackMod = 2.0f;
            if (modY > innerBottom + edgeSlackMod || (modY + totalBlockHeight) < innerTop - edgeSlackMod) {
                moduleY += totalBlockHeight + moduleGap;
                modIndex++;
                continue;
            }

            ImDrawFlags flags = ImDrawFlags_RoundCornersBottom;
            float radius = 0.f;
            if (modIndex == filteredMods.size() - 1) {
                endMod = true;
                radius = 15.f * (1.f - mod->cAnim);
            }

            

            ImColor rgb = getCachedThemedColor(static_cast<int>(moduleY * 2));

            if (mod->getCategory() == categories[i])
            {
                ImVec4 modRect = ImVec4(
                    catPositions[i].x + modulePaddingX,
                    catPositions[i].y + catHeight + moduleY,
                    catPositions[i].x + modulePaddingX + modWidth,
                    catPositions[i].y + catHeight + moduleY + moduleHeight);
                modRect.y = std::floor(modRect.y);
                modRect.x = std::floor(modRect.x);
                modRect.w = std::floor(modRect.w);
                float targetAnim = mod->showSettings ? 1.f : 0.f;
                if (abs(targetAnim - mod->cAnim) > 0.001f) {
                    float animSpeed = (targetAnim < mod->cAnim) ? 18.0f : 16.0f;
                    mod->cAnim = MathUtils::animate(targetAnim, mod->cAnim, ImRenderUtils::getDeltaTime() * animSpeed);
                    mod->cAnim = MathUtils::clamp(mod->cAnim, 0.f, 1.f);
                }
                float openEase = 1.0f - powf(1.0f - mod->cAnim, 3.0f);
                
                
                ImColor __bgA = Interface::getBlurBgColor();
                ImColor __bgB = ImColor(30, 30, 30);
                ImColor setBg = MathUtils::lerpImColor(__bgA, __bgB, openEase);
                
                float __colorAnim = 0.0f;
                {
                    auto itColor = perfCache.moduleColorAnims.find(mod.get());
                    if (itColor != perfCache.moduleColorAnims.end()) __colorAnim = itColor->second;
                    else if (mod->mEnabled) __colorAnim = 1.0f; 
                }
                float __lighten = 0.16f * __colorAnim;
                setBg.Value.x = std::min(1.0f, setBg.Value.x + __lighten);
                setBg.Value.y = std::min(1.0f, setBg.Value.y + __lighten);
                setBg.Value.z = std::min(1.0f, setBg.Value.z + __lighten);
                bool isClosingPhase = false;
                {
                    auto itPrev = prevCAnim.find(mod.get());
                    if (itPrev != prevCAnim.end()) {
                        isClosingPhase = (mod->cAnim < itPrev->second - 0.0001f);
                    }
                }
                if (isClosingPhase) {
                    closingRoundHoldUntil[mod.get()] = NOW + 450;
                }
                if (mod->showSettings) {
                    closingRoundHoldUntil[mod.get()] = 0;
                }
                if (openEase > 0.001f)
                {
                    Setting* lastDraggedSetting = nullptr;
                    int sIndex = 0;
                    Setting* lastVisibleSettingForRounding = nullptr;
                    for (int __i = static_cast<int>(mod->mSettings.size()) - 1; __i >= 0; --__i) {
                        Setting* __s = mod->mSettings[__i];
                        std::string __snCheck = StringUtils::toLower(__s->mName);
                        if (__s->mIsVisible() && __snCheck != "visible") { lastVisibleSettingForRounding = __s; break; }
                    }
                    bool firstVisibleSetting = true;
                    for (const auto& setting : mod->mSettings)
                    {
                        std::string __sn = StringUtils::toLower(setting->mName);
                        if (!setting->mIsVisible() || __sn == "visible")
                        {
                            setting->sliderEase = 0;
                            setting->enumSlide = 0;
                            continue;
                        }



                        float radius = 0.f;
                        if (endMod && sIndex == mod->mSettings.size() - 1)
                            radius = 15.f;
                        else if (endMod)
                            radius = 15.f * (1.f - mod->cAnim);

                        bool endSetting = sIndex == mod->mSettings.size() - 1;
                        float setPadding = 0.f;

                        ImColor rgb = getCachedThemedColor(static_cast<int>(moduleY * 2));
                        rgb.Value.w = 1.0f;
                        switch (setting->mType)

                        {
                        case SettingType::Bool:
                        {
                            BoolSetting* boolSetting = reinterpret_cast<BoolSetting*>(setting);
                            moduleY += MathUtils::lerp(0.0f, modHeight, openEase);

                            ImVec4 rect = ImVec4(
                                modRect.x, catPositions[i].y + catHeight + moduleY + setPadding, modRect.z,
                                catPositions[i].y + catHeight + moduleY + modHeight);
                            rect.x = std::floor(rect.x);
                            rect.y = std::floor(rect.y);
                            rect.z = std::floor(rect.z);
                            rect.w = std::floor(rect.y + modHeight);
                            if (firstVisibleSetting) {
                                float targetY = rect.y;
                                rect.y = std::floor(MathUtils::lerp(modRect.w, targetY, openEase));
                                rect.w = std::floor(rect.y + modHeight);
                                firstVisibleSetting = false;
                            }
                            bool withinVertical = (rect.y < (catWindow.y + catTotalHeight)) && (rect.w > (catWindow.y + catHeight));

                            if (rect.y < innerBottom && rect.w > innerTop)
                            {
                                std::string setName;
                                if (lowercase) {
                                    auto itLS = perfCache.lowerSettingNames.find(setting);
                                    if (itLS == perfCache.lowerSettingNames.end()) {
                                        perfCache.lowerSettingNames[setting] = StringUtils::toLower(setting->mName);
                                    }
                                    setName = perfCache.lowerSettingNames[setting];
                                }
                                else {
                                    setName = setting->mName;
                                }
                                bool isSettingHovered = ImRenderUtils::isMouseOver(rect) && isEnabled && catPositions[i].isExtended;
                                bool isLastForRound = (setting == lastVisibleSettingForRounding);
                                float roundRadius = isLastForRound ? 10.0f : 0.0f;
                                ImDrawFlags roundFlags = isLastForRound ? ImDrawFlags_RoundCornersBottom : 0;
                                float elemAlpha = openEase * animation;
                                ImColor setBgWithAlpha = setBg;
                                setBgWithAlpha.Value.w = 0.35f;
                                ImRenderUtils::fillRectangle(rect, setBgWithAlpha, elemAlpha * 0.35f, roundRadius, ImGui::GetBackgroundDrawList(), roundFlags);

                                if (ImRenderUtils::isMouseOver(rect) && isEnabled && catPositions[i].isExtended)
                                {
                                    bool hoverWithinVertical = (rect.y < innerBottom) && (rect.w > innerTop);
                                    if (hoverWithinVertical)
                                    {
                                        tooltip = setting->mDescription;
                                        if (ImGui::IsMouseClicked(0) && !displayColorPicker && mod->showSettings)
                                        {
                                            bool old = boolSetting->mValue;
                                            boolSetting->mValue = !old;
                                            if (boolSetting->mValue != old)
                                                ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f);
                                        }

                                        if (ImGui::IsMouseClicked(2) && !displayColorPicker && catPositions[i].isExtended)
                                        {
                                            lastBoolSetting = boolSetting;
                                            isBoolSettingBinding = true;
                                            ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f);
                                        }
                                    }
                                }

                                float targetBoolScale = boolSetting->mValue ? 1.0f : 0.0f;
                                if (abs(targetBoolScale - setting->boolScale) > 0.001f) {
                                    setting->boolScale = MathUtils::animate(
                                        targetBoolScale, setting->boolScale,
                                        ImRenderUtils::getDeltaTime() * 10);
                                }

                                float scaledWidth = rect.z - rect.x;
                                float scaledHeight = rect.w - rect.y;

                                ImVec2 center = ImVec2(rect.x + (rect.z - rect.x) / 2.f, rect.y + (rect.w - rect.y) / 2.f);
                                ImVec4 scaledRect = ImVec4(center.x - scaledWidth / 2.f, center.y - scaledHeight / 2.f, center.x + scaledWidth / 2.f, center.y + scaledHeight / 2.f);

                                float cSetRectCentreX = rect.x + ((rect.z - rect.x) - ImRenderUtils::getTextWidth(&setName, textSize)) / 2;
                                float cSetRectCentreY = rect.y + ((rect.w - rect.y) - textHeight) / 2.0f;
                                float rowCenterY = rect.y + (rect.w - rect.y) * 0.5f;

                                ImVec4 smoothScaledRect = ImVec4(scaledRect.z - 19, scaledRect.y + 5, scaledRect.z - 5, scaledRect.w - 5);
                                ImVec2 circleRect = ImVec2(smoothScaledRect.getCenter().x, smoothScaledRect.getCenter().y);

                                float toggleRadius = 6.0f;
                                float toggleWidth = 30.0f;
                                float toggleHeight = 15.0f;
                                float rightMargin = 10.0f;
                                ImVec4 booleanRect = ImVec4(rect.z - rightMargin - toggleWidth, rowCenterY - toggleHeight / 2.0f, rect.z - rightMargin, rowCenterY + toggleHeight / 2.0f);
                                booleanRect = booleanRect.scaleToPoint(ImVec4(rect.z, rect.y, rect.z, rect.w), 1.0f);

                                ImVec2 toggleCenter = ImVec2(booleanRect.getCenter().x, booleanRect.getCenter().y);
                                ImVec4 toggleBg = ImVec4(toggleCenter.x - toggleWidth / 2, toggleCenter.y - toggleHeight / 2,
                                    toggleCenter.x + toggleWidth / 2, toggleCenter.y + toggleHeight / 2);

                                
                                bool toggleHovered = ImRenderUtils::isMouseOver(toggleBg) && isEnabled && !displayColorPicker && mod->showSettings && catPositions[i].isExtended;
                                ImVec4 v = rgb.Value;
                                ImColor selNormal(v.x * 0.90f, v.y * 0.90f, v.z * 0.90f, v.w);
                                ImColor selHover(v.x * 1.00f, v.y * 1.00f, v.z * 1.00f, v.w);
                                ImColor offNormal = setBg;
                                offNormal.Value.w = 210.0f / 255.0f;
                                ImColor offHover = setBg;
                                offHover.Value.w = 230.0f / 255.0f;
                                offHover.Value.x = std::min(1.0f, offHover.Value.x + 0.06f);
                                offHover.Value.y = std::min(1.0f, offHover.Value.y + 0.06f);
                                offHover.Value.z = std::min(1.0f, offHover.Value.z + 0.06f);

                                size_t keyToggle = ((size_t)setting ^ 0x9E3779B97F4A7C15ull);
                                float targetHover = toggleHovered ? 1.0f : 0.0f;
                                float currentHover = 0.0f;
                                {
                                    auto itAnim = enumHoverAnim.find(keyToggle);
                                    if (itAnim != enumHoverAnim.end()) currentHover = itAnim->second;
                                }
                                currentHover = MathUtils::animate(targetHover, currentHover, ImRenderUtils::getDeltaTime() * 10.0f);
                                enumHoverAnim[keyToggle] = currentHover;

                                ImColor baseNormal = boolSetting->mValue ? selNormal : offNormal;
                                ImColor baseHover = boolSetting->mValue ? selHover : offHover;
                                ImColor bgColor = MathUtils::lerpImColor(baseNormal, baseHover, currentHover);
                                ImRenderUtils::fillRectangle(toggleBg, bgColor, elemAlpha * 0.35f, toggleHeight / 2);

                                float circleX = boolSetting->mValue ?
                                    toggleBg.z - toggleRadius - 2.0f :
                                    toggleBg.x + toggleRadius + 2.0f;

                                circleX = MathUtils::lerp(
                                    toggleBg.x + toggleRadius + 2.0f,
                                    toggleBg.z - toggleRadius - 2.0f,
                                    setting->boolScale
                                );

                                ImVec2 circlePos = ImVec2(circleX, toggleCenter.y);
                                ImRenderUtils::fillCircle(circlePos, toggleRadius, ImColor(255, 255, 255),
                                    elemAlpha, 12);

                                
                                float labelY = rowCenterY - (textHeight * 0.5f);
                                ImRenderUtils::drawText(ImVec2(rect.x + 10.f, labelY), setName,
                                    Interface::getTextColor(), textSize, elemAlpha, false);
                            }
                            break;
                        }
                        case SettingType::MultiEnum:
                        {
                            MultiEnumSetting* me = reinterpret_cast<MultiEnumSetting*>(setting);
                            std::string setName = lowercase ? StringUtils::toLower(setting->mName) : setting->mName;
                            std::vector<std::string> values = me->mValues;
                            if (lowercase) {
                                for (std::string& v : values) v = StringUtils::toLower(v);
                            }

                            moduleY += MathUtils::lerp(0.0f, modHeight, openEase);

                            ImVec4 rect = ImVec4(
                                modRect.x, catPositions[i].y + catHeight + moduleY + setPadding, modRect.z,
                                catPositions[i].y + catHeight + moduleY + modHeight);
                            rect.y = std::floor(rect.y);
                            if (rect.w > innerTop && rect.y < innerBottom)
                            {
                                bool isLastForRound = (setting == lastVisibleSettingForRounding);
                                float roundRadius = isLastForRound ? 10.0f : 0.0f;
                                ImDrawFlags roundFlags = isLastForRound ? ImDrawFlags_RoundCornersBottom : 0;
                                float elemAlpha = openEase * animation;
                                ImColor enumBgWithAlpha = setBg;
                                enumBgWithAlpha.Value.w = 0.35f;

                                if (ImRenderUtils::isMouseOver(rect) && isEnabled && catPositions[i].isExtended) {
                                    bool withinVerticalMain = (rect.y < innerBottom) && (rect.w > innerTop);
                                    if (withinVerticalMain) tooltip = setting->mDescription;
                                }

                                float labelScale = 0.85f;
                                float labelH = ImGui::GetFont()->CalcTextSizeA(18.0f * labelScale, FLT_MAX, -1, setName.c_str()).y;
                                float innerPadX = 10.0f;
                                float innerPadY = 2.0f;
                                float gapX = 6.0f;
                                float gapY = 6.0f;
                                float hpX = 4.0f;
                                float topPad = firstVisibleSetting ? 0.0f : innerPadY;
                                float labelSpacingT = firstVisibleSetting ? 4.0f : 8.0f;

                                float innerLeft = rect.x + innerPadX;
                                float innerRight = rect.z - innerPadX;
                                float innerWidth = std::max(0.0f, innerRight - innerLeft);

                                float enumTextScale = textSize * 0.85f;
                                int count = static_cast<int>(values.size());
                                int lines = 0; float lineW = 0.0f;
                                for (int j = 0; j < count; ++j) {
                                    std::string lbl = values[j];
                                    float tw_btn = ImRenderUtils::getTextWidth(&lbl, enumTextScale);
                                    float bw = tw_btn + hpX * 2.0f;
                                    if (lineW == 0.0f) lineW = bw;
                                    else if (lineW + gapX + bw <= innerWidth) lineW += gapX + bw;
                                    else { lines++; lineW = bw; }
                                }
                                if (lineW > 0.0f) lines++;

                                float btnH = 18.0f;
                                float buttonsH = lines * btnH + (lines > 1 ? (lines - 1) * gapY : 0.0f);
                                float rowHeight = std::max(modHeight, topPad + labelH + labelSpacingT + buttonsH + innerPadY);
                                float enumTextHeight = ImGui::GetFont()->CalcTextSizeA(18.0f * enumTextScale, FLT_MAX, -1, "").y;
                                float animRowHeight = MathUtils::lerp(modHeight, rowHeight, openEase);
                                float animRowHeightPx = std::floor(animRowHeight);

                                ImVec4 rowRect = rect;
                                rowRect.y = std::floor(rowRect.y);
                                rowRect.w = std::floor(rowRect.y + animRowHeightPx);
                                if (firstVisibleSetting) {
                                    float origY = rowRect.y;
                                    rowRect.y = MathUtils::lerp(modRect.w, origY, openEase);
                                    rowRect.y = std::floor(rowRect.y);
                                    rowRect.w = std::floor(rowRect.y + animRowHeightPx);
                                    firstVisibleSetting = false;
                                }

                                const float edgeSlack = 2.0f;
                                if (rowRect.y > innerBottom + edgeSlack || rowRect.w < innerTop - edgeSlack) {
                                    float extraH_skip_px = (animRowHeightPx - modHeight);
                                    if (extraH_skip_px > 0.0f) moduleY += extraH_skip_px;
                                    sIndex++;
                                    break;
                                }

                                ImRenderUtils::fillRectangle(rowRect, enumBgWithAlpha, elemAlpha * 0.35f, roundRadius, ImGui::GetBackgroundDrawList(), roundFlags);
                                ImRenderUtils::drawText(ImVec2(innerLeft, rowRect.y + topPad), setName, Interface::getTextColor(), labelScale, elemAlpha, false);

                                float rowInnerTop = std::floor(rowRect.y + topPad + labelH + labelSpacingT);
                                float rowInnerBottom = rowRect.w - innerPadY;

                                
                                bool isUiTheme = (StringUtils::toLower(mod->getName()) == "interface" && StringUtils::toLower(setting->mName) == "ui theme");
                                if (isUiTheme) {
                                    
                                    ImVec4 segRect(innerLeft, rowInnerTop, innerRight, rowInnerTop + 24.0f);
                                    ImColor baseBg = setBg; baseBg.Value.w = 0.35f;
                                    ImRenderUtils::fillRectangle(segRect, baseBg, elemAlpha * 0.35f, 8.0f);

                                    size_t keySel = ((size_t)setting ^ 0xBEEFCAFEu);
                                    float selCurr = 0.0f;
                                    auto itSel = enumSelectAnim.find(keySel);
                                    if (itSel != enumSelectAnim.end()) selCurr = itSel->second;
                                    
                                    auto* themeSetting = reinterpret_cast<EnumSettingT<Interface::UiTheme>*>(setting);
                                    float selTarget = (themeSetting->mValue == Interface::UiTheme::Light) ? 1.0f : 0.0f;
                                    selCurr = MathUtils::animate(selTarget, selCurr, ImRenderUtils::getDeltaTime() * 10.0f);
                                    enumSelectAnim[keySel] = selCurr;

                                    float halfW = (segRect.z - segRect.x) * 0.5f;
                                    float selX = segRect.x + selCurr * halfW;
                                    ImVec4 hiRect(selX, segRect.y, selX + halfW, segRect.w);
                                    ImColor hiCol = rgb; hiCol.Value.w = 0.55f;
                                    ImRenderUtils::fillRectangle(hiRect, hiCol, elemAlpha * 0.55f, 8.0f);

                                    
                                    ImColor onTxt = Interface::getTextColor();
                                    ImColor offTxt = (onTxt.Value.x > 0.5f ? ImColor(200, 200, 200) : ImColor(60, 60, 60));
                                    float darkCx = segRect.x + halfW * 0.5f;
                                    float lightCx = segRect.x + halfW * 1.5f;
                                    std::string dLbl = "Dark";
                                    std::string lLbl = "Light";
                                    float th = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, dLbl.c_str()).y;
                                    ImVec2 dPos(darkCx - ImRenderUtils::getTextWidth(&dLbl, textSize) * 0.5f, segRect.y + (24.0f - th) * 0.5f);
                                    ImVec2 lPos(lightCx - ImRenderUtils::getTextWidth(&lLbl, textSize) * 0.5f, segRect.y + (24.0f - th) * 0.5f);
                                    
                                    ImColor dCol = MathUtils::lerpImColor(offTxt, onTxt, 1.0f - selCurr);
                                    ImColor lCol = MathUtils::lerpImColor(offTxt, onTxt, selCurr);
                                    ImRenderUtils::drawText(dPos, dLbl, dCol, textSize, elemAlpha, false);
                                    ImRenderUtils::drawText(lPos, lLbl, lCol, textSize, elemAlpha, false);

                                    
                                    ImVec4 leftRect(segRect.x, segRect.y, segRect.x + halfW, segRect.w);
                                    ImVec4 rightRect(segRect.x + halfW, segRect.y, segRect.z, segRect.w);
                                    bool leftHovered = ImRenderUtils::isMouseOver(leftRect) && isEnabled && catPositions[i].isExtended;
                                    bool rightHovered = ImRenderUtils::isMouseOver(rightRect) && isEnabled && catPositions[i].isExtended;
                                    if (leftHovered && ImGui::IsMouseClicked(0)) { themeSetting->setValue(Interface::UiTheme::Dark); ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f); }
                                    if (rightHovered && ImGui::IsMouseClicked(0)) { themeSetting->setValue(Interface::UiTheme::Light); ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f); }
                                }
                                else if (count > 0) {
                                    float currentX = innerLeft;
                                    float currentY = rowInnerTop;
                                    for (int j = 0; j < count; ++j)
                                    {
                                        std::string label = values[j];
                                        float tw_btn = ImRenderUtils::getTextWidth(&label, enumTextScale);
                                        float btnW = tw_btn + hpX * 2.0f;

                                        if (currentX + btnW > innerRight + 0.5f) {
                                            currentX = innerLeft;
                                            currentY = currentY + btnH + gapY;
                                        }

                                        float bx1 = std::floor(currentX);
                                        float bx2 = std::floor(bx1 + btnW);
                                        ImVec4 btnRect(bx1, currentY, bx2, currentY + btnH);

                                        bool hovered = ImRenderUtils::isMouseOver(btnRect) && isEnabled && !displayColorPicker && mod->showSettings && catPositions[i].isExtended;
                                        bool selected = me->hasValue(j);

                                        ImVec4 v = rgb.Value;
                                        ImColor selNormal(v.x * 0.90f, v.y * 0.90f, v.z * 0.90f, v.w);
                                        ImColor selHover(v.x * 1.00f, v.y * 1.00f, v.z * 1.00f, v.w);
                                        
                                        ImColor offNormal = setBg;
                                        ImColor offHover = setBg;
                                        
                                        offNormal.Value.w = 210.0f / 255.0f;
                                        offHover.Value.w = 230.0f / 255.0f;
                                        
                                        offHover.Value.x = std::min(1.0f, offHover.Value.x + 0.06f);
                                        offHover.Value.y = std::min(1.0f, offHover.Value.y + 0.06f);
                                        offHover.Value.z = std::min(1.0f, offHover.Value.z + 0.06f);

                                        size_t selKey = ((size_t)me << 1) ^ ((size_t)j * 2654435761u);
                                        float selTarget = selected ? 1.0f : 0.0f;
                                        float selCurrent = 0.0f;
                                        auto itSel = enumSelectAnim.find(selKey);
                                        if (itSel != enumSelectAnim.end()) selCurrent = itSel->second;
                                        selCurrent = MathUtils::animate(selTarget, selCurrent, ImRenderUtils::getDeltaTime() * 10.0f);
                                        enumSelectAnim[selKey] = selCurrent;

                                        ImColor baseNormal = MathUtils::lerpImColor(offNormal, selNormal, selCurrent);
                                        ImColor baseHover = MathUtils::lerpImColor(offHover, selHover, selCurrent);

                                        size_t key = (size_t)me ^ ((size_t)j * 2654435761u);
                                        float target = hovered ? 1.0f : 0.0f;
                                        float current = 0.0f;
                                        auto itAnim = enumHoverAnim.find(key);
                                        if (itAnim != enumHoverAnim.end()) current = itAnim->second;
                                        current = MathUtils::animate(target, current, ImRenderUtils::getDeltaTime() * 10.0f);
                                        enumHoverAnim[key] = current;

                                        ImColor btnBg = MathUtils::lerpImColor(baseNormal, baseHover, current);
                                        ImRenderUtils::fillRectangle(btnRect, btnBg, elemAlpha * 0.35f, 6.0f);

                                        float tx = std::floor(bx1 + (btnW - tw_btn) / 2.0f);
                                        float ty = std::floor(currentY + (btnH - enumTextHeight) / 2.0f);
                                        ImColor onText = Interface::getTextColor();
                                        ImColor offText = (onText.Value.x > 0.5f ? ImColor(200, 200, 200) : ImColor(60, 60, 60));
                                        ImColor tcol = MathUtils::lerpImColor(offText, onText, selCurrent);
                                        ImRenderUtils::drawText(ImVec2(tx, ty), label, tcol, enumTextScale, elemAlpha, false);

                                        if (hovered && ImGui::IsMouseClicked(0)) {
                                            me->toggleValue(j);
                                            ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f);
                                        }

                                        currentX = currentX + btnW + gapX;
                                    }
                                }

                                float extraH_px = (animRowHeightPx - modHeight);
                                if (extraH_px > 0.0f) moduleY += extraH_px;
                            }
                            break;
                        }
                        case SettingType::Enum:
                        {
                            EnumSetting* enumSetting = reinterpret_cast<EnumSetting*>(setting);
                            std::string setName = lowercase ? StringUtils::toLower(setting->mName) : setting->mName;
                            std::vector<std::string> enumValues = enumSetting->mValues;
                            if (lowercase)
                            {
                                for (std::string& value : enumValues)
                                {
                                    value = StringUtils::toLower(value);
                                }
                            }
                            int* iterator = &enumSetting->mValue;
                            int numValues = static_cast<int>(enumValues.size());

                            moduleY += MathUtils::lerp(0.0f, modHeight, openEase);

                            ImVec4 rect = ImVec4(
                                modRect.x, catPositions[i].y + catHeight + moduleY + setPadding, modRect.z,
                                catPositions[i].y + catHeight + moduleY + modHeight);
                            rect.y = std::floor(rect.y);
                            if (rect.w > innerTop && rect.y < innerBottom)
                            {
                                bool isLastForRound = (setting == lastVisibleSettingForRounding);
                                float roundRadius = isLastForRound ? 10.0f : 0.0f;
                                ImDrawFlags roundFlags = isLastForRound ? ImDrawFlags_RoundCornersBottom : 0;
                                float elemAlpha = openEase * animation;
                                ImColor enumBgWithAlpha = setBg;
                                enumBgWithAlpha.Value.w = 0.35f;

                                if (ImRenderUtils::isMouseOver(rect) && isEnabled && catPositions[i].isExtended)
                                {
                                    bool withinVerticalMain = (rect.y < innerBottom) && (rect.w > innerTop);
                                    if (withinVerticalMain)
                                    {
                                        tooltip = setting->mDescription;
                                    }
                                }

                                float labelScale = 0.85f;
                                float labelH = ImGui::GetFont()->CalcTextSizeA(18.0f * labelScale, FLT_MAX, -1, setName.c_str()).y;
                                float innerPadX = 10.0f;
                                float innerPadY = 2.0f;
                                float gapX = 6.0f;
                                float gapY = 6.0f;
                                float hpX = 4.0f;
                                float topPad = firstVisibleSetting ? 0.0f : innerPadY;
                                float labelSpacingT = firstVisibleSetting ? 4.0f : 8.0f;

                                float innerLeft = rect.x + innerPadX;
                                float innerRight = rect.z - innerPadX;
                                float innerWidth = std::max(0.0f, innerRight - innerLeft);


                                float enumTextScale = textSize * 0.85f;
                                int count = numValues;
                                int lines = 0; float lineW = 0.0f;
                                for (int j = 0; j < count; ++j) {
                                    std::string lbl = enumValues[j];
                                    float tw_btn = ImRenderUtils::getTextWidth(&lbl, enumTextScale);
                                    float bw = tw_btn + hpX * 2.0f;
                                    if (lineW == 0.0f) lineW = bw;
                                    else if (lineW + gapX + bw <= innerWidth) lineW += gapX + bw;
                                    else { lines++; lineW = bw; }
                                }
                                if (lineW > 0.0f) lines++;

                                float btnH = 18.0f;
                                float labelSpacing = 8.0f;
                                float buttonsH = lines * btnH + (lines > 1 ? (lines - 1) * gapY : 0.0f);
                                float rowHeight = std::max(modHeight, topPad + labelH + labelSpacingT + buttonsH + innerPadY);
                                float enumTextHeight = ImGui::GetFont()->CalcTextSizeA(18.0f * enumTextScale, FLT_MAX, -1, "").y;
                                float animRowHeight = MathUtils::lerp(modHeight, rowHeight, openEase);
                                float animRowHeightPx = std::floor(animRowHeight);


                                ImVec4 rowRect = rect;
                                rowRect.y = std::floor(rowRect.y);
                                rowRect.w = std::floor(rowRect.y + animRowHeightPx);
                                if (firstVisibleSetting) {
                                    float origY = rowRect.y;
                                    rowRect.y = MathUtils::lerp(modRect.w, origY, openEase);
                                    rowRect.y = std::floor(rowRect.y);
                                    rowRect.w = std::floor(rowRect.y + animRowHeightPx);
                                    firstVisibleSetting = false;
                                }

                                const float edgeSlack = 2.0f;
                                if (rowRect.y > innerBottom + edgeSlack || rowRect.w < innerTop - edgeSlack) {
                                    float extraH_skip_px = (animRowHeightPx - modHeight);
                                    if (extraH_skip_px > 0.0f) moduleY += extraH_skip_px;
                                    sIndex++;
                                    continue;
                                }

                                ImColor enumRowBgWithAlpha = setBg;
                                enumRowBgWithAlpha.Value.w = 0.35f;
                                ImRenderUtils::fillRectangle(rowRect, enumRowBgWithAlpha, elemAlpha * 0.35f, roundRadius, ImGui::GetBackgroundDrawList(), roundFlags);
                                ImRenderUtils::drawText(ImVec2(innerLeft, rowRect.y + topPad), setName, Interface::getTextColor(), labelScale, elemAlpha, false);


                                if (ImRenderUtils::isMouseOver(rowRect) && isEnabled && catPositions[i].isExtended)
                                {
                                    bool withinVerticalMain2 = (rowRect.y < innerBottom) && (rowRect.w > innerTop);
                                    if (withinVerticalMain2) tooltip = setting->mDescription;
                                }

                                float rowInnerTop = std::floor(rowRect.y + topPad + labelH + labelSpacingT);
                                float rowInnerBottom = rowRect.w - innerPadY;

                                if (count > 0) {
                                    float currentX = innerLeft;
                                    float currentY = rowInnerTop;
                                    for (int j = 0; j < count; ++j)
                                    {
                                        std::string label = enumValues[j];
                                        float tw_btn = ImRenderUtils::getTextWidth(&label, enumTextScale);
                                        float btnW = tw_btn + hpX * 2.0f;

                                        if (currentX + btnW > innerRight + 0.5f) {
                                            currentX = innerLeft;
                                            currentY = currentY + btnH + gapY;
                                        }

                                        float bx1 = std::floor(currentX);
                                        float bx2 = std::floor(bx1 + btnW);
                                        ImVec4 btnRect(bx1, currentY, bx2, currentY + btnH);

                                        bool hovered = ImRenderUtils::isMouseOver(btnRect) && isEnabled && !displayColorPicker && mod->showSettings && catPositions[i].isExtended;
                                        bool selected = (*iterator == j);

                                        ImVec4 v = rgb.Value;
                                        ImColor selNormal(v.x * 0.90f, v.y * 0.90f, v.z * 0.90f, v.w);
                                        ImColor selHover(v.x * 1.00f, v.y * 1.00f, v.z * 1.00f, v.w);
                                        ImColor offNormal = setBg;
                                        ImColor offHover = setBg;
                                        offNormal.Value.w = 210.0f / 255.0f;
                                        offHover.Value.w = 230.0f / 255.0f;
                                        offHover.Value.x = std::min(1.0f, offHover.Value.x + 0.06f);
                                        offHover.Value.y = std::min(1.0f, offHover.Value.y + 0.06f);
                                        offHover.Value.z = std::min(1.0f, offHover.Value.z + 0.06f);

                                        size_t selKey = ((size_t)enumSetting << 1) ^ ((size_t)j * 2654435761u);
                                        float selTarget = selected ? 1.0f : 0.0f;
                                        float selCurrent = 0.0f;
                                        auto itSel = enumSelectAnim.find(selKey);
                                        if (itSel != enumSelectAnim.end()) selCurrent = itSel->second;
                                        selCurrent = MathUtils::animate(selTarget, selCurrent, ImRenderUtils::getDeltaTime() * 10.0f);
                                        enumSelectAnim[selKey] = selCurrent;

                                        ImColor baseNormal = MathUtils::lerpImColor(offNormal, selNormal, selCurrent);
                                        ImColor baseHover = MathUtils::lerpImColor(offHover, selHover, selCurrent);

                                        size_t key = (size_t)enumSetting ^ ((size_t)j * 2654435761u);
                                        float target = hovered ? 1.0f : 0.0f;
                                        float current = 0.0f;
                                        auto itAnim = enumHoverAnim.find(key);
                                        if (itAnim != enumHoverAnim.end()) current = itAnim->second;
                                        current = MathUtils::animate(target, current, ImRenderUtils::getDeltaTime() * 10.0f);
                                        enumHoverAnim[key] = current;

                                        ImColor btnBg = MathUtils::lerpImColor(baseNormal, baseHover, current);

                                        ImRenderUtils::fillRectangle(btnRect, btnBg, elemAlpha * 0.35f, 6.0f);

                                        float tx = std::floor(bx1 + (btnW - tw_btn) / 2.0f);
                                        float ty = std::floor(currentY + (btnH - enumTextHeight) / 2.0f);
                                        ImColor offText(200, 200, 200);
                                        ImColor onText(255, 255, 255);
                                        ImColor tcol = MathUtils::lerpImColor(offText, onText, selCurrent);
                                        ImRenderUtils::drawText(ImVec2(tx, ty), label, tcol, enumTextScale, elemAlpha, false);

                                        if (hovered && ImGui::IsMouseClicked(0))
                                        {
                                            *iterator = j;
                                            ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f);
                                        }
                                        currentX = currentX + btnW + gapX;
                                    }
                                }

                                float extraH_px = (animRowHeightPx - modHeight);
                                if (extraH_px > 0.0f) moduleY += extraH_px;
                            }
                            break;
                        }
                        case SettingType::Number:
                        {
                            NumberSetting* numSetting = reinterpret_cast<NumberSetting*>(setting);
                            const float value = numSetting->mValue;
                            const float min = numSetting->mMin;
                            const float max = numSetting->mMax;

                            char str[10];
                            sprintf_s(str, 10, "%.2f", value);
                            std::string rVal = str;

                            std::string setName = lowercase ? StringUtils::toLower(setting->mName) : setting->mName;
                            std::string valueName = rVal;

                            moduleY += MathUtils::lerp(0.0f, modHeight, openEase);

                            ImVec4 backGroundRect = ImVec4(
                                modRect.x, (catPositions[i].y + catHeight + moduleY), modRect.z,
                                catPositions[i].y + catHeight + moduleY + modHeight);

                            backGroundRect.y = std::floor(backGroundRect.y);
                            backGroundRect.w = std::floor(backGroundRect.y + modHeight);
                            if (firstVisibleSetting) {
                                float targetBgY = backGroundRect.y;
                                backGroundRect.y = MathUtils::lerp(modRect.w, targetBgY, openEase);
                                backGroundRect.y = std::floor(backGroundRect.y);
                                backGroundRect.w = std::floor(backGroundRect.y + modHeight);
                                firstVisibleSetting = false;
                            }

                            ImVec4 rect = ImVec4(
                                modRect.x + 10, (catPositions[i].y + catHeight + moduleY + setPadding), modRect.z - 10,
                                catPositions[i].y + catHeight + moduleY + modHeight);
                            
                            rect.y = std::floor(rect.y);
                            rect.w = std::floor(rect.w);

                            static float clickAnimation = 1.f;


                            if (ImGui::IsMouseDown(0) && ImRenderUtils::isMouseOver(rect))
                            {
                                clickAnimation = MathUtils::animate(0.60f, clickAnimation, ImRenderUtils::getDeltaTime() * 10);
                            }
                            else
                            {
                                clickAnimation = MathUtils::animate(1.f, clickAnimation, ImRenderUtils::getDeltaTime() * 10);
                            }

                            if (backGroundRect.w > innerTop && backGroundRect.y < innerBottom)
                            {
                                bool isNumberHovered = ImRenderUtils::isMouseOver(backGroundRect) && isEnabled && catPositions[i].isExtended;
                                bool isLastForRound = (setting == lastVisibleSettingForRounding);
                                float roundRadius = isLastForRound ? 10.0f : 0.0f;
                                ImDrawFlags roundFlags = isLastForRound ? ImDrawFlags_RoundCornersBottom : 0;
                                float elemAlpha = openEase * animation;
                                ImColor numBgWithAlpha = setBg;
                                numBgWithAlpha.Value.w = 0.35f;
                                ImRenderUtils::fillRectangle(backGroundRect, numBgWithAlpha, elemAlpha * 0.35f, roundRadius, ImGui::GetBackgroundDrawList(), roundFlags);

                                const float sliderPos = (value - min) / (max - min) * (rect.z - rect.x);
                                if (abs(sliderPos - setting->sliderEase) > 0.1f) {
                                    setting->sliderEase = MathUtils::animate(
                                        sliderPos, setting->sliderEase, ImRenderUtils::getDeltaTime() * 10);
                                }
                                setting->sliderEase = std::clamp(setting->sliderEase, 0.f, rect.z - rect.x);

#pragma region Slider dragging
                                if (ImRenderUtils::isMouseOver(rect) && isEnabled && catPositions[i].isExtended)
                                {
                                    tooltip = setting->mDescription;
                                    if (ImGui::IsMouseDown(0) || ImGui::IsMouseDown(2))
                                    {
                                        setting->isDragging = true;
                                        lastDraggedSetting = setting;
                                    }
                                }

                                if (ImGui::IsMouseDown(0) && setting->isDragging && isEnabled)
                                {
                                    if (lastDraggedSetting != setting)
                                    {
                                        setting->isDragging = false;
                                    }
                                    else
                                    {
                                        const float newValue = std::fmax(
                                            std::fmin(
                                                (ImRenderUtils::getMousePos().x - rect.x) / (rect.z - rect.x) * (
                                                    max - min) + min, max), min);
                                        numSetting->setValue(newValue);
                                    }
                                }
                                else if (ImGui::IsMouseDown(2) && setting->isDragging && isEnabled)
                                {
                                    if (lastDraggedSetting != setting)
                                    {
                                        setting->isDragging = false;
                                    }
                                    else
                                    {
                                        float newValue = std::fmax(
                                            std::fmin(
                                                (ImRenderUtils::getMousePos().x - rect.x) / (rect.z - rect.x) * (
                                                    max - min) + min, max), min);

                                        newValue = std::round(newValue / midclickRounding) * midclickRounding;
                                        numSetting->mValue = newValue;
                                    }
                                }
                                else
                                {
                                    setting->isDragging = false;
                                }
#pragma endregion    

                                float ySize = rect.w - rect.y;

                                ImVec2 sliderBarMin = ImVec2(rect.x, rect.w - ySize / 8);
                                ImVec2 sliderBarMax = ImVec2(rect.x + (setting->sliderEase * inScale), rect.w);
                                sliderBarMin.y = sliderBarMax.y - 6 * inScale;

                                ImVec4 sliderRect = ImVec4(sliderBarMin.x, sliderBarMin.y - 4.5f, sliderBarMax.x, sliderBarMax.y - 4.5f);

                                ImRenderUtils::fillRectangle(sliderRect, rgb, elemAlpha, 15);

                                ImVec2 circlePos = ImVec2(sliderRect.z - 2.25f, sliderRect.getCenter().y);

                                if (value <= min + 0.83f)
                                {
                                    circlePos.x = sliderRect.z + 2.25f;
                                }


                                ImRenderUtils::fillCircle(circlePos, 4.5f * clickAnimation, rgb, elemAlpha, 12);

                                auto ValueLen = ImRenderUtils::getTextWidth(&valueName, textSize);
                                float valueH = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, valueName.c_str()).y;
                                ImVec2 valuePos = ImVec2((backGroundRect.z - 10.f) - ValueLen, backGroundRect.y + ((backGroundRect.w - backGroundRect.y) - valueH) * 0.5f);
                                {
                                    ImColor baseText = Interface::getTextColor();
                                    
                                    ImColor valueCol = (baseText.Value.x > 0.5f ? ImColor(200, 200, 200) : ImColor(40, 40, 40));
                                    ImRenderUtils::drawText(valuePos, valueName, valueCol, textSize, elemAlpha, false);
                                }

                                float cSetRectCentreY_num = backGroundRect.y + ((backGroundRect.w - backGroundRect.y) - textHeight) / 2.0f;
                                ImRenderUtils::drawText(ImVec2(backGroundRect.x + 10.f, cSetRectCentreY_num),
                                    setName, Interface::getTextColor(), textSize,
                                    elemAlpha, false);
                            }
                            break;
                        }
                        case SettingType::Color:
                        {
                            ColorSetting* colorSetting = reinterpret_cast<ColorSetting*>(setting);
                            ImColor color = colorSetting->getAsImColor();
                            ImVec4 rgb = color.Value;
                            std::string setName = lowercase ? StringUtils::toLower(setting->mName) : setting->mName;

                            moduleY += MathUtils::lerp(0.0f, modHeight, mod->cAnim);

                            ImVec4 rect = ImVec4(
                                modRect.x, catPositions[i].y + catHeight + moduleY + setPadding, modRect.z,
                                catPositions[i].y + catHeight + moduleY + modHeight);
                            rect.y = std::floor(rect.y);
                            rect.w = std::floor(rect.w);
                            if (firstVisibleSetting) {
                                float targetY3 = rect.y;
                                rect.y = MathUtils::lerp(modRect.w, targetY3, openEase);
                                rect.y = std::floor(rect.y);
                                rect.w = std::floor(rect.y + modHeight);
                                firstVisibleSetting = false;
                            }

                            if (rect.w > innerTop && rect.y < innerBottom)
                            {
                                bool isColorHovered = ImRenderUtils::isMouseOver(rect) && isEnabled && catPositions[i].isExtended;
                                bool isLastForRound = (setting == lastVisibleSettingForRounding);
                                float roundRadius = isLastForRound ? 10.0f : 0.0f;
                                ImDrawFlags roundFlags = isLastForRound ? ImDrawFlags_RoundCornersBottom : 0;
                                float elemAlpha = openEase * animation;
                                ImColor setBgWithAlpha = setBg;
                                setBgWithAlpha.Value.w = 0.35f;
                                ImRenderUtils::fillRectangle(rect, setBgWithAlpha, elemAlpha * 0.35f, roundRadius, ImGui::GetBackgroundDrawList(), roundFlags);

                                if (ImRenderUtils::isMouseOver(rect) && isEnabled && catPositions[i].isExtended)
                                {
                                    bool isSettingVisible =
                                        (rect.y < innerBottom) && (rect.w > innerTop);

                                    if (isSettingVisible)
                                    {
                                        tooltip = setting->mDescription;
                                        if (ImGui::IsMouseClicked(0) && !displayColorPicker && mod->showSettings)
                                        {
                                            displayColorPicker = !displayColorPicker;
                                            lastColorSetting = colorSetting;
                                        }
                                    }
                                }

                                float cSetRectCentreY = rect.y + ((rect.w - rect.y) - textHeight) / 2;
                                ImRenderUtils::drawText(ImVec2(rect.x + 10.f, cSetRectCentreY), setName,
                                    Interface::getTextColor(), textSize, elemAlpha, false);

                                float colorPadY = 9.0f;
                                ImVec2 colorRect = ImVec2(rect.z - 25, rect.y + colorPadY);
                                ImRenderUtils::fillRectangle(
                                    ImVec4(rect.z - 25, rect.y + colorPadY, rect.z - 10, rect.w - colorPadY),
                                    colorSetting->getAsImColor(), elemAlpha, 6.0f);
                            }
                            break;
                        }
                        case SettingType::MultiBind:
                        {
                            MultiBindSetting* multiBindSetting = reinterpret_cast<MultiBindSetting*>(setting);
                            std::string setName = lowercase ? StringUtils::toLower(setting->mName) : setting->mName;

                            moduleY += MathUtils::lerp(0.0f, modHeight, openEase);

                            ImVec4 rect = ImVec4(
                                modRect.x, catPositions[i].y + catHeight + moduleY + setPadding, modRect.z,
                                catPositions[i].y + catHeight + moduleY + modHeight);
                            rect.y = std::floor(rect.y);

                            float labelScale = 0.85f;
                            float labelH = ImGui::GetFont()->CalcTextSizeA(18.0f * labelScale, FLT_MAX, -1, setName.c_str()).y;
                            float innerPadX = 10.0f;
                            float innerPadY = 2.0f;
                            float topPad = firstVisibleSetting ? 0.0f : innerPadY;
                            float labelSpacingT = firstVisibleSetting ? 4.0f : 8.0f;

                            float innerLeft = rect.x + innerPadX;
                            float innerRight = rect.z - innerPadX;

                            float itemHeight = 20.0f;
                            int count = (int)multiBindSetting->mItemNames.size();
                            float rowHeight = std::max(modHeight, topPad + labelH + labelSpacingT + (count * itemHeight) + innerPadY);
                            float animRowHeight = MathUtils::lerp(modHeight, rowHeight, openEase);
                            float animRowHeightPx = std::floor(animRowHeight);

                            ImVec4 rowRect = rect;
                            rowRect.y = std::floor(rowRect.y);
                            rowRect.w = std::floor(rowRect.y + animRowHeightPx);
                            if (firstVisibleSetting) {
                                float origY = rowRect.y;
                                rowRect.y = MathUtils::lerp(modRect.w, origY, openEase);
                                rowRect.y = std::floor(rowRect.y);
                                rowRect.w = std::floor(rowRect.y + animRowHeightPx);
                                firstVisibleSetting = false;
                            }

                            const float edgeSlack = 2.0f;
                            if (rowRect.y > innerBottom + edgeSlack || rowRect.w < innerTop - edgeSlack) {
                                float extraH_skip_px = (animRowHeightPx - modHeight);
                                if (extraH_skip_px > 0.0f) moduleY += extraH_skip_px;
                                sIndex++;
                                continue;
                            }

                            bool isLastForRound = (setting == lastVisibleSettingForRounding);
                            float roundRadius = isLastForRound ? 10.0f : 0.0f;
                            ImDrawFlags roundFlags = isLastForRound ? ImDrawFlags_RoundCornersBottom : 0;
                            float elemAlpha = openEase * animation;
                            auto interfaceModule = gFeatureManager->mModuleManager->getModule<Interface>();
                            bool lightTheme = interfaceModule && interfaceModule->mUiTheme.mValue == Interface::UiTheme::Light;
                            ImColor mbg = lightTheme ? ImColor(210, 210, 210) : ImColor(40, 40, 40);
                            mbg.Value.w = 0.35f;
                            ImRenderUtils::fillRectangle(rowRect, mbg, elemAlpha * 0.35f, roundRadius, ImGui::GetBackgroundDrawList(), roundFlags);
                            ImRenderUtils::drawText(ImVec2(innerLeft, rowRect.y + topPad), setName, Interface::getTextColor(), labelScale, elemAlpha, false);

                            if (ImRenderUtils::isMouseOver(rowRect) && isEnabled && catPositions[i].isExtended)
                            {
                                bool isSettingVisible = (rowRect.y < innerBottom) && (rowRect.w > innerTop);
                                if (isSettingVisible)
                                {
                                    tooltip = setting->mDescription;
                                    if (ImGui::IsMouseClicked(0) && !isMultiBindSettingBinding && mod->showSettings)
                                    {
                                        int clickedItem = -1;
                                        float startY = std::floor(rowRect.y + topPad + labelH + labelSpacingT);
                                        for (int j = 0; j < count; ++j) {
                                            float itemY = startY + (j * itemHeight);
                                            ImVec4 itemRect(innerLeft, itemY, innerRight, itemY + itemHeight);
                                            if (ImRenderUtils::isMouseOver(itemRect)) { clickedItem = j; break; }
                                        }
                                        if (clickedItem >= 0) {
                                            isMultiBindSettingBinding = true;
                                            lastMultiBindSetting = multiBindSetting;
                                            lastMultiBindItemName = multiBindSetting->mItemNames[clickedItem];
                                        }
                                    }
                                }
                            }

                            float rowInnerTop = std::floor(rowRect.y + topPad + labelH + labelSpacingT);
                            for (int j = 0; j < count; ++j) {
                                const std::string& itemName = multiBindSetting->mItemNames[j];
                                int key = multiBindSetting->getBind(itemName);
                                float itemY = rowInnerTop + (j * itemHeight);
                                ImRenderUtils::drawText(ImVec2(innerLeft + 5.0f, itemY), itemName, Interface::getTextColor(), textSize * 0.8f, elemAlpha, false);
                                std::string keyName = (key == -1) ? "NONE" : Keyboard::getKey(key);
                                if (isMultiBindSettingBinding && lastMultiBindSetting == multiBindSetting && lastMultiBindItemName == itemName) keyName = "[...]";
                                float keyScale = textSize * 0.8f;
                                float keyTw = ImRenderUtils::getTextWidth(&keyName, keyScale);
                                float keyX = innerRight - 10.0f - keyTw;
                                ImColor keyCol = lightTheme ? ImColor(0, 0, 0) : ImColor(255, 255, 255);
                                ImRenderUtils::drawText(ImVec2(keyX, itemY), keyName, keyCol, keyScale, elemAlpha, false);
                            }

                            float extraH_px = (animRowHeightPx - modHeight);
                            if (extraH_px > 0.0f) moduleY += extraH_px;
                            break;
                        }
                        }

                        sIndex++;
                    }

                }


                if (modRect.w > innerTop && modRect.y < innerBottom)
                {
                    {
                        float cornerRadius = 10.0f;
                        bool isHovered = ImRenderUtils::isMouseOver(modRect) && catPositions[i].isExtended && isEnabled;

                        ImColor __baseModBg = Interface::getBlurBgColor();
                        ImColor __lightModBg = ImColor(30, 30, 30);
                        float catAlpha = animation * catPositions[i].openAnimProgress;
                        float __openEase = 1.0f - powf(1.0f - mod->cAnim, 3.0f);
                        ImColor bg = MathUtils::lerpImColor(__baseModBg, __lightModBg, __openEase);
                        bg.Value.w = 0.7f;
                        float targetColorAnim = mod->mEnabled ? 1.0f : 0.0f;
                        float& colorAnim = perfCache.moduleColorAnims[mod.get()];
                        colorAnim = MathUtils::animate(targetColorAnim, colorAnim, ImRenderUtils::getDeltaTime() * 8.0f);
                        float lighten = 0.16f * colorAnim;
                        bg.Value.x = std::min(1.0f, bg.Value.x + lighten);
                        bg.Value.y = std::min(1.0f, bg.Value.y + lighten);
                        bg.Value.z = std::min(1.0f, bg.Value.z + lighten);
                        bool isLastModule = (modIndex == (int)filteredMods.size() - 1);
                        ImDrawFlags modRoundFlags = 0;
                        if (__openEase >= 0.70f) {
                            modRoundFlags = isLastModule ? (ImDrawFlags_RoundCornersTop | ImDrawFlags_RoundCornersBottom) : ImDrawFlags_RoundCornersTop;
                        }
                        else {
                            modRoundFlags = ImDrawFlags_RoundCornersAll;
                        }
                        ImRenderUtils::fillRectangle(modRect, bg, catAlpha * 0.35f, cornerRadius, ImGui::GetBackgroundDrawList(), modRoundFlags);
                        {
                            
                        }

                        ImColor enabledColor = rgb;
                        ImColor disabledColor = ImColor(180, 180, 180);
                        ImColor textColor = ImColor(
                            disabledColor.Value.x + (enabledColor.Value.x - disabledColor.Value.x) * colorAnim,
                            disabledColor.Value.y + (enabledColor.Value.y - disabledColor.Value.y) * colorAnim,
                            disabledColor.Value.z + (enabledColor.Value.z - disabledColor.Value.z) * colorAnim,
                            1.0f
                        );
                        textColor.Value.w = catAlpha * (0.7f + 0.3f * colorAnim);
                        float modTextHeight = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, mod->getName().c_str()).y;
                        ImVec2 modPosLerped = ImVec2(
                            modRect.x + 8.0f,
                            modRect.y + ((modRect.w - modRect.y) - modTextHeight) / 3.4f
                        );
                        if (lowPerformanceMode) {
                            if (colorAnim < 0.5f) {
                                ImRenderUtils::drawText(
                                    modPosLerped,
                                    mod->getName(),
                                    Interface::getTextColor(),
                                    textSize,
                                    catAlpha,
                                    false
                                );
                            }
                            else {
                                ImRenderUtils::drawGradientText(
                                    modPosLerped,
                                    mod->getName(),
                                    textSize,
                                    catAlpha,
                                    false,
                                    1.0f
                                );
                            }
                        }
                        else {
                            float blackAlpha = catAlpha * (1.0f - colorAnim);
                            float gradAlpha = catAlpha * colorAnim;
                            if (blackAlpha > 0.02f) {
                                ImRenderUtils::drawText(
                                    modPosLerped,
                                    mod->getName(),
                                    Interface::getTextColor(),
                                    textSize,
                                    blackAlpha,
                                    false
                                );
                            }
                            if (gradAlpha > 0.02f) {
                                ImRenderUtils::drawGradientText(
                                    modPosLerped,
                                    mod->getName(),
                                    textSize,
                                    gradAlpha,
                                    false,
                                    1.0f
                                );
                            }
                        }
                        {
                            bool showStaffIcon = mod->mPremium;
                            if (showStaffIcon) {
                                ID3D11ShaderResourceView* staffSrv = nullptr;
                                int sw = 0, sh = 0;
                                auto itStaff = perfCache.textureCache.find("staff.png");
                                if (itStaff != perfCache.textureCache.end()) {
                                    staffSrv = itStaff->second;
                                    auto dims = perfCache.textureDimensions["staff.png"]; sw = dims.first; sh = dims.second;
                                }
                                if (staffSrv) {
                                    float baseIconSize = 16.0f;
                                    float iconSize = baseIconSize;
                                    float nameW = ImRenderUtils::getTextWidth(&mod->getName(), textSize);
                                    ImVec2 iconPos(
                                        modPosLerped.x + nameW + 6.0f,
                                        modRect.y + ((modRect.w - modRect.y) - iconSize) * 0.5f
                                    );
                                    float iconRightBound = modRect.z - 28.0f;
                                    if (iconPos.x + iconSize > iconRightBound) {
                                        iconPos.x = iconRightBound - iconSize;
                                    }
                                    ImDrawList* dl = ImGui::GetBackgroundDrawList();
                                    ImU32 baseTint = IM_COL32(255, 215, 0, (int)(220 * catAlpha * ImRenderUtils::getGlobalAlpha()));
                                    dl->AddImage(
                                        (ImTextureID)staffSrv,
                                        iconPos,
                                        ImVec2(iconPos.x + iconSize, iconPos.y + iconSize),
                                        ImVec2(0, 0), ImVec2(1, 1),
                                        baseTint
                                    );
                                    drawShineBand(dl, staffSrv, iconPos, ImVec2(iconPos.x + iconSize, iconPos.y + iconSize), catAlpha);
                                    ImVec4 iconRect(iconPos.x, iconPos.y, iconPos.x + iconSize, iconPos.y + iconSize);
                                    bool iconHovered = ImRenderUtils::isMouseOver(iconRect) && isEnabled && catPositions[i].isExtended;
                                    std::string premiumText = "only for premium user";
                                    float premiumScale = textSize * 0.85f;
                                    float tw = ImRenderUtils::getTextWidth(&premiumText, premiumScale);
                                    float th = ImGui::GetFont()->CalcTextSizeA(premiumScale, FLT_MAX, -1, premiumText.c_str()).y;
                                    ImVec2 tPos(iconPos.x + iconSize * 0.5f - tw * 0.5f, iconPos.y - th - 20.0f);
                                    float textLeftBound = modRect.x + 4.0f;
                                    float textRightBound = modRect.z - 4.0f - tw;
                                    if (tPos.x < textLeftBound) tPos.x = textLeftBound;
                                    if (tPos.x > textRightBound) tPos.x = textRightBound;
                                    ImVec4 textRect(tPos.x, tPos.y, tPos.x + tw, tPos.y + th);
                                    bool textHovered = ImRenderUtils::isMouseOver(textRect) && isEnabled && catPositions[i].isExtended;
                                    float curr = 0.0f;
                                    auto itAnim = staffTextAnim.find(mod.get());
                                    if (itAnim != staffTextAnim.end()) curr = itAnim->second;
                                    float target = (iconHovered || textHovered) ? 1.0f : 0.0f;
                                    float spd = (target < curr) ? 18.0f : 12.0f;
                                    curr = MathUtils::animate(target, curr, ImRenderUtils::getDeltaTime() * spd);
                                    staffTextAnim[mod.get()] = curr;
                                    float textAlpha = curr * catAlpha;
                                    if (textAlpha > 0.01f) {

                                        ImDrawList* fdl = ImGui::GetForegroundDrawList();
                                        ImColor baseGold = ImColor(255, 215, 0);
                                        ImColor brightGold = ImColor(255, 240, 140);
                                        ImRenderUtils::drawText(tPos, premiumText, baseGold, premiumScale, textAlpha, false, 0, fdl);
                                        float tLin = ((NOW % 5000) / 5000.0f);
                                        float tSmooth = tLin * tLin * tLin * (tLin * (tLin * 6.0f - 15.0f) + 10.0f);
                                        float bandWT = tw * 0.35f;
                                        float bandXX = tPos.x + tSmooth * (tw + bandWT) - bandWT;
                                        float clipMinX2 = std::max(tPos.x, bandXX);
                                        float clipMaxX2 = std::min(tPos.x + tw, bandXX + bandWT);
                                        if (clipMaxX2 > clipMinX2) {
                                            fdl->PushClipRect(ImVec2(clipMinX2, tPos.y - 2.0f), ImVec2(clipMaxX2, tPos.y + th + 2.0f), true);
                                            ImRenderUtils::drawText(tPos, premiumText, brightGold, premiumScale, textAlpha, false, 0, fdl);
                                            fdl->PopClipRect();
                                        }
                                    }
                                }
                            }
                        }
                        bool hasSettingsDots = false;
                        for (const auto& setting : mod->mSettings) { std::string __sn = StringUtils::toLower(setting->mName); if (setting->mIsVisible() && __sn != "visible") { hasSettingsDots = true; break; } }
                        if (hasSettingsDots) {
                            ImVec2 dotsCenter = ImVec2(modRect.z - 16.0f, modRect.y + (modRect.w - modRect.y) / 2.0f);
                            float dotRadius = 1.5f;
                            float dotSpacing = 5.0f;
                            ImDrawList* dotsDl = ImGui::GetBackgroundDrawList();
                            ImU32 dotsCol = IM_COL32(200, 200, 200, (int)(255 * catAlpha * ImRenderUtils::getGlobalAlpha()));
                            dotsDl->AddCircleFilled(ImVec2(dotsCenter.x - dotSpacing, dotsCenter.y), dotRadius, dotsCol, 12);
                            dotsDl->AddCircleFilled(ImVec2(dotsCenter.x, dotsCenter.y), dotRadius, dotsCol, 12);
                            dotsDl->AddCircleFilled(ImVec2(dotsCenter.x + dotSpacing, dotsCenter.y), dotRadius, dotsCol, 12);
                        }
                    }

                    if (ImRenderUtils::isMouseOver(modRect) && catPositions[i].isExtended && isEnabled && catPositions[i].isExtended)
                    {
                        bool isModuleVisible =
                            modRect.y >= innerTop &&
                            modRect.w <= innerBottom &&
                            modRect.x >= innerLeft &&
                            modRect.z <= innerRight;

                        if (isModuleVisible)
                        {
                            if (ImRenderUtils::isMouseOver(catWindow) && catPositions[i].isExtended && catPositions[i].isExtended)
                            {
                                tooltip = mod->mDescription;
                            }

                            if (ImGui::IsMouseClicked(0) && !displayColorPicker && catPositions[i].isExtended)
                            {
                                if (!moduleToggled) mod->toggle();
                                ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f);
                                moduleToggled = true;
                            }
                            else if (ImGui::IsMouseClicked(1) && !displayColorPicker && catPositions[i].isExtended)
                            {
                                bool hasVisibleSettingsClick = false;
                                for (const auto& setting : mod->mSettings) { std::string __sn = StringUtils::toLower(setting->mName); if (setting->mIsVisible() && __sn != "visible") { hasVisibleSettingsClick = true; break; } }
                                if (hasVisibleSettingsClick) {
                                    bool opening = !mod->showSettings;
                                    mod->showSettings = !mod->showSettings;
                                    if (opening) {
                                        float blockHeightFull = modHeight + approxSettingsHeight;
                                        float topY = catPositions[i].y + catHeight + moduleY;
                                        float bottomY = topY + blockHeightFull;
                                        float innerTopBound = innerTop + 4.0f;
                                        float innerBottomBound = innerBottom - 4.0f;
                                        float delta = 0.0f;
                                        if (bottomY > innerBottomBound) delta = bottomY - innerBottomBound;
                                        else if (topY < innerTopBound) delta = topY - innerTopBound;
                                        if (delta != 0.0f) {
                                            catPositions[i].scrollEase = std::max(0.0f, catPositions[i].scrollEase + delta);
                                        }
                                    }
                                }
                            }
                            else if (ImGui::IsMouseClicked(2) && !displayColorPicker && catPositions[i].isExtended)
                            {
                                lastMod = mod;
                                isBinding = true;
                                ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f);
                            }
                        }
                    }
                }
                moduleY += modHeight + moduleGap;
                prevCAnim[mod.get()] = mod->cAnim;
                modIndex++;
            }
        }

        if (catPositions[i].openAnimProgress > 0.001f) {
            float finalAlpha = animation * catPositions[i].openAnimProgress;
            if (finalAlpha > 0.01f) {
                const float innerLeft = catPositions[i].x + (catWidth - innerWidth) / 2.0f;
                const float innerTop = catPositions[i].y + catHeight + 5.0f;
                const float innerRight = innerLeft + innerWidth;
                const float innerBottom = innerTop + innerHeight;
                float fadeH = 18.0f;
                fadeH = std::min(fadeH, innerHeight * 0.25f);
                ImColor blurBg = Interface::getBlurBgColor();
                int bgR = (int)(blurBg.Value.x * 255.0f);
                int bgG = (int)(blurBg.Value.y * 255.0f);
                int bgB = (int)(blurBg.Value.z * 255.0f);
                ImU32 cTopA = IM_COL32(bgR, bgG, bgB, (int)(180 * 0.80f * finalAlpha * ImRenderUtils::getGlobalAlpha()));
                ImU32 cTopB = IM_COL32(bgR, bgG, bgB, 0);
                drawList->AddRectFilledMultiColor(
                    ImVec2(innerLeft, innerTop),
                    ImVec2(innerRight, innerTop + fadeH),
                    cTopA, cTopA, cTopB, cTopB,
                    12.0f, ImDrawFlags_RoundCornersTop);
                ImU32 cBotA = IM_COL32(bgR, bgG, bgB, 0);
                ImU32 cBotB = IM_COL32(bgR, bgG, bgB, (int)(180 * 0.80f * finalAlpha * ImRenderUtils::getGlobalAlpha()));
                drawList->AddRectFilledMultiColor(
                    ImVec2(innerLeft, innerBottom - fadeH),
                    ImVec2(innerRight, innerBottom),
                    cBotA, cBotA, cBotB, cBotB,
                    12.0f, ImDrawFlags_RoundCornersBottom);
            }
        }
        drawList->PopClipRect();
        if (catPositions[i].openAnimProgress > 0.001f) {
            drawList->PopClipRect();
        }

        if (isBinding)
        {
            tooltip = "Currently binding " + lastMod->getName() + "..." + " Press ESC to unbind.";
            for (const auto& key : Keyboard::mPressedKeys)
            {
                if (key.second && lastMod)
                {
                    lastMod->mKey = key.first == VK_ESCAPE ? 0 : key.first;
                    isBinding = false;
                    if (key.first == VK_ESCAPE)
                    {
                        ClientInstance::get()->playUi("random.break", 0.75f, 1.0f);
                    }
                    else
                    {
                        ClientInstance::get()->playUi("random.orb", 0.75f, 1.0f);
                    }
                }
            }
        }

        if (isBoolSettingBinding)
        {
            tooltip = "Currently binding " + lastBoolSetting->mName + "... Press ESC to unbind.";
            for (const auto& key : Keyboard::mPressedKeys)
            {
                if (key.second && lastBoolSetting)
                {
                    lastBoolSetting->mKey = (key.first == VK_ESCAPE) ? 0 : key.first;
                    isBoolSettingBinding = false;

                    if (key.first == VK_ESCAPE)
                    {
                        ClientInstance::get()->playUi("random.break", 0.75f, 1.0f);
                    }
                    else
                    {
                        ClientInstance::get()->playUi("random.orb", 0.75f, 1.0f);
                    }
                }
            }
        }

        if (isMultiBindSettingBinding)
        {
            tooltip = "Currently binding " + lastMultiBindSetting->mName + " - " + lastMultiBindItemName + "... Press ESC to unbind.";
            for (const auto& key : Keyboard::mPressedKeys)
            {
                if (key.second && lastMultiBindSetting)
                {
                    lastMultiBindSetting->setBind(lastMultiBindItemName, key.first == VK_ESCAPE ? -1 : key.first);
                    isMultiBindSettingBinding = false;
                    lastMultiBindSetting = nullptr;
                    lastMultiBindItemName = "";
                    if (!ConfigManager::LastLoadedConfig.empty()) {
                        ConfigManager::saveConfig(ConfigManager::LastLoadedConfig);
                    }

                    if (key.first == VK_ESCAPE)
                    {
                        ClientInstance::get()->playUi("random.break", 0.75f, 1.0f);
                    }
                    else
                    {
                        ClientInstance::get()->playUi("random.orb", 0.75f, 1.0f);
                    }
                }
            }
        }

        std::string catName = lowercase ? StringUtils::toLower(categories[i]) : categories[i];

        
        
        

        
        
        
        if (!lowPerformanceMode && animation > 0.01f) {
            D2D::addBlurOptimized(ImGui::GetBackgroundDrawList(), 5.0f, catRect, 8.0f);
        }
        ImColor catBgColor = Interface::getBlurBgColor();
        catBgColor.Value.w *= 0.95f;
        ImRenderUtils::fillRectangle(catRect, catBgColor, animation * 0.95f, 15, ImGui::GetBackgroundDrawList(), ImDrawFlags_RoundCornersTop);
        
        

        FontHelper::pushPrefFont(true, true, true);
        float catTextHeight = ImGui::GetFont()->CalcTextSizeA(textSize * 1.35, FLT_MAX, -1, catName.c_str()).y;
        float cRectCentreX = catRect.x + ((catRect.z - catRect.x) - ImRenderUtils::getTextWidth(&catName, textSize * 1.35)) / 2;
        float cRectCentreY = catRect.y + ((catRect.w - catRect.y) - catTextHeight) / 5;
        ImRenderUtils::drawText(ImVec2(cRectCentreX, cRectCentreY), catName, Interface::getTextColor(),
            textSize * 1.35, animation, false);
        FontHelper::popPrefFont();

        float centerX = screen.x / 2.f;
        float centerY = screen.y / 2.f;
        float xPos = centerX - (categories.size() * (catWidth + catGap) / 2) + i * (catWidth + catGap);
        float targetY = centerY - (catTotalHeight / 2);

        catPositions[i].x = xPos;
        catPositions[i].y = targetY;

#pragma region DraggingLogic
        
        /*
        static bool dragging = false;
        static ImVec2 dragOffset;
        if (catPositions[i].isDragging)
        {
            if (ImGui::IsMouseDown(0))
            {
                if (!dragging)
                {
                    dragOffset = ImVec2(ImRenderUtils::getMousePos().x - catRect.x,
                        ImRenderUtils::getMousePos().y - catRect.y);
                    dragging = true;
                }
                ImVec2 newPosition = ImVec2(ImRenderUtils::getMousePos().x - dragOffset.x,
                    targetY); 

                newPosition.x = std::clamp(newPosition.x, 0.f, screen.x - catWidth);
                
                newPosition.x = std::round(newPosition.x / 2) * 2;

                catPositions[i].x = newPosition.x;
                catPositions[i].y = newPosition.y;
            }
            else
            {
                catPositions[i].isDragging = false;
                dragging = false;
            }
        }
        else if (ImRenderUtils::isMouseOver(catRect) && ImGui::IsMouseClicked(0) && isEnabled)
        {
            catPositions[i].isDragging = true;
            dragOffset = ImVec2(ImRenderUtils::getMousePos().x - catRect.x,
                ImRenderUtils::getMousePos().y - catRect.y);
        }
        */
#pragma endregion
    }

    {
        static float tooltipAnim = 0.0f;
        static std::string lastTooltipText = "";
        const bool hasNewTooltip = !tooltip.empty();
        if (hasNewTooltip) lastTooltipText = tooltip;
        float target = hasNewTooltip ? 1.0f : 0.0f;
        {
            float spd = (target < tooltipAnim) ? 24.0f : 12.0f;
            tooltipAnim = MathUtils::animate(target, tooltipAnim, ImRenderUtils::getDeltaTime() * spd);
        }

        if (tooltipAnim > 0.01f && !lastTooltipText.empty())
        {
            float tooltipScale = textSize * 1.05f;

            ImFont* arialLarge = nullptr;
            bool pushedArial = false;
            if (FontHelper::Fonts.contains("arial_large")) arialLarge = FontHelper::Fonts["arial_large"];
            if (arialLarge) { ImGui::PushFont(arialLarge); pushedArial = true; }

            float textWidth = ImRenderUtils::getTextWidth(&lastTooltipText, tooltipScale);
            float textHeight = ImGui::GetFont()->CalcTextSizeA(tooltipScale * 18.0f, FLT_MAX, 0, lastTooltipText.c_str()).y;
            float padding = 4.0f;
            float verticalMargin = 12.0f;
            float guiTopY = !catPositions.empty() ? catPositions[0].y : (screen.y / 2.f - catTotalHeight / 2.f);
            float x = (screen.x - textWidth) / 2.0f;
            float baseY = std::max(5.0f, guiTopY - textHeight - verticalMargin);
            float ySlide = MathUtils::lerp(8.0f, 0.0f, tooltipAnim);
            float y = baseY - ySlide;

            ImVec4 tooltipRect = ImVec4(
                x - padding,
                y - padding,
                x + textWidth + padding,
                y + textHeight + padding
            );

            float alpha = tooltipAnim;
            tooltipRect = tooltipRect.scaleToCenter(alpha);
            ImRenderUtils::fillRectangle(tooltipRect, Interface::getBlurBgColor(), animation * alpha * 0.80f, 6.f, ImGui::GetForegroundDrawList());
            ImRenderUtils::drawText(ImVec2(tooltipRect.x + padding, tooltipRect.y + padding), lastTooltipText,
                Interface::getTextColor(), tooltipScale * alpha, animation * alpha, false, 0, ImGui::GetForegroundDrawList());

            if (pushedArial) ImGui::PopFont();
        }
    }

    if (isEnabled)
    {
        scrollDirection = 0;
        static float bottomSlide = 0.0f;
        static float buttonHideAnim = 0.0f;
        static bool isHiding = false;
        static bool shouldShowConfigs = false;
        if (isHiding) {
            buttonHideAnim = MathUtils::animate(0.0f, buttonHideAnim, ImRenderUtils::getDeltaTime() * 15.0f);
            if (buttonHideAnim < 0.1f && !shouldShowConfigs) {
                shouldShowConfigs = true;
            }
        }
        else {
            buttonHideAnim = MathUtils::animate(1.0f, buttonHideAnim, ImRenderUtils::getDeltaTime() * 15.0f);
        }
        if (!displayConfigsMenu && !displaySpooferMenu && shouldShowConfigs) {
            isHiding = false;
            shouldShowConfigs = false;
        }
        float targetSlide = (isEnabled && !displayConfigsMenu && !displaySpooferMenu && !displayIRCMenu) ? 1.0f : 0.0f;
        {
            float spd = (targetSlide < bottomSlide) ? 26.0f : 12.0f;
            bottomSlide = MathUtils::animate(targetSlide, bottomSlide, ImRenderUtils::getDeltaTime() * spd);
        }
        ImVec2 btnSize(110.0f, 38.0f);
        float hiddenY = screen.y + 20.0f;
        float visibleY = screen.y - btnSize.y - 24.0f;

        float hideDistance = 30.0f;
        float hideY = visibleY + hideDistance;
        float finalY = MathUtils::lerp(hiddenY, visibleY, bottomSlide);
        float currBtnY = MathUtils::lerp(finalY, hideY, 1.0f - buttonHideAnim);

        float totalWidth = btnSize.x * 3 + 24.0f; // Configs, IRC, Spoofer with 12px gaps
        ImVec2 configsPos((screen.x - totalWidth) * 0.5f, currBtnY);
        ImVec2 ircPos(configsPos.x + btnSize.x + 12.0f, currBtnY);
        ImVec2 spooferPos(ircPos.x + btnSize.x + 12.0f, currBtnY);

        ImVec4 configsBtnRect(configsPos.x, configsPos.y, configsPos.x + btnSize.x, configsPos.y + btnSize.y);
        bool configsHovered = ImRenderUtils::isMouseOver(configsBtnRect);

        static float configsBtnScale = 1.0f;
        static bool wasConfigsClicked = false;
        bool configsClicked = configsHovered && ImGui::IsMouseDown(0);
        float configsTargetScale = 1.0f;
        if (configsClicked) {
            configsTargetScale = 1.08f;
            wasConfigsClicked = true;
        }
        else if (configsHovered) {
            configsTargetScale = 1.05f;
        }
        else {
            configsTargetScale = 1.0f;
        }
        configsBtnScale = MathUtils::animate(configsTargetScale, configsBtnScale, ImRenderUtils::getDeltaTime() * 12.0f);
        ImVec2 scaledConfigsBtnSize(btnSize.x * configsBtnScale, btnSize.y * configsBtnScale);
        ImVec2 scaledConfigsPos(
            configsPos.x - (scaledConfigsBtnSize.x - btnSize.x) * 0.5f,
            configsPos.y - (scaledConfigsBtnSize.y - btnSize.y) * 0.5f
        );
        ImVec4 scaledConfigsBtnRect(scaledConfigsPos.x, scaledConfigsPos.y,
            scaledConfigsPos.x + scaledConfigsBtnSize.x, scaledConfigsPos.y + scaledConfigsBtnSize.y);

        float finalAlpha = animation * bottomSlide * buttonHideAnim;
        ImColor configsBtnBgBase = Interface::getBlurBgColor();
        ImColor configsBtnBg = configsBtnBgBase;
        configsBtnBg.Value.w = (230.0f / 255.0f) * finalAlpha * ImRenderUtils::getGlobalAlpha();
        
        D2D::addBlurOptimized(ImGui::GetBackgroundDrawList(), 2.0f, scaledConfigsBtnRect, 10.0f * configsBtnScale);
        ImRenderUtils::fillRectangle(scaledConfigsBtnRect, configsBtnBgBase, finalAlpha * 0.90f, 10.0f * configsBtnScale);
        float configsIconPad = 12.0f * configsBtnScale;
        float scaledConfigsIconSize = 18.0f * configsBtnScale;
        ImVec2 configsIconPos(scaledConfigsBtnRect.x + configsIconPad, scaledConfigsBtnRect.y + (scaledConfigsBtnSize.y - scaledConfigsIconSize) * 0.5f);

        ID3D11ShaderResourceView* cfgIconTexture = nullptr;
        if (perfCache.textureCache.find("documents") != perfCache.textureCache.end()) {
            cfgIconTexture = perfCache.textureCache["documents"];
        }

        if (cfgIconTexture) {
            ImColor tcol = Interface::getTextColor();
            ImGui::GetBackgroundDrawList()->AddImage(
                cfgIconTexture,
                configsIconPos,
                ImVec2(configsIconPos.x + scaledConfigsIconSize, configsIconPos.y + scaledConfigsIconSize),
                ImVec2(0, 0), ImVec2(1, 1), IM_COL32((int)(tcol.Value.x * 255.0f), (int)(tcol.Value.y * 255.0f), (int)(tcol.Value.z * 255.0f), (int)(255 * finalAlpha * ImRenderUtils::getGlobalAlpha()))
            );
            drawShineBand(ImGui::GetBackgroundDrawList(), cfgIconTexture, configsIconPos, ImVec2(configsIconPos.x + scaledConfigsIconSize, configsIconPos.y + scaledConfigsIconSize), finalAlpha);
        }
        std::string configsLabel = "Configs";
        float cfgTextScale = configsBtnScale * 0.96f;
        float configsTextH = ImGui::GetFont()->CalcTextSizeA(18 * cfgTextScale, FLT_MAX, -1, configsLabel.c_str()).y;
        ImVec2 configsTextPos(scaledConfigsBtnRect.x + 40.0f * configsBtnScale, scaledConfigsBtnRect.y + (scaledConfigsBtnSize.y - configsTextH) / 2.0f);
        ImRenderUtils::drawText(configsTextPos, configsLabel, Interface::getTextColor(), cfgTextScale, finalAlpha, false);

        if (configsHovered && bottomSlide > 0.99f && buttonHideAnim > 0.99f && ImGui::IsMouseClicked(0) && !isHiding) {
            ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f);
            isHiding = true;
            displayConfigsMenu = true;
        }

        // IRC button (center)
        ImVec4 ircBtnRect(ircPos.x, ircPos.y, ircPos.x + btnSize.x, ircPos.y + btnSize.y);
        bool ircHovered = ImRenderUtils::isMouseOver(ircBtnRect);

        static float ircBtnScale = 1.0f;
        static bool wasIrcClicked = false;
        bool ircClicked = ircHovered && ImGui::IsMouseDown(0);
        float ircTargetScale = 1.0f;
        if (ircClicked) {
            ircTargetScale = 1.08f;
            wasIrcClicked = true;
        }
        else if (ircHovered) {
            ircTargetScale = 1.05f;
        }
        else {
            ircTargetScale = 1.0f;
        }
        ircBtnScale = MathUtils::animate(ircTargetScale, ircBtnScale, ImRenderUtils::getDeltaTime() * 12.0f);
        ImVec2 scaledIrcBtnSize(btnSize.x * ircBtnScale, btnSize.y * ircBtnScale);
        ImVec2 scaledIrcPos(
            ircPos.x - (scaledIrcBtnSize.x - btnSize.x) * 0.5f,
            ircPos.y - (scaledIrcBtnSize.y - btnSize.y) * 0.5f
        );
        ImVec4 scaledIrcBtnRect(scaledIrcPos.x, scaledIrcPos.y,
            scaledIrcPos.x + scaledIrcBtnSize.x, scaledIrcPos.y + scaledIrcBtnSize.y);

        ImColor ircBtnBgBase = Interface::getBlurBgColor();
        ImColor ircBtnBg = ircBtnBgBase;
        ircBtnBg.Value.w = (230.0f / 255.0f) * finalAlpha * ImRenderUtils::getGlobalAlpha();
        D2D::addBlurOptimized(ImGui::GetBackgroundDrawList(), 2.0f, scaledIrcBtnRect, 10.0f * ircBtnScale);
        ImRenderUtils::fillRectangle(scaledIrcBtnRect, ircBtnBgBase, finalAlpha * 0.90f, 10.0f * ircBtnScale);

        float ircIconPad = 12.0f * ircBtnScale;
        float scaledIrcIconSize = 18.0f * ircBtnScale;
        ImVec2 ircIconPos(scaledIrcBtnRect.x + ircIconPad, scaledIrcBtnRect.y + (scaledIrcBtnSize.y - scaledIrcIconSize) * 0.5f);

        ID3D11ShaderResourceView* ircIconTexture = nullptr;
        if (perfCache.textureCache.find("documents") != perfCache.textureCache.end()) {
            ircIconTexture = perfCache.textureCache["documents"];
        }

        if (ircIconTexture) {
            ImColor tcol = Interface::getTextColor();
            ImGui::GetBackgroundDrawList()->AddImage(
                ircIconTexture,
                ircIconPos,
                ImVec2(ircIconPos.x + scaledIrcIconSize, ircIconPos.y + scaledIrcIconSize),
                ImVec2(0, 0), ImVec2(1, 1),
                IM_COL32((int)(tcol.Value.x * 255.0f), (int)(tcol.Value.y * 255.0f), (int)(tcol.Value.z * 255.0f), (int)(255 * finalAlpha * ImRenderUtils::getGlobalAlpha()))
            );
            drawShineBand(ImGui::GetBackgroundDrawList(), ircIconTexture, ircIconPos, ImVec2(ircIconPos.x + scaledIrcIconSize, ircIconPos.y + scaledIrcIconSize), finalAlpha);
        }
        std::string ircLabel = "IRC";
        float ircTextScale = ircBtnScale * 0.96f;
        float ircTextH = ImGui::GetFont()->CalcTextSizeA(18 * ircTextScale, FLT_MAX, -1, ircLabel.c_str()).y;
        ImVec2 ircTextPos(scaledIrcBtnRect.x + 40.0f * ircBtnScale, scaledIrcBtnRect.y + (scaledIrcBtnSize.y - ircTextH) / 2.0f);
        ImRenderUtils::drawText(ircTextPos, ircLabel, Interface::getTextColor(), ircTextScale, finalAlpha, false);

        if (ircHovered && bottomSlide > 0.99f && buttonHideAnim > 0.99f && ImGui::IsMouseClicked(0) && !isHiding) {
            ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f);
            isHiding = true;
            displayIRCMenu = true;
        }

        ImVec4 spooferBtnRect(spooferPos.x, spooferPos.y, spooferPos.x + btnSize.x, spooferPos.y + btnSize.y);
        bool spooferHovered = ImRenderUtils::isMouseOver(spooferBtnRect);

        static float spooferBtnScale = 1.0f;
        static bool wasSpooferClicked = false;
        bool spooferClicked = spooferHovered && ImGui::IsMouseDown(0);
        float spooferTargetScale = 1.0f;
        if (spooferClicked) {
            spooferTargetScale = 1.08f;
            wasSpooferClicked = true;
        }
        else if (spooferHovered) {
            spooferTargetScale = 1.05f;
        }
        else {
            spooferTargetScale = 1.0f;
        }
        spooferBtnScale = MathUtils::animate(spooferTargetScale, spooferBtnScale, ImRenderUtils::getDeltaTime() * 12.0f);
        ImVec2 scaledSpooferBtnSize(btnSize.x * spooferBtnScale, btnSize.y * spooferBtnScale);
        ImVec2 scaledSpooferPos(
            spooferPos.x - (scaledSpooferBtnSize.x - btnSize.x) * 0.5f,
            spooferPos.y - (scaledSpooferBtnSize.y - btnSize.y) * 0.5f
        );
        ImVec4 scaledSpooferBtnRect(scaledSpooferPos.x, scaledSpooferPos.y,
            scaledSpooferPos.x + scaledSpooferBtnSize.x, scaledSpooferPos.y + scaledSpooferBtnSize.y);

        ImColor spooferBtnBgBase = Interface::getBlurBgColor();
        ImColor spooferBtnBg = spooferBtnBgBase;
        spooferBtnBg.Value.w = (230.0f / 255.0f) * finalAlpha * ImRenderUtils::getGlobalAlpha();
        D2D::addBlurOptimized(ImGui::GetBackgroundDrawList(), 2.0f, scaledSpooferBtnRect, 10.0f * spooferBtnScale);
        ImRenderUtils::fillRectangle(scaledSpooferBtnRect, spooferBtnBgBase, finalAlpha * 0.90f, 10.0f * spooferBtnScale);
        float spooferIconPad = 12.0f * spooferBtnScale;
        float scaledSpooferIconSize = 18.0f * spooferBtnScale;
        ImVec2 spooferIconPos(scaledSpooferBtnRect.x + spooferIconPad, scaledSpooferBtnRect.y + (scaledSpooferBtnSize.y - scaledSpooferIconSize) * 0.5f);

        ID3D11ShaderResourceView* spooferIconTexture = nullptr;
        if (perfCache.textureCache.find("documents") != perfCache.textureCache.end()) {
            spooferIconTexture = perfCache.textureCache["documents"];
        }

        if (spooferIconTexture) {
            ImColor tcol = Interface::getTextColor();
            ImGui::GetBackgroundDrawList()->AddImage(
                spooferIconTexture,
                spooferIconPos,
                ImVec2(spooferIconPos.x + scaledSpooferIconSize, spooferIconPos.y + scaledSpooferIconSize),
                ImVec2(0, 0), ImVec2(1, 1), IM_COL32((int)(tcol.Value.x * 255.0f), (int)(tcol.Value.y * 255.0f), (int)(tcol.Value.z * 255.0f), (int)(255 * finalAlpha * ImRenderUtils::getGlobalAlpha()))
            );
            drawShineBand(ImGui::GetBackgroundDrawList(), spooferIconTexture, spooferIconPos, ImVec2(spooferIconPos.x + scaledSpooferIconSize, spooferIconPos.y + scaledSpooferIconSize), finalAlpha);
        }
        std::string spooferLabel = "Spoofer";
        float spTextScale = spooferBtnScale * 0.96f;
        float spooferTextH = ImGui::GetFont()->CalcTextSizeA(18 * spTextScale, FLT_MAX, -1, spooferLabel.c_str()).y;
        ImVec2 spooferTextPos(scaledSpooferBtnRect.x + 40.0f * spooferBtnScale, scaledSpooferBtnRect.y + (scaledSpooferBtnSize.y - spooferTextH) / 2.0f);
        ImRenderUtils::drawText(spooferTextPos, spooferLabel, Interface::getTextColor(), spTextScale, finalAlpha, false);

        if (spooferHovered && bottomSlide > 0.99f && buttonHideAnim > 0.99f && ImGui::IsMouseClicked(0) && !isHiding) {
            ClientInstance::get()->playUi("random.pop2", 0.75f, 1.0f);
            isHiding = true;
            displaySpooferMenu = true;
        }
    }
    FontHelper::popPrefFont();
#endif  
}


void ModernGui::onWindowResizeEvent(WindowResizeEvent& event)
{
    resetPosition = true;
    lastReset = NOW;
    clearCache();
}

void ModernGui::clearCache()
{
    perfCache.sortedModsCache.clear();
    perfCache.filteredModsCache.clear();
    perfCache.settingsHeightCache.clear();
    perfCache.moduleColorAnims.clear();
    perfCache.modulesCacheValid = false;
    perfCache.lowercaseCacheValid = false;
    perfCache.lastSearchStr.clear();
    perfCache.textureCache.clear();
    perfCache.textureDimensions.clear();
    perfCache.cacheInitialized = false;
}

void ModernGui::initializeCache()
{
    if (perfCache.cacheInitialized) return;
    ID3D11ShaderResourceView* findTex = nullptr;
    int findW = 0, findH = 0;
    auto it = ResourceLoader::Resources.find("find");
    if (it != ResourceLoader::Resources.end()) {
        if (D3DHook::loadTextureFromEmbeddedResource("find", &findTex, &findW, &findH)) {
            perfCache.textureCache["find"] = findTex;
            perfCache.textureDimensions["find"] = { findW, findH };
        }
    }
    if (!findTex) {
        const char* candidates[] = {
            "find"
        };
        for (const char* c : candidates) {
            if (D3DHook::loadTextureFromEmbeddedResource(c, &findTex, &findW, &findH)) {
                perfCache.textureCache["find"] = findTex;
                perfCache.textureDimensions["find"] = { findW, findH };
                break;
            }
        }
    }
    ID3D11ShaderResourceView* cfgTex = nullptr;
    int cfgW = 0, cfgH = 0;
    auto cfgIt = ResourceLoader::Resources.find("documents");
    if (cfgIt != ResourceLoader::Resources.end()) {
        if (D3DHook::loadTextureFromEmbeddedResource("documents", &cfgTex, &cfgW, &cfgH)) {
            perfCache.textureCache["documents"] = cfgTex;
            perfCache.textureDimensions["documents"] = { cfgW, cfgH };
        }
    }

    ID3D11ShaderResourceView* crossTex = nullptr; int crossW = 0, crossH = 0;
    if (D3DHook::loadTextureFromEmbeddedResource("cross", &crossTex, &crossW, &crossH)) {
        perfCache.textureCache["cross"] = crossTex;
        perfCache.textureDimensions["cross"] = { crossW, crossH };
    }
    ID3D11ShaderResourceView* loadTex = nullptr; int loadW = 0, loadH = 0;
    if (D3DHook::loadTextureFromEmbeddedResource("load", &loadTex, &loadW, &loadH)) {
        perfCache.textureCache["load"] = loadTex;
        perfCache.textureDimensions["load"] = { loadW, loadH };
    }
    ID3D11ShaderResourceView* saveTex = nullptr; int saveW = 0, saveH = 0;
    if (D3DHook::loadTextureFromEmbeddedResource("save", &saveTex, &saveW, &saveH)) {
        perfCache.textureCache["save"] = saveTex;
        perfCache.textureDimensions["save"] = { saveW, saveH };
    }
    ID3D11ShaderResourceView* staffTex = nullptr; int staffW = 0, staffH = 0;
    {
        auto staffRes = ResourceLoader::Resources.find("staff.png");
        if (staffRes != ResourceLoader::Resources.end()) {
            if (D3DHook::loadTextureFromEmbeddedResource("staff.png", &staffTex, &staffW, &staffH)) {
                perfCache.textureCache["staff.png"] = staffTex;
                perfCache.textureDimensions["staff.png"] = { staffW, staffH };
            }
        }
    }
    auto& modules = gFeatureManager->mModuleManager->getModules();
    for (auto& module : modules) {
        perfCache.moduleColorAnims[module.get()] = module->mEnabled ? 1.0f : 0.0f;
    }

    perfCache.cacheInitialized = true;
}

void ModernGui::DrawRightRoundedInput(ImVec2 pos, ImVec2 size, float rounding, char* buffer, size_t buf_size, float alpha, float appear) {
    ImDrawList* drawList = ImGui::GetWindowDrawList();

    ImVec4 rect(pos.x, pos.y, pos.x + size.x, pos.y + size.y);
    D2D::addBlurOptimized(ImGui::GetBackgroundDrawList(), 18.0f, rect, rounding);
    
    ImColor searchBg = ImColor(40, 40, 40, 100); 
    drawList->AddRectFilled(
        pos,
        ImVec2(pos.x + size.x, pos.y + size.y),
        IM_COL32((int)(searchBg.Value.x * 255.0f), (int)(searchBg.Value.y * 255.0f), (int)(searchBg.Value.z * 255.0f), (int)(100 * alpha * ImRenderUtils::getGlobalAlpha())),
        12.0f,
        ImDrawFlags_RoundCornersAll
    );

    float baseIconSize = 14.0f;
    float iconPadding = 8.0f;
    float scale = MathUtils::lerp(0.9f, 1.0f, appear);
    float iconSize = baseIconSize * scale;
    ImVec2 iconPos(pos.x + iconPadding, pos.y + (size.y - iconSize) * 0.5f);

    ID3D11ShaderResourceView* findTex = nullptr;
    int findW = 0, findH = 0;
    auto itFind = perfCache.textureCache.find("find");
    if (itFind != perfCache.textureCache.end()) {
        findTex = itFind->second;
        auto dims = perfCache.textureDimensions["find"];
        findW = dims.first; findH = dims.second;
    }

    if (findTex) {
        ImVec2 pMin(iconPos.x, iconPos.y);
        ImVec2 pMax(iconPos.x + iconSize, iconPos.y + iconSize);
        ImColor iconColC = Interface::getTextColor();
        ImU32 col = IM_COL32((int)(iconColC.Value.x * 255.0f), (int)(iconColC.Value.y * 255.0f), (int)(iconColC.Value.z * 255.0f), (int)(230 * alpha * ImRenderUtils::getGlobalAlpha()));
        drawList->AddImage((ImTextureID)findTex, pMin, pMax, ImVec2(0, 0), ImVec2(1, 1), col);
        drawShineBand(drawList, findTex, pMin, pMax, alpha);
    }
    else {
        ImVec2 iconCenter(iconPos.x + iconSize * 0.5f, pos.y + size.y * 0.5f);
        float circleRadius = iconSize * 0.35f;
        float lineLength = iconSize * 0.3f;
        ImColor iconColC = Interface::getTextColor();
        ImU32 vcol = IM_COL32((int)(iconColC.Value.x * 200.0f), (int)(iconColC.Value.y * 200.0f), (int)(iconColC.Value.z * 200.0f), (int)(200 * alpha * ImRenderUtils::getGlobalAlpha()));
        drawList->AddCircle(
            ImVec2(iconCenter.x - lineLength * 0.3f, iconCenter.y - lineLength * 0.3f),
            circleRadius,
            vcol,
            12,
            1.5f
        );
        ImVec2 handleStart(iconCenter.x + lineLength * 0.2f, iconCenter.y + lineLength * 0.2f);
        ImVec2 handleEnd(iconCenter.x + lineLength, iconCenter.y + lineLength);
        drawList->AddLine(handleStart, handleEnd, vcol, 1.5f);
    }
    ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_TextSelectedBg, ImVec4(0.26f, 0.59f, 0.98f, 0.35f));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_TextDisabled, ImVec4(1.0f, 1.0f, 1.0f, 0.9f)); 
    ImGui::SetWindowFontScale(0.85f); 
    float verticalPadding = (size.y - ImGui::GetTextLineHeight()) * 0.5f;
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(25.0f, verticalPadding));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 12.0f);
    ImGui::SetCursorScreenPos(pos);
    ImGui::InputTextWithHint("##config_search", "Search...", buffer, buf_size);
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(4); 
    ImGui::SetWindowFontScale(1.0f);
}

void ModernGui::drawShineBand(ImDrawList* dl, ID3D11ShaderResourceView* tex, const ImVec2& pMin, const ImVec2& pMax, float alpha)
{
    if (!dl || !tex) return;
    if (alpha <= 0.01f) return;
    float w = pMax.x - pMin.x;
    float h = pMax.y - pMin.y;
    if (w <= 0.0f || h <= 0.0f) return;

    static float s_time = 0.0f;
    s_time += ImRenderUtils::getDeltaTime();
    float cycle = 6.0f;
    float lin = fmodf(s_time, cycle) / cycle;
    float t = lin * lin * lin * (lin * (lin * 6.0f - 15.0f) + 10.0f);

    float bandW = w * 0.50f;
    float softW = w * 0.30f;
    float bandX = pMin.x + t * (w + bandW) - bandW;

    float ga = ImRenderUtils::getGlobalAlpha();
    int aCenter = (int)(235.0f * alpha * ga);
    int aSide = (int)(140.0f * alpha * ga);

    auto drawClipped = [&](float x0, float x1, int a)
        {
            float clipMinX = std::max(pMin.x, x0);
            float clipMaxX = std::min(pMax.x, x1);
            if (clipMaxX <= clipMinX) return;
            dl->PushClipRect(ImVec2(clipMinX, pMin.y), ImVec2(clipMaxX, pMax.y), true);
            dl->AddImage((ImTextureID)tex, pMin, pMax, ImVec2(0, 0), ImVec2(1, 1), IM_COL32(255, 255, 255, std::clamp(a, 0, 255)));
            dl->PopClipRect();
        };

    auto drawGradientRegion = [&](float x0, float x1, int a0, int a1)
        {
            const int slices = 8;
            float width = (x1 - x0) / slices;
            for (int i = 0; i < slices; ++i)
            {
                float sx0 = x0 + width * i;
                float sx1 = sx0 + width;
                float k = (float)(i + 0.5f) / (float)slices;
                int a = (int)((1.0f - k) * a0 + k * a1);
                drawClipped(sx0, sx1, a);
            }
        };

    drawGradientRegion(bandX - softW, bandX, 0, aSide);
    drawClipped(bandX, bandX + bandW, aCenter);
    drawGradientRegion(bandX + bandW, bandX + bandW + softW, aSide, 0);
}

char ModernGui::searchBuffer[128] = "";
bool ModernGui::searchFocused = false;

void ModernGui::handleSearchInput(unsigned int key, bool down)
{
    if (!searchFocused || !down) return;
    size_t len = strlen(searchBuffer);
    if (key == VK_BACK) {
        if (len > 0) searchBuffer[len - 1] = '\0';
    }
    else if (key == VK_RETURN) {
        searchFocused = false;
    }
    else if (key >= 32 && key <= 126 && len < sizeof(searchBuffer) - 1) {
        searchBuffer[len] = (char)key;
        searchBuffer[len + 1] = '\0';
    }
}


void ModernGui::startWelcomeAnimation()
{
    static bool sessionWelcomeShown = false;

    if (!sessionWelcomeShown) {
        welcomeAnimationActive = true;
        welcomeAnimationTime = 0.0f;
        hasShownWelcome = true;
        sessionWelcomeShown = true;
    }
}

void ModernGui::resetWelcomeAnimation()
{
    welcomeAnimationActive = false;
    welcomeAnimationTime = 0.0f;
    hasShownWelcome = false;
}

void ModernGui::renderWelcomeAnimation(ImDrawList* drawList, ImVec2 screenSize)
{
    if (!welcomeAnimationActive) return;
    welcomeAnimationTime += ImRenderUtils::getDeltaTime();
    if (welcomeAnimationTime >= welcomeAnimationDuration) {
        welcomeAnimationActive = false;
        return;
    }
    ImFont* font = ImGui::GetFont();
    if (!font) return;
    float progress = welcomeAnimationTime / welcomeAnimationDuration;
    auto clamp01 = [](float x) { return std::clamp(x, 0.0f, 1.0f); };
    auto ease = [&](float x) { x = clamp01(x); return x * x * (3.0f - 2.0f * x); };
    auto easeSine = [&](float x) { x = clamp01(x); return 0.5f - 0.5f * cosf(x * 3.1415926f); };
    float backgroundAlpha = 1.0f;
    if (progress < 0.12f) {
        backgroundAlpha = ease(progress / 0.12f);
    }
    else if (progress > 0.82f) {
        backgroundAlpha = ease((1.0f - progress) / 0.18f);
    }
    drawList->AddRectFilled(
        ImVec2(0, 0),
        screenSize,
        IM_COL32(0, 0, 0, static_cast<int>(backgroundAlpha * 255))
    );
    float edgeW = 180.0f;
    for (int i = 0; i < (int)edgeW; i += 2) {
        float a = 1.0f - (float)i / edgeW;
        float ea = ease(a);
        int al = (int)(ea * 42.0f * backgroundAlpha * ImRenderUtils::getGlobalAlpha());
        drawList->AddRect(
            ImVec2((float)i, (float)i),
            ImVec2(screenSize.x - (float)i, screenSize.y - (float)i),
            IM_COL32(22, 22, 22, al),
            20.0f
        );
    }
    ImVec2 c1(0.0f, 0.0f);
    ImVec2 c2(screenSize.x, 0.0f);
    ImVec2 c3(0.0f, screenSize.y);
    ImVec2 c4(screenSize.x, screenSize.y);
    drawList->AddShadowCircle(ImVec2(c1.x, c1.y), 220.0f, ImColor(0, 0, 0, (int)(120 * backgroundAlpha * ImRenderUtils::getGlobalAlpha())), 60, ImVec2(0.0f, 0.0f), 0, 24);
    drawList->AddShadowCircle(ImVec2(c2.x, c2.y), 220.0f, ImColor(0, 0, 0, (int)(120 * backgroundAlpha * ImRenderUtils::getGlobalAlpha())), 60, ImVec2(0.0f, 0.0f), 0, 24);
    drawList->AddShadowCircle(ImVec2(c3.x, c3.y), 220.0f, ImColor(0, 0, 0, (int)(120 * backgroundAlpha * ImRenderUtils::getGlobalAlpha())), 60, ImVec2(0.0f, 0.0f), 0, 24);
    drawList->AddShadowCircle(ImVec2(c4.x, c4.y), 220.0f, ImColor(0, 0, 0, (int)(120 * backgroundAlpha * ImRenderUtils::getGlobalAlpha())), 60, ImVec2(0.0f, 0.0f), 0, 24);
    if (progress >= 0.12f && progress <= 0.82f) {
        float textProgress = (progress - 0.12f) / (0.82f - 0.12f);
        float textAlpha = sinf(clamp01(textProgress) * 3.1415926f);
        float textScale = 1.0f + 0.01f * easeSine(textProgress);
        std::string helloText = "welcome to EverLast";
        float fontSize = 36.0f;
        ImVec2 baseSize = font->CalcTextSizeA(fontSize, FLT_MAX, -1, helloText.c_str());
        ImVec2 startPos((screenSize.x - baseSize.x) * 0.5f, (screenSize.y - baseSize.y) * 0.5f);
        ImVec2 p = startPos;
        float t = ImGui::GetTime();
        static std::vector<float> ySmooth;
        static std::vector<float> aSmooth;
        if (ySmooth.size() != helloText.size()) {
            ySmooth.assign(helloText.size(), 0.0f);
            aSmooth.assign(helloText.size(), 0.0f);
        }
        float dt = ImRenderUtils::getDeltaTime();
        for (size_t i = 0; i < helloText.size(); ++i) {
            char c = helloText[i];
            ImVec2 chSize = font->CalcTextSizeA(fontSize, FLT_MAX, -1, &c, &c + 1);
            float wave = sinf((float)i * 0.22f + t * 1.6f);
            float aMul = std::clamp(wave * 0.35f + 0.65f, 0.45f, 1.0f);
            float aTarget = textAlpha * aMul;
            float yTarget = sinf((float)i * 0.16f + t * 1.4f) * 2.0f;
            ySmooth[i] = MathUtils::animate(yTarget, ySmooth[i], dt * 10.0f);
            aSmooth[i] = MathUtils::animate(aTarget, aSmooth[i], dt * 10.0f);
            int a = (int)(std::clamp(aSmooth[i], 0.0f, 1.0f) * 255.0f);
            ImColor col = ImColor(255, 255, 255, a);
            drawList->AddText(font, fontSize * textScale, ImVec2(p.x, p.y + ySmooth[i]), col, &c, &c + 1);
            p.x += chSize.x;
        }
        ImVec2 center(startPos.x + baseSize.x * 0.5f, startPos.y + baseSize.y * 0.5f);
        drawList->AddShadowCircle(center, baseSize.x * 0.35f, ImColor(255, 255, 255, (int)(38 * textAlpha * ImRenderUtils::getGlobalAlpha())), 90, ImVec2(0.0f, 0.0f), 0, 28);
    }
}

void ModernGui::initializeSnow()
{
    snowflakes.clear();
    snowSpawnTimer = 0.0f;
    snowInitialized = true;
    ImVec2 screen = ImRenderUtils::getScreenSize();
    int initCount = MAX_SNOW / 2;
    for (int i = 0; i < initCount; ++i) {
        Snowflake s;
        s.x = static_cast<float>(rand() % static_cast<int>(screen.x));
        s.y = static_cast<float>(rand() % static_cast<int>(static_cast<int>(screen.y)));
        s.vx = 0.0f;
        s.vy = 40.0f + static_cast<float>(rand() % 60);
        s.radius = 1.0f + static_cast<float>(rand() % 3);
        s.alpha = 0.35f + (rand() % 65) / 255.0f;
        s.swayPhase = static_cast<float>(rand() % 628) / 100.0f;
        s.swaySpeed = 0.5f + static_cast<float>(rand() % 150) / 100.0f;
        s.swayAmp = 6.0f + static_cast<float>(rand() % 80) / 10.0f;
        snowflakes.push_back(s);
    }
}

void ModernGui::updateSnow(float deltaTime)
{
    ImVec2 screen = ImRenderUtils::getScreenSize();
    snowSpawnTimer += deltaTime;
    float spawnInterval = 0.02f;
    while (snowflakes.size() < MAX_SNOW && snowSpawnTimer >= spawnInterval) {
        snowSpawnTimer -= spawnInterval;
        Snowflake s;
        s.x = static_cast<float>(rand() % static_cast<int>(screen.x));
        s.y = -10.0f;
        s.vx = 0.0f;
        s.vy = 60.0f + static_cast<float>(rand() % 80);
        s.radius = 1.0f + static_cast<float>(rand() % 3);
        s.alpha = 0.35f + (rand() % 65) / 255.0f;
        s.swayPhase = static_cast<float>(rand() % 628) / 100.0f;
        s.swaySpeed = 0.8f + static_cast<float>(rand() % 180) / 100.0f;
        s.swayAmp = 8.0f + static_cast<float>(rand() % 100) / 10.0f;
        snowflakes.push_back(s);
    }

    for (auto& s : snowflakes) {
        s.swayPhase += s.swaySpeed * deltaTime;
        float sway = cosf(s.swayPhase) * s.swayAmp * deltaTime;
        s.x += sway;
        s.y += s.vy * deltaTime;
    }

    for (auto& s : snowflakes) {
        if (s.x < -20.0f) s.x = screen.x + 20.0f;
        if (s.x > screen.x + 20.0f) s.x = -20.0f;
    }

    snowflakes.erase(
        std::remove_if(snowflakes.begin(), snowflakes.end(), [&](const Snowflake& s) { return s.y > screen.y + 20.0f; }),
        snowflakes.end()
    );
}

void ModernGui::renderSnow(ImDrawList* drawList, float animation)
{
    if (animation <= 0.0f) return;
    float ga = ImRenderUtils::getGlobalAlpha();
    for (const auto& s : snowflakes) {
        int a = (int)(255.0f * s.alpha * ga);
        drawList->AddCircleFilled(ImVec2(s.x, s.y), s.radius, IM_COL32(255, 255, 255, a), 12);
    }
}
ID3D11ShaderResourceView* ModernGui::getTextureCached(const std::string& key, int& w, int& h)
{
    auto it = perfCache.textureCache.find(key);
    if (it != perfCache.textureCache.end()) {
        auto dims = perfCache.textureDimensions[key];
        w = dims.first; h = dims.second;
        return it->second;
    }
    ID3D11ShaderResourceView* tex = nullptr; int tw = 0, th = 0;
    if (D3DHook::loadTextureFromEmbeddedResource(key.c_str(), &tex, &tw, &th)) {
        perfCache.textureCache[key] = tex;
        perfCache.textureDimensions[key] = { tw, th };
        w = tw; h = th;
        return tex;
    }
    w = 0; h = 0; return nullptr;
}



