#pragma once
#include <imgui.h>
#include <string>
#include <Utils/MiscUtils/ImRenderUtils.hpp>

namespace GuiBuildInfo {
    inline void Render(ImDrawList* drawList, ImVec2 screenSize) {
        // Simple implementation to satisfy the linker and compiler
        // You can customize this later
        std::string buildText = "Build: User Debug";
        ImVec2 textSize = ImGui::GetFont()->CalcTextSizeA(18.0f, FLT_MAX, -1.0f, buildText.c_str());
        ImVec2 pos(10.0f, 10.0f);
        
        ImRenderUtils::drawText(pos, buildText, ImColor(255, 255, 255), 1.0f, 1.0f, true);
    }
}
