//
// Created by vastrakai on 6/29/2024.
//

#pragma once

#include "Event.hpp"

class RenderEvent : public Event {
public:
    RenderEvent() : Event() {}
};