﻿



#include "Speed.hpp"

#include <Features/FeatureManager.hpp>
#include <Features/Events/BaseTickEvent.hpp>
#include <Features/Events/PacketInEvent.hpp>
#include <Features/Events/PacketOutEvent.hpp>
#include <Features/Events/RunUpdateCycleEvent.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>
#include <Features/Modules/Player/Scaffold.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/KeyboardMouseSettings.hpp>
#include <SDK/Minecraft/MinecraftSim.hpp>
#include <SDK/Minecraft/Inventory/PlayerInventory.hpp>
#include <SDK/Minecraft/Network/Packets/PlayerAuthInputPacket.hpp>
#include <SDK/Minecraft/Network/Packets/MobEffectPacket.hpp>
#include <SDK/Minecraft/Network/Packets/SetActorMotionPacket.hpp>

void Speed::onEnable()
{
    gFeatureManager->mDispatcher->listen<BaseTickEvent, &Speed::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketInEvent, &Speed::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketOutEvent, &Speed::onPacketOutEvent>(this);
    gFeatureManager->mDispatcher->listen<RunUpdateCycleEvent, &Speed::onRunUpdateCycleEvent>(this);
}

void Speed::onDisable()
{
    gFeatureManager->mDispatcher->deafen<BaseTickEvent, &Speed::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketInEvent, &Speed::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketOutEvent, &Speed::onPacketOutEvent>(this);
    gFeatureManager->mDispatcher->deafen<RunUpdateCycleEvent, &Speed::onRunUpdateCycleEvent>(this);
    ClientInstance::get()->getMinecraftSim()->setSimTimer(20.f);
}

void Speed::onRunUpdateCycleEvent(RunUpdateCycleEvent& event)
{
    if (event.isCancelled() || event.mApplied) return;

    static auto scaffold = gFeatureManager->mModuleManager->getModule<Scaffold>();
    if (scaffold->mEnabled) return;

    /*if (mMode.mValue != Mode::Friction) {
        Sleep(101);
    }*/
}


void Speed::onBaseTickEvent(BaseTickEvent& event)
{
    auto player = event.mActor;
    if (!player) return;
    if (player->getFlag<RedirectCameraInputComponent>()) return;

    if (mMode.mValue == Mode::Friction)
    {
        tickFriction(player);
    }
    else if (mMode.mValue == Mode::Legit)
    {
        tickLegit(player);
    }
    else if (mMode.mValue == Mode::NT)
    {
        tickNT(player);
    }
}

void Speed::onPacketInEvent(PacketInEvent& event)
{
    if (event.mPacket->getId() == PacketID::SetActorMotion && mDamageBoost.mValue)
    {
        auto sam = event.getPacket<SetActorMotionPacket>();
        auto player = ClientInstance::get()->getLocalPlayer();
        if (!player) return;

        if (sam->mRuntimeID == player->getRuntimeID())
        {
            mDamageBoostVal = mDamageBoostSpeed.as<float>();
        }
    }
    if (event.mPacket->getId() == PacketID::MobEffect)
    {
        auto player = ClientInstance::get()->getLocalPlayer();
        if (!player) return;

        auto mep = event.getPacket<MobEffectPacket>();

        if (mep->mRuntimeId != player->getRuntimeID()) return;

        auto effect = std::string(mep->getEffectName());
        auto eventName = std::string(mep->getEventName());
        uint64_t time = mep->mEffectDurationTicks * 50;

        if (mep->mEventId == MobEffectPacket::Event::Add) {
            mEffectTimers[mep->mEffectId] = NOW + time;
        } else if (mep->mEventId == MobEffectPacket::Event::Remove) {
            mEffectTimers.erase(mep->mEffectId);
        }

        spdlog::info("Effect: {} Event: {} Time: {}", effect, eventName, time);
    }

    if (!mEnabled) return;
}

void Speed::onPacketOutEvent(PacketOutEvent& event)
{
    if (event.mPacket->getId() == PacketID::PlayerAuthInput)
    {
        auto paip = event.getPacket<PlayerAuthInputPacket>();
        auto player = ClientInstance::get()->getLocalPlayer();
        if (Keyboard::isUsingMoveKeys()) paip->mInputData |= AuthInputAction::JUMPING | AuthInputAction::WANT_UP | AuthInputAction::JUMP_DOWN;
        if (!player->isOnGround() && player->wasOnGround() && Keyboard::isUsingMoveKeys()) {
            paip->mInputData |= AuthInputAction::START_JUMPING;
        }
    }
}

void Speed::tickLegit(Actor* player)
{
    if (mTimerBoost.mValue) ClientInstance::get()->getMinecraftSim()->setSimTimer(mTimerSpeed.as<float>());
    else ClientInstance::get()->getMinecraftSim()->setSimTimer(20.f);

    static int tick = 0;
    if (player->isOnGround()) tick = 0;
    else tick++;

    if (mFastFall.mValue == FastfallMode::Predict)
    {
        if (tick == mFallTicks.as<int>())
        {
            auto fallSpeed = mFallSpeed.as<float>();
            auto stateVector = player->getStateVectorComponent();
            for (int i = 0; i < fallSpeed; i++)
            {
                stateVector->mVelocity.y = (stateVector->mVelocity.y - 0.08f) * 0.98f;
            }
        }
        if (mFastFall2.mValue && tick == mFallTicks2.as<int>())
        {
            auto fallSpeed = mFallSpeed2.as<float>();
            auto stateVector = player->getStateVectorComponent();
            for (int i = 0; i < fallSpeed; i++)
            {
                stateVector->mVelocity.y = (stateVector->mVelocity.y - 0.08f) * 0.98f;
            }
        }
    } 
    else if (mFastFall.mValue == FastfallMode::SetVel)
    {
        if (tick == mFallTicks.as<int>())
        {
            auto fallSpeed = mFallSpeed.as<float>() / 10;
            auto stateVector = player->getStateVectorComponent();
            stateVector->mVelocity.y = -fallSpeed;
        }
        if (mFastFall2.mValue && tick == mFallTicks2.as<int>())
        {
            auto fallSpeed = mFallSpeed2.as<float>() / 10;
            auto stateVector = player->getStateVectorComponent();
            stateVector->mVelocity.y = -fallSpeed;
        }
    }

    glm::vec3 velocity = player->getStateVectorComponent()->mVelocity;
    float movementSpeed = sqrt(velocity.x * velocity.x + velocity.z * velocity.z);

    if (!player->isOnGround() && Keyboard::isUsingMoveKeys() && player->wasOnGround())
    {
        movementSpeed += (mSpeed.as<float>() / 10 / 10);
    }
    else if (Keyboard::isUsingMoveKeys() && !player->isOnGround() && !player->wasOnGround() && player->getFallDistance() > 0) {
        movementSpeed *= mFriction.as<float>();
    }

    float movementYaw = atan2(velocity.z, velocity.x);
    float movementYawDegrees = movementYaw * (180.0f / M_PI) - 90.f;
    float newMovementYaw = movementYaw;

    glm::vec3 newVelocity = {cos(newMovementYaw) * movementSpeed, velocity.y, sin(newMovementYaw) * movementSpeed};
    if (mSpeed.mValue != 0)
        player->getStateVectorComponent()->mVelocity = newVelocity;
}

void Speed::tickNT(Actor* player)
{
    FrictionPreset preset;
    preset.speed = mSpeed.as<float>();
    preset.strafe = false;
    preset.useStrafeSpeed = false;
    preset.strafeSpeed = 0.5;
    preset.friction = mFriction.as<float>();
    preset.timerBoost = true;
    preset.timerSpeed = mNTTimerBoostSpeed.as<float>();
    preset.fastFall = mNTFastFall.mValue;
    preset.fallTicks = mNTJumpMs.as<int>();
    preset.fallSpeed = mNTFallSpeed.as<float>();
    preset.fastFall2 = false;
    preset.fallTicks2 = 5;
    preset.fallSpeed2 = 1.00;
    preset.jumpType = JumpType::Vanilla;
    preset.jumpHeight = 0.42f;

    tickFrictionPreset(preset);
}

void Speed::tickFriction(Actor* player)
{
    if (mTimerBoost.mValue) ClientInstance::get()->getMinecraftSim()->setSimTimer(mTimerSpeed.as<float>());
    else ClientInstance::get()->getMinecraftSim()->setSimTimer(20.f);

    static auto friction = mFriction.as<float>();
    static int tick = 0;

    if (player->isOnGround())
    {
        friction = 1.f;
        tick = 0;
    }
    else
    {
        friction *= mFriction.as<float>();
        tick++;
    }

    
    if (mFastFall.mValue == FastfallMode::Predict)
    {
        if (tick == mFallTicks.as<int>())
        {
            auto fallSpeed = mFallSpeed.as<float>();
            auto stateVector = player->getStateVectorComponent();
            for (int i = 0; i < fallSpeed; i++)
            {
                stateVector->mVelocity.y = (stateVector->mVelocity.y - 0.08f) * 0.98f;
            }
        }
        if (mFastFall2.mValue && tick == mFallTicks2.as<int>())
        {
            auto fallSpeed = mFallSpeed2.as<float>();
            auto stateVector = player->getStateVectorComponent();
            for (int i = 0; i < fallSpeed; i++)
            {
                stateVector->mVelocity.y = (stateVector->mVelocity.y - 0.08f) * 0.98f;
            }
        }
    } 
    else if (mFastFall.mValue == FastfallMode::SetVel)
    {
        if (tick == mFallTicks.as<int>())
        {
            auto fallSpeed = mFallSpeed.as<float>() / 10;
            auto stateVector = player->getStateVectorComponent();
            stateVector->mVelocity.y = -fallSpeed;
        }
        if (mFastFall2.mValue && tick == mFallTicks2.as<int>())
        {
            auto fallSpeed = mFallSpeed2.as<float>() / 10;
            auto stateVector = player->getStateVectorComponent();
            stateVector->mVelocity.y = -fallSpeed;
        }
    }

    float speed = mSpeed.as<float>();

    glm::vec2 motion = MathUtils::getMotion(player->getActorRotationComponent()->mYaw, (speed / 10) * friction, false);
    auto stateVector = player->getStateVectorComponent();
    stateVector->mVelocity = {motion.x, stateVector->mVelocity.y, motion.y};
};


void Speed::tickFrictionPreset(FrictionPreset& preset)
{
    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;
    bool timerBoostSettting = preset.timerBoost;
    float timerSpeedSetting = preset.timerSpeed;
    float frictionSetting = preset.friction;
    float speedSetting = preset.speed;
    bool strafeSetting = preset.strafe;
    bool useStrafeSpeedSetting = preset.useStrafeSpeed;
    float strafeSpeedSetting = preset.strafeSpeed;
    FastfallMode fastFallSetting = preset.fastFall;
    int fallTicksSetting = preset.fallTicks;
    float fallSpeedSetting = preset.fallSpeed;
    bool fastFall2Setting = preset.fastFall2;
    int fallTicks2Setting = preset.fallTicks2;
    float fallSpeed2Setting = preset.fallSpeed2;
    JumpType jumpTypeSetting = preset.jumpType;
    float jumpHeightSetting = preset.jumpHeight;

    if (Keyboard::isStrafing() && useStrafeSpeedSetting) speedSetting = strafeSpeedSetting;

    if (timerBoostSettting) ClientInstance::get()->getMinecraftSim()->setSimTimer(timerSpeedSetting);
    else ClientInstance::get()->getMinecraftSim()->setSimTimer(20.f);

    static float friction = frictionSetting;
    static int tick = 0;

    if (player->isOnGround())
    {
        friction = 1.f;
        tick = 0;
    }
    else
    {
        friction *= frictionSetting;
        tick++;
    }

    
    if (fastFallSetting == FastfallMode::Predict)
    {
        if (tick == fallTicksSetting)
        {
            auto fallSpeed = fallSpeedSetting;
            auto stateVector = player->getStateVectorComponent();
            for (int i = 0; i < fallSpeed; i++)
            {
                stateVector->mVelocity.y = (stateVector->mVelocity.y - 0.08f) * 0.98f;
            }
        }
        if (fastFall2Setting && tick == fallTicks2Setting)
        {
            auto fallSpeed = fallSpeed2Setting;
            auto stateVector = player->getStateVectorComponent();
            for (int i = 0; i < fallSpeed; i++)
            {
                stateVector->mVelocity.y = (stateVector->mVelocity.y - 0.08f) * 0.98f;
            }
        }
    } 
    else if (fastFallSetting == FastfallMode::SetVel)
    {
        if (tick == fallTicksSetting)
        {
            auto fallSpeed = fallSpeedSetting / 10;
            auto stateVector = player->getStateVectorComponent();
            stateVector->mVelocity.y = -fallSpeed;
        }
        if (fastFall2Setting && tick == fallTicks2Setting)
        {
            auto fallSpeed = fallSpeed2Setting / 10;
            auto stateVector = player->getStateVectorComponent();
            stateVector->mVelocity.y = -fallSpeed;
        }
    }

    glm::vec2 motion = MathUtils::getMotion(player->getActorRotationComponent()->mYaw, (speedSetting / 10) * friction, false);
    auto stateVector = player->getStateVectorComponent();
    stateVector->mVelocity = {motion.x, stateVector->mVelocity.y, motion.y};

    bool usingMoveKeys = Keyboard::isUsingMoveKeys();
    if (usingMoveKeys && jumpTypeSetting == JumpType::Vanilla) {
        if (player->isOnGround())
        {
            player->jumpFromGround();
            player->getStateVectorComponent()->mVelocity.y = jumpHeightSetting;
        }
    } else if (usingMoveKeys && jumpTypeSetting == JumpType::Velocity) {
        if (player->isOnGround()) {
            player->getStateVectorComponent()->mVelocity.y = jumpHeightSetting;
        }
    }
};