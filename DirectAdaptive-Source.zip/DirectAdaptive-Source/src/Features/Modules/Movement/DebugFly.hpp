


#pragma once

#include <Features/Modules/Module.hpp>

class DebugFly : public ModuleBase<DebugFly> {
public:
    enum class SpeedMode {
        Static,
        Decrease,
        Loop,
        Wave,
        Test
    };

    enum class TimerMode {
        Static,
        Decrease,
        Loop,
        Wave
    };

    EnumSettingT<SpeedMode> mSpeedMode = EnumSettingT("Режим скорости", "Режим изменения скорости", SpeedMode::Static,  "Статичный", "Уменьшение", "Цикл", "Волна", "Тест");
    EnumSettingT<TimerMode> mTimerMode = EnumSettingT("Режим таймера", "Режим изменения таймера", TimerMode::Wave,  "Статичный", "Уменьшение", "Цикл", "Волна");

    NumberSetting mSpeed = NumberSetting("Скорость", "Скорость полета", 39.64594650268555, 1, 80, 0.1);
    NumberSetting mMinSpeed = NumberSetting("Мин. скорость", "Минимальная скорость полета", 40.864864349365234, 0, 80, 0.1);
    NumberSetting mMaxSpeed = NumberSetting("Макс. скорость", "Максимальная скорость полета", 51.24324417114258, 0, 80, 0.1);
    NumberSetting mSpeedMultiplier = NumberSetting("Множитель скорости", "Увеличение горизонтальной скорости", 2.1891891956329346, 0, 10, 0.1);
    NumberSetting mDelayTick = NumberSetting("Задержка тиков", "Задержка в тиках", 0, 0, 5, 0.1);
    NumberSetting mTimer = NumberSetting("Таймер", "Таймер скорости игры", 0.36486488580703735, 0, 3, 0.1);
    NumberSetting mTimerMin = NumberSetting("Мин. таймер", "Минимальное значение таймера", 0.30000001192092896, 0, 1, 0.1);
    NumberSetting mTimerMax = NumberSetting("Макс. таймер", "Максимальное значение таймера", 0.5756756663322449, 0, 5, 0.1);
    NumberSetting mTimerMultiplier = NumberSetting("Множитель таймера", "Множитель значения таймера", 2.1351351737976074, 0, 1, 0.1);
    NumberSetting mGlide = NumberSetting("Скольжение", "Параметр скольжения", 1.921621561050415, 0, 10, 0.1);

    BoolSetting mTestGlide = BoolSetting("Множитель скольжения", "Использовать множитель скольжения", true);
    BoolSetting mFullStop = BoolSetting("Полная остановка", "Останавливать движение полностью", true);
    BoolSetting mDebug = BoolSetting("Отладка", "Режим отладки", true);


    DebugFly() : ModuleBase("DebugFly", "Полет на 190 блоков (конфиг по умолчанию)", ModuleCategory::Movement, 0, false) {
        
        addSettings(
            &mSpeedMode,
            &mTimerMode,
            &mSpeed,
            &mMinSpeed,
            &mMaxSpeed,
            &mSpeedMultiplier,
            &mDelayTick,
            &mTimer,
            &mTimerMin,
            &mTimerMax,
            &mTimerMultiplier,
            &mGlide,
            &mTestGlide,
            &mFullStop,
            &mDebug
        );

        mNames = {
            {Lowercase, "debugfly"},
            {LowercaseSpaced, "debug fly"},
            {Normal, "DebugFly"},
            {NormalSpaced, "Debug Fly"}
        };
    }

    bool mJustEnabled = false;

    int mSpeedIndex = 0;
    int mTimerIndex = 0;

    bool mIsSpeedIncrease = false;
    bool mIsTimerIncrease = false;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
};
