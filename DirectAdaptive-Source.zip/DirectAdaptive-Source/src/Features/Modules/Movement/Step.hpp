#pragma once





class Step : public ModuleBase<Step>
{
public:
    enum class Mode {
        Vanilla,
        Flareon,
        FlareonV2
    };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим работы модуля", Mode::Vanilla, "Ванилла", "Flareon", "FlareonV2");
    NumberSetting mStepHeight = NumberSetting("Высота", "Максимальная высота шага", 0.50f, 0.0f, 5.f, 0.1f);

    Step() : ModuleBase<Step>("Step", "Позволяет быстро подниматься на блоки", ModuleCategory::Movement, 0, false) {
        addSetting(&mMode);
        addSetting(&mStepHeight);

        mNames = {
            {Lowercase, "step"},
            {LowercaseSpaced, "step"},
            {Normal, "Step"},
            {NormalSpaced, "Step"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
};