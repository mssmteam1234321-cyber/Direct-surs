﻿#pragma once



#include <Features/FeatureManager.hpp>
#include <Features/Modules/Module.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>
#include <SDK/Minecraft/Network/Packets/MobEffectPacket.hpp>
#include <unordered_map>

enum class JumpType {
    Vanilla,
    Velocity,
    None
};


enum class FastfallMode {
    None,
    Predict,
    SetVel
};


struct FrictionPreset
{
    float speed = 0.5;
    bool strafe = true;
    bool useStrafeSpeed = true;
    float strafeSpeed = 0.5;
    float friction = 0.975;
    bool timerBoost = false;
    float timerSpeed = 20;
    FastfallMode fastFall = FastfallMode::None;
    int fallTicks = 5;
    float fallSpeed = 1.00;
    bool fastFall2 = false;
    int fallTicks2 = 5;
    float fallSpeed2 = 1.00;
    JumpType jumpType = JumpType::Vanilla;
    float jumpHeight = 0.42f;

    FrictionPreset() = default;
    FrictionPreset(float speed, bool strafe, bool useStrafeSpeed, float strafeSpeed, float friction, bool timerBoost, float timerSpeed, FastfallMode fastFall, int fallTicks, float fallSpeed, bool fastFall2, int fallTicks2, float fallSpeed2, JumpType jumpType, float jumpHeight)
        : speed(speed), strafe(strafe), useStrafeSpeed(useStrafeSpeed), strafeSpeed(strafeSpeed), friction(friction), timerBoost(timerBoost), timerSpeed(timerSpeed), fastFall(fastFall), fallTicks(fallTicks), fallSpeed(fallSpeed), fastFall2(fastFall2), fallTicks2(fallTicks2), fallSpeed2(fallSpeed2), jumpType(jumpType), jumpHeight(jumpHeight)
    {}
};

class Speed : public ModuleBase<Speed> {
public:
    enum class Mode {
        Friction,
        Legit,
        NT
    };

    enum class BypassMode {
        Always,
        StrafeOnly
    };

    EnumSettingT<Mode> mMode = EnumSettingT("Режим", "Режим работы скорости", Mode::Friction, "Friction", "Legit", "NT Speed");

    NumberSetting mSpeed = NumberSetting("Скорость", "Скорость движения", 0.5, 0, 10, 0.01);
    NumberSetting mFriction = NumberSetting("Трение", "Сила трения", 0.975, 0, 1, 0.01);
    BoolSetting mTimerBoost = BoolSetting("Буст таймера", "Ускорять ли таймер", false);
    NumberSetting mTimerSpeed = NumberSetting("Скорость таймера", "Скорость ускорения таймера", 20, 0, 40, 0.1);

    EnumSettingT<FastfallMode> mFastFall = EnumSettingT("Быстрое падение", "Режим быстрого падения", FastfallMode::None, "Нет", "Предикт", "Велосити");
    NumberSetting mFallTicks = NumberSetting("Тики падения", "Тик срабатывания падения", 5, 0, 20, 1);
    NumberSetting mFallSpeed = NumberSetting("Скорость падения", "Скорость движения вниз", 1.00, 0, 10, 0.01);
    BoolSetting mFastFall2 = BoolSetting("Быстрое падение 2", "Использовать второе быстрое падение", false);
    NumberSetting mFallTicks2 = NumberSetting("Тики падения 2", "Тик срабатывания падения (2)", 5, 0, 20, 1);
    NumberSetting mFallSpeed2 = NumberSetting("Скорость падения 2", "Скорость движения вниз (2)", 1.00, 0, 10, 0.01);

    EnumSettingT<FastfallMode> mNTFastFall = EnumSettingT("Быстрое падение (NT)", "Режим быстрого падения для NT Speed", FastfallMode::None, "Нет", "Предикт", "Set Vel");
    NumberSetting mNTJumpMs = NumberSetting("Прыжок мс", "Задержка перед движением вниз", 5, 0, 20, 1);
    NumberSetting mNTFallSpeed = NumberSetting("Скорость (NT)", "Скорость падения", 1.00, 0, 10, 0.01);
    NumberSetting mNTTimerBoostSpeed = NumberSetting("Буст таймера (NT)", "Скорость ускорения таймера в NT Speed", 20, 0, 40, 0.1);

    BoolSetting mExtraHeight = BoolSetting("Доп. Высота", "Дополнительная высота", false);
    NumberSetting mClipHeight = NumberSetting("Высота клипа", "Высота для клипа", 1.00, 0, 2, 0.1);

    BoolSetting mDamageBoost = BoolSetting("Ускорение от урона", "Ускоряться при получении урона", false);
    NumberSetting mDamageBoostSpeed = NumberSetting("Скорость от урона", "Значение ускорения", 0.0, 0, 10, 0.01);
    float mDamageBoostVal = 0.0f;
    std::unordered_map<EffectType, uint64_t> mEffectTimers;

    Speed() : ModuleBase("Speed", "Позволяет вам двигаться быстрее", ModuleCategory::Movement, 0, false) {
        addSettings(
            &mMode,
            &mSpeed,
            &mFriction,
            &mTimerBoost,
            &mTimerSpeed,
            &mFastFall,
            &mFallTicks,
            &mFallSpeed,
            &mFastFall2,
            &mFallTicks2,
            &mFallSpeed2,
            &mNTFastFall,
            &mNTJumpMs,
            &mNTFallSpeed,
            &mNTTimerBoostSpeed,
            &mDamageBoost,
            &mDamageBoostSpeed
        );
#ifdef __PRIVATE_BUILD__
        addSettings(&mExtraHeight, &mClipHeight);
#endif

        VISIBILITY_CONDITION(mSpeed, mMode.mValue == Mode::Friction || mMode.mValue == Mode::Legit || mMode.mValue == Mode::NT);
        VISIBILITY_CONDITION(mFriction, mMode.mValue == Mode::Friction || mMode.mValue == Mode::Legit || mMode.mValue == Mode::NT);
        VISIBILITY_CONDITION(mTimerBoost, mMode.mValue == Mode::Friction || mMode.mValue == Mode::Legit);
        VISIBILITY_CONDITION(mTimerSpeed, (mMode.mValue == Mode::Friction || mMode.mValue == Mode::Legit) && mTimerBoost.mValue);
        VISIBILITY_CONDITION(mFastFall, mMode.mValue == Mode::Friction || mMode.mValue == Mode::Legit);
        VISIBILITY_CONDITION(mFallTicks, mMode.mValue == Mode::Friction && mFastFall.mValue != FastfallMode::None || mMode.mValue == Mode::Legit && mFastFall.mValue != FastfallMode::None);
        VISIBILITY_CONDITION(mFallSpeed, mMode.mValue == Mode::Friction && mFastFall.mValue != FastfallMode::None || mMode.mValue == Mode::Legit && mFastFall.mValue != FastfallMode::None);
        VISIBILITY_CONDITION(mFastFall2, mMode.mValue == Mode::Friction && mFastFall.mValue != FastfallMode::None || mMode.mValue == Mode::Legit && mFastFall.mValue != FastfallMode::None);
        VISIBILITY_CONDITION(mFallTicks2, mMode.mValue == Mode::Friction && mFastFall.mValue != FastfallMode::None && mFastFall2.mValue || mMode.mValue == Mode::Legit && mFastFall.mValue != FastfallMode::None && mFastFall2.mValue);
        VISIBILITY_CONDITION(mFallSpeed2, mMode.mValue == Mode::Friction && mFastFall.mValue != FastfallMode::None && mFastFall2.mValue || mMode.mValue == Mode::Legit && mFastFall.mValue != FastfallMode::None && mFastFall2.mValue);

        VISIBILITY_CONDITION(mNTFastFall, mMode.mValue == Mode::NT);
        VISIBILITY_CONDITION(mNTJumpMs, mMode.mValue == Mode::NT && mNTFastFall.mValue != FastfallMode::None);
        VISIBILITY_CONDITION(mNTFallSpeed, mMode.mValue == Mode::NT && mNTFastFall.mValue != FastfallMode::None);
        VISIBILITY_CONDITION(mNTTimerBoostSpeed, mMode.mValue == Mode::NT);

        mNames = {
            {Lowercase, "speed"},
            {LowercaseSpaced, "speed"},
            {Normal, "Speed"},
            {NormalSpaced, "Speed"}
        };

    }

    void onEnable() override;
    void onDisable() override;
    void onRunUpdateCycleEvent(class RunUpdateCycleEvent& event);
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
    void tickLegit(Actor* player);
    void tickFriction(Actor* player);
    void tickNT(Actor* player);
    void tickFrictionPreset(FrictionPreset& preset);

    std::string getSettingDisplay() override
    {
        return mMode.mValues[mMode.as<int>()];
    }
};
