#pragma once




#include <Features/Modules/Module.hpp>

class Sprint : public ModuleBase<Sprint>
{
public:
    Sprint() : ModuleBase("Sprint", "Автоматический спринт", ModuleCategory::Movement, 0, false) {
        mNames = {
            {Lowercase, "sprint"},
            {LowercaseSpaced, "sprint"},
            {Normal, "Sprint"},
            {NormalSpaced, "Sprint"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
};