#pragma once




#include <Features/Modules/Module.hpp>

class InventoryMove : public ModuleBase<InventoryMove> {
public:
    BoolSetting mDisallowShift = BoolSetting("Запретить шифт", "Запретить приседание в инвентаре.", false);

    InventoryMove() : ModuleBase("InventoryMove", "Позволяет двигаться с открытым инвентарем.", ModuleCategory::Movement, 0, false) {
        addSettings(&mDisallowShift);

        mNames = {
            {Lowercase, "inventorymove"},
            {LowercaseSpaced, "inventory move"},
            {Normal, "InventoryMove"},
            {NormalSpaced, "Inventory Move"}
        };
    }

    bool mHasOpenContainer = false;

    static void patchFunc1(bool);
    static void patchFunc2(bool);
    static void patchFunc(bool b)
    {
        patchFunc1(b);
        patchFunc2(b);
    }
    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onRenderEvent(class RenderEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
};