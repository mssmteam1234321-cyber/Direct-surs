#pragma once




#include <Features/Modules/Module.hpp>



class Phase : public ModuleBase<Phase> {
public:
    enum class Mode {
        Horizontal,
        Vertical,
        Clip
    };
    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим работы модуля", Mode::Horizontal, "Горизонтальный", "Вертикальный", "Клип");
    NumberSetting mSpeed = NumberSetting("Скорость", "Скорость вертикального фазирования", 1.f, 0.f, 10.f, 0.1f);
    BoolSetting mBlink = BoolSetting("Блинк", "Блинковать при фазировании", false);
    BoolSetting mTest = BoolSetting("Тест", "Тест", false);
    Phase() : ModuleBase("Phase", "Позволяет проходить сквозь стены", ModuleCategory::Movement, 0, false) {
        addSettings(&mMode, &mSpeed, &mBlink, &mTest);

        VISIBILITY_CONDITION(mSpeed, mMode.mValue == Mode::Vertical);
        VISIBILITY_CONDITION(mBlink, mMode.mValue == Mode::Horizontal);
        VISIBILITY_CONDITION(mTest, mMode.mValue == Mode::Clip);

        mNames = {
            {Lowercase, "phase"},
            {LowercaseSpaced, "phase"},
            {Normal, "Phase"},
            {NormalSpaced, "Phase"}
        };
    }

    bool mMoving = false;
    bool mClip = false;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
    void onRunUpdateCycleEvent(class RunUpdateCycleEvent& event);

    std::string getSettingDisplay() override {
        return mMode.mValues[mMode.as<int>()];
    }
};