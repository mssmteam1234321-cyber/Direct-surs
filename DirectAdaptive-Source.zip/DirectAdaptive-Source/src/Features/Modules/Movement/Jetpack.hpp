#pragma once





class Jetpack : public ModuleBase<Jetpack>
{
public:

    NumberSetting mVerticalSpeed = NumberSetting("Вертикальная скор.", "Вертикальная скорость полета", 1.0f, 0.5f, 10.0f, 0.01f);
    NumberSetting mHorizontalSpeed = NumberSetting("Горизонтальная скор.", "Горизонтальная скорость полета", 1.0f, 0.5f, 10.0f, 0.01f);
    BoolSetting mReset = BoolSetting("Сброс при выкл", "Сброс движения при выключении", false);

    Jetpack() : ModuleBase<Jetpack>("Jetpack", "Позволяет летать", ModuleCategory::Movement, 0, false) {

        addSettings(&mVerticalSpeed, &mHorizontalSpeed);
        addSetting(&mReset);

        mNames = {
            {Lowercase, "jetpack"},
            {LowercaseSpaced, "jetpack"},
            {Normal, "Jetpack"},
            {NormalSpaced, "Jetpack"}
        };

        mEnableWhileHeld = true;
    }

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
};
