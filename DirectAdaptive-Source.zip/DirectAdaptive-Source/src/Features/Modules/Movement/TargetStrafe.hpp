#pragma once




#include <Features/Modules/Module.hpp>
#include <Features/Modules/Setting.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>

class TargetStrafe : public ModuleBase<TargetStrafe> {
public:
    NumberSetting mDistance = NumberSetting("Дистанция", "Дистанция до цели", 3.f, 0.5f, 5.f, 0.1f);
    NumberSetting mMinDistance = NumberSetting("Мин. дистанция", "Минимальная дистанция до цели", 3.f, 0.5f, 5.f, 0.1f);
    BoolSetting mWallCheck = BoolSetting("Проверка стен", "Менять направление при столкновении со стеной", false);
    BoolSetting mJumpOnly = BoolSetting("Только в прыжке", "Стрейфить только в прыжке", false);
    BoolSetting mSpeedOnly = BoolSetting("Только со скоростью", "Стрейфить только с включенным Speed", false);
    BoolSetting mAlwaysSprint = BoolSetting("Спринт", "Всегда спринтиться", false);
    BoolSetting mRenderCircle = BoolSetting("Рендер круга", "Рисовать круг вокруг цели", false);

    TargetStrafe() : ModuleBase("TargetStrafe", "Автоматически крутится вокруг цели", ModuleCategory::Movement, 0, false) {
        addSettings(
            &mDistance,
            &mMinDistance,
            &mWallCheck,
            &mJumpOnly,
            &mSpeedOnly,
            &mAlwaysSprint
            
        );

        mNames = {
            {Lowercase, "targetstrafe"},
            {LowercaseSpaced, "target strafe"},
            {Normal, "TargetStrafe"},
            {NormalSpaced, "Target Strafe"}
        };
    }

    bool mShouldStrafe = false;
    Actor* mCurrentTarget = nullptr;
    bool mWasStrafing = false;

    bool mForward = false;
    bool mBackward = false;
    bool mMoveRight = true;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onRenderEvent(class RenderEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
    void handleKeyInput(bool pressingW, bool pressingA, bool pressingS, bool pressingD);
};