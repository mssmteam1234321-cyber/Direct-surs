#pragma once
#include <Features/Modules/Module.hpp>





class NoSlowDown : public ModuleBase<NoSlowDown> {
public:
    NoSlowDown() : ModuleBase("NoSlowdown", "Предотвращает замедление при ходьбе через паутину, использовании предметов и т.д.", ModuleCategory::Movement, 0, false) {
        mNames = {
            {Lowercase, "noslowdown"},
            {LowercaseSpaced, "no slowdown"},
            {Normal, "NoSlowDown"},
            {NormalSpaced, "No Slowdown"}
        };
    }

    static void patchSlowdown(bool patch);
    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onItemSlowdownEvent(class ItemSlowdownEvent& event);
};