#pragma once




#include <Features/Modules/Setting.hpp>

class Fly : public ModuleBase<Fly> {
public:
    enum class Mode {
        Motion,
        Elytra,
        Pregame,
        Jump,
    };

    EnumSettingT<Mode> mMode = EnumSettingT("Режим", "Режим полета", Mode::Motion,  "Движение", "Элитры", "Прегейм", "Прыжок");
    BoolSetting mApplyGlideFlags = BoolSetting("Флаги парения", "Применять флаги элитры (парение)", true); 
    NumberSetting mSpeed = NumberSetting("Скорость", "Скорость полета", 5.6f, 0.f, 20.f, 0.1f);

    
    BoolSetting mSpeedFriction = BoolSetting("Трение скорости", "Применять трение к скорости", true);
    NumberSetting mFriction = NumberSetting("Трение", "Сила трения", 0.975f, 0.f, 1.f, 0.01f);
    NumberSetting mHeightLoss = NumberSetting("Потеря высоты", "Потеря высоты за прыжок", 0.5f, 0.f, 2.f, 0.01f);
    NumberSetting mJumpDelay = NumberSetting("Задержка прыжка", "Задержка перед прыжком (сек)", 0.2f, 0.f, 1.f, 0.01f);
    BoolSetting mDamageOnly = BoolSetting("Только от урона", "Летать только при получении урона", false);
    NumberSetting mFlyTime = NumberSetting("Время полета", "Время полета после урона", 1.f, 0.f, 10.f, 0.01f);
    BoolSetting mResetOnGround = BoolSetting("Сброс на земле", "Сбрасывать высоту прыжка на земле", true);
    BoolSetting mResetOnDisable = BoolSetting("Сброс при выкл", "Сбрасывать скорость при выключении", true);
    BoolSetting mDebug = BoolSetting("Отладка", "Показывать сообщения отладки", false);

    
    BoolSetting mTimerBoost = BoolSetting("Ускорение таймера", "Ускорять таймер", false);
    NumberSetting mTimerBoostValue = NumberSetting("Скорость таймера", "Значение ускорения таймера", 1.f, 0.01f, 60.f, 0.01f);

    Fly() : ModuleBase("Fly", "Позволяет вам летать", ModuleCategory::Movement, 0, false) {
        addSettings(
            &mMode,
            &mApplyGlideFlags,
            &mSpeed,
            
            &mSpeedFriction,
            &mFriction,
            &mHeightLoss,
            &mJumpDelay,
            &mDamageOnly,
            &mFlyTime,
            &mResetOnGround,
            &mResetOnDisable,
            &mDebug,

            &mTimerBoost,
            &mTimerBoostValue
        );
        VISIBILITY_CONDITION(mApplyGlideFlags, mMode.mValue == Mode::Motion);
        VISIBILITY_CONDITION(mSpeed, mMode.mValue == Mode::Motion || mMode.mValue == Mode::Jump || mMode.mValue == Mode::Elytra);

        VISIBILITY_CONDITION(mHeightLoss, mMode.mValue == Mode::Jump);
        VISIBILITY_CONDITION(mJumpDelay, mMode.mValue == Mode::Jump);
        VISIBILITY_CONDITION(mSpeedFriction, mMode.mValue == Mode::Jump);
        VISIBILITY_CONDITION(mFriction, mMode.mValue == Mode::Jump && mSpeedFriction.mValue);
        VISIBILITY_CONDITION(mDamageOnly, mMode.mValue == Mode::Jump);
        VISIBILITY_CONDITION(mFlyTime, mMode.mValue == Mode::Jump && mDamageOnly.mValue);

        VISIBILITY_CONDITION(mDebug, mMode.mValue == Mode::Jump);
        VISIBILITY_CONDITION(mResetOnGround, mMode.mValue == Mode::Jump);
        VISIBILITY_CONDITION(mResetOnDisable, mMode.mValue == Mode::Jump);

        VISIBILITY_CONDITION(mTimerBoostValue, mTimerBoost.mValue);


        mNames = {
            {Lowercase, "fly"},
            {LowercaseSpaced, "fly"},
            {Normal, "Fly"},
            {NormalSpaced, "Fly"}
        };

        gFeatureManager->mDispatcher->listen<PacketInEvent, &Fly::onPacketInEvent>(this);

    }

    float mCurrentY = 0.f;
    uint64_t mLastJump = 0;
    float mCurrentFriction = 1.f;
    uint64_t mLastDamage = 0;


    void onEnable() override;
    void onDisable() override;
    void displayDebug(const std::string& message) const;
    void onBaseTickEvent(class BaseTickEvent& event);
    bool tickJump(Actor* player);
    void jump();
    void onPacketOutEvent(class PacketOutEvent& event) const;
    void onPacketInEvent(class PacketInEvent& event);

    std::string getSettingDisplay() override
    {
        return mMode.mValues[mMode.as<int>()];
    }
};