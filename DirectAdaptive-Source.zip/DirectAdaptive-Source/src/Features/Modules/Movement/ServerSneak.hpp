#pragma once





class ServerSneak : public ModuleBase<ServerSneak>
{
public:
    BoolSetting mCancelActorData = BoolSetting("Отменять ActorData", "Отменять пакеты ActorData (предотвращает приседание на клиенте)", true);

    ServerSneak() : ModuleBase("ServerSneak", "Приседание на стороне сервера", ModuleCategory::Movement, 0, false)
    {
        addSettings(&mCancelActorData);

        mNames = {
            {Lowercase, "serversneak"},
            {LowercaseSpaced, "server sneak"},
            {Normal, "ServerSneak"},
            {NormalSpaced, "Server Sneak"}
        };
    }

    uint64_t mLastInteract = 0;

    void onEnable() override;
    void onDisable() override;
    void onPacketOutEvent(class PacketOutEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
};