



#pragma once
#include <Features/Modules/Module.hpp>
#include <Features/Modules/Setting.hpp>

class Spider : public ModuleBase<Spider> {
public:
    enum class Mode {
        Clip,
#ifdef __PRIVATE_BUILD__
        Flareon
#endif
    };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим карабканья", Mode::Clip, "Clip"
#ifdef __PRIVATE_BUILD__
    ,"Flareon");
#else
    );
#endif
    NumberSetting mSpeed = NumberSetting("Скорость", "Скорость карабканья", 2.50, 1, 5, 0.01);
    BoolSetting mOnGroundOnly = BoolSetting("Только на земле", "Использовать только если вы на земле", false);

    Spider() : ModuleBase("Spider", "Позволяет карабкаться по стенам", ModuleCategory::Movement, 0, false) {
        addSetting(&mMode);
        addSetting(&mSpeed);
        addSetting(&mOnGroundOnly);

        mNames = {
            {Lowercase, "spider"},
            {LowercaseSpaced, "spider"},
            {Normal, "Spider"},
            {NormalSpaced, "Spider"},
        };
    }

    float mPosY = 0.f;
    bool mWasCollided = false;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
};