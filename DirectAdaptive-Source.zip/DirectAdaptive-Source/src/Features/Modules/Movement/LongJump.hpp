#pragma once





class LongJump : public ModuleBase<LongJump> {
public:
    NumberSetting mSpeed = NumberSetting("Скорость", "Насколько быстро вы движетесь", 1, 0, 40, 0.01);
    NumberSetting mHeight = NumberSetting("Высота", "Как высоко вы прыгаете", 0.42, 0, 10, 0.01);
    BoolSetting mTimerBoost = BoolSetting("Таймер буст", "Ускоряет таймер при прыжке", false);
    NumberSetting mTimer = NumberSetting("Таймер", "Значение таймера при включении модуля", 28.30, 0.01, 60, 0.01);
    BoolSetting mApplyJumpFlags = BoolSetting("Флаги прыжка", "Применяет флаги прыжка к игроку", true);
    BoolSetting mDisableModules = BoolSetting("Откл. модули", "Отключает другие модули с той же кнопкой", false);

    LongJump() : ModuleBase("LongJump", "Позволяет прыгать на большие расстояния", ModuleCategory::Movement, 0, false) {
        addSettings(
            &mSpeed,
            &mHeight,
            &mTimerBoost,
            &mTimer,
            &mApplyJumpFlags,
            &mDisableModules
        );

        VISIBILITY_CONDITION(mTimer, mTimerBoost.mValue);

        mNames = {
            {Lowercase, "longjump"},
            {LowercaseSpaced, "long jump"},
            {Normal, "LongJump"},
            {NormalSpaced, "Long Jump"}
        };
    }

    bool mHasJumped = false;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
};