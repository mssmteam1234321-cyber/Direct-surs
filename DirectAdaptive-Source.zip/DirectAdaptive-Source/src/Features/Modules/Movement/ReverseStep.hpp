#pragma once




#include <Features/Modules/Module.hpp>

class ReverseStep : public ModuleBase<ReverseStep>
{
public:
    enum class Mode {
        Motion
    };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Стиль падения", Mode::Motion, "Motion");
    NumberSetting mMaxFallDistance = NumberSetting("Макс. дистанция", "Максимальная дистанция падения (чтобы не упасть в бездну)", 20, 0, 30, 1);
    BoolSetting mDontUseIfSpeed = BoolSetting("Не юзать со Speed", "Не использовать, если включен Speed", true);
    BoolSetting mDontUseIfLongJump = BoolSetting("Не юзать с LongJump", "Не использовать, если включен LongJump", true);
    BoolSetting mVoidCheck = BoolSetting("Проверка бездны", "Не использовать, если падаете в бездну", true);

    ReverseStep() : ModuleBase<ReverseStep>("ReverseStep", "Автоматически спускает вас вниз по блокам", ModuleCategory::Movement, 0, false) {
        addSetting(&mMode);
        addSetting(&mMaxFallDistance);
        addSetting(&mDontUseIfSpeed);
        addSetting(&mDontUseIfLongJump);
        addSetting(&mVoidCheck);

        mNames = {
                {Lowercase, "reversestep"},
                {LowercaseSpaced, "reverse step"},
                {Normal, "ReverseStep"},
                {NormalSpaced, "Reverse Step"}
        };
    }

    bool mJumped = false;

    bool canFallDown();
    bool isVoid();

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
};