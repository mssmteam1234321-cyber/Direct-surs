#pragma once




#include <Features/Modules/Module.hpp>

class DamageBoost : public ModuleBase<DamageBoost> {
public:
    NumberSetting mSpeed = NumberSetting("Скорость", "Ускорение после получения урона", 8.f, 1.f, 20.0f, 0.01f);
    BoolSetting mOnGroundCheck = BoolSetting("Проверка земли", "Разная скорость на земле и в воздухе", false);
    NumberSetting mGroundSpeed = NumberSetting("Скорость на земле", "Скорость на земле", 7.f, 1.f, 20.0f, 0.01f);
    NumberSetting mOffGroundSpeed = NumberSetting("Скорость в воздухе", "Скорость в воздухе", 10.f, 1.f, 20.0f, 0.01f);

    DamageBoost() : ModuleBase("DamageBoost", "Ускоряет при получении урона", ModuleCategory::Movement, 0, false) {
        addSettings(&mSpeed, &mOnGroundCheck, &mGroundSpeed, &mOffGroundSpeed);
        VISIBILITY_CONDITION(mGroundSpeed, mOnGroundCheck.mValue);
        VISIBILITY_CONDITION(mOffGroundSpeed, mOnGroundCheck.mValue);

        mNames = {
            {Lowercase, "damageboost"},
            {LowercaseSpaced, "damage boost"},
            {Normal, "DamageBoost"},
            {NormalSpaced, "Damage Boost"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onPacketInEvent(class PacketInEvent& event);
};