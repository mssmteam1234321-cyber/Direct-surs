


#pragma once
#include <Features/Modules/Module.hpp>



class HiveFly : public ModuleBase<HiveFly> {
public:

    NumberSetting mSpeed = NumberSetting("Скорость", "Скорость полета", 60, 0, 100, 1);
    NumberSetting mTimer = NumberSetting("Таймер", "Таймер, устанавливаемый при включении", 3, 0, 40, 1);

    HiveFly() : ModuleBase("HiveFly", "Полет для Hive", ModuleCategory::Movement, 0, false) {

        addSettings(&mSpeed, &mTimer);

        mNames = {
                {Lowercase, "hivefly"},
                {LowercaseSpaced, "hive fly"},
                {Normal, "HiveFly"},
                {NormalSpaced, "Hive Fly"}
        };
    }

    bool mCanFly;
    int mVeloTick;
    int mTicksToStay;
    bool mShouldStay;

    void Reset();
    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
};