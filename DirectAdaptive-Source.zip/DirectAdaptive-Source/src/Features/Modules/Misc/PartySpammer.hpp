#pragma once





class PartySpammer : public ModuleBase<PartySpammer> {
public:
    enum class Mode {
        Form,
        Command
    };
    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим спамера пати", Mode::Form, "Form"
#ifdef __PRIVATE_BUILD__
        , "Command"
#endif
    );
    BoolSetting mActive = BoolSetting("Активен", "Активен ли спамер пати", false);
    NumberSetting mDelay = NumberSetting("Задержка", "Задержка в мс между приглашениями", 1000, 0, 10000, 100);
    BoolSetting mHideInviteMessage = BoolSetting("Скрыть сообщение", "Не показывать сообщение приглашения в чате", false);

    PartySpammer() : ModuleBase("PartySpammer", "Спамит приглашениями в пати", ModuleCategory::Misc, 0, false) {
        addSetting(&mMode);
        addSetting(&mActive);
        addSetting(&mDelay);
#ifdef __PRIVATE_BUILD__
        addSetting(&mHideInviteMessage);
#endif

        VISIBILITY_CONDITION(mActive, mMode.mValue == Mode::Form);
        VISIBILITY_CONDITION(mDelay, mMode.mValue == Mode::Form);
        VISIBILITY_CONDITION(mHideInviteMessage, mMode.mValue == Mode::Command);

        mNames = {
            {Lowercase, "partyspammer"},
            {LowercaseSpaced, "party spammer"},
            {Normal, "PartySpammer"},
            {NormalSpaced, "Party Spammer"}
        };
    }

    std::string mPlayerToSpam = "Sinister4458";
    std::vector<int> mOpenFormIds;
    std::map<int, std::string> mFormJsons;
    std::map<int, std::string> mFormTitles;
    bool mSentInvite = false;
    bool mInteractable = false;
    uint64_t mLastInteract = 0;
    uint64_t mLastCommandRequestPacketSent = 0;
    bool mInvited = false;

    void onEnable() override;
    void onDisable() override;
    void submitForm(int buttonId, int formId);
    void submitBoolForm(bool buttonId, int formId);
    void closeForm(int formId);
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
};