



#include "VoiceChat.hpp"
#include <winrt/Windows.Networking.Sockets.h>
#include <winrt/Windows.Storage.Streams.h>
#include <winrt/Windows.Foundation.h>
#include <spdlog/spdlog.h>
#include <thread>

using namespace winrt;
using namespace Windows::Networking;
using namespace Windows::Networking::Sockets;
using namespace Windows::Storage::Streams;
using namespace Windows::Foundation;

class VoiceClient {
public:
    VoiceClient(const std::string& serverIP, int serverPort)
        : serverIP(serverIP), serverPort(serverPort) {
        winrt::init_apartment();  
    }

    void connectToServer() {
        try {
            
            socket.ConnectAsync(HostName(winrt::to_hstring(serverIP)), L"1845").get();
            spdlog::info("Successfully connected to the server!");

            
            writer = DataWriter(socket.OutputStream());
        } catch (hresult_error const& ex) {
            spdlog::error("Failed to connect to server: {}", winrt::to_string(ex.message()));
        }
    }

    IAsyncAction sendAudioDataAsync(const std::vector<BYTE>& audioBuffer) {
        try {
            
            writer.WriteBytes(array_view<const BYTE>(audioBuffer));
            co_await writer.StoreAsync(); 
        } catch (hresult_error const& ex) {
            spdlog::error("Failed to send audio data: {}", winrt::to_string(ex.message()));
        }
    }

    void closeConnection() {
        writer.Close(); 
        socket.Close(); 
    }

    std::string serverIP;
    int serverPort;
    StreamSocket socket;
    DataWriter writer{ nullptr };
};


void VoiceChat::onEnable()
{

}

void VoiceChat::onDisable()
{

}

std::unique_ptr<VoiceClient> client = nullptr;


void VoiceChat::onInit()
{
    /*
    client = std::make_unique<VoiceClient>("127.0.0.1", 1845);

    
    std::thread([&]() {
        client->connectToServer();  
        
        std::this_thread::sleep_for(std::chrono::seconds(1));


        
        AudioUtils::recordVoiceClip([&](const std::vector<BYTE>& audioBuffer) {
            client->sendAudioDataAsync(audioBuffer).get(); 
        });
    }).detach();  
    */
}
