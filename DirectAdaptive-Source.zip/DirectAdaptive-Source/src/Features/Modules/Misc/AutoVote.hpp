#pragma once




class AutoVote : public ModuleBase<AutoVote> {
public:
    BoolSetting mPrioritizeVoting = BoolSetting("Приоритет голосования", "Приоритет карт из списка autoVoteTemplate, иначе голосовать случайно.", false);

    AutoVote() : ModuleBase("AutoVote", "Автоматически голосует за карты на Hive", ModuleCategory::Misc, 0, false) {
        addSetting(&mPrioritizeVoting);

        mNames = {
            {Lowercase, "autovote"},
            {LowercaseSpaced, "auto vote"},
            {Normal, "AutoVote"},
            {NormalSpaced, "Auto Vote"}
        };
    }

    MessageTemplate mAutoVoteTemplate = MessageTemplate("autoVoteTemplate", "Pillars\nIvory\nBaroque\n");

    unsigned int mLastFormId = 0;
    bool mHasFormOpen = false;
    bool mVotedThisDimension = false;
    bool mInteractedThisDimension = false;
    std::string mJson;

    void submitForm(int buttonId);
    void closeForm();
    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
};