#pragma once
#include <Features/Events/BaseTickEvent.hpp>





class IRC : public ModuleBase<IRC> {
public:
    BoolSetting mShowNamesInChat = BoolSetting("Имена в чате", "Показывать имена пользователей IRC в чате Minecraft", true);
    BoolSetting mAlwaysSendToIrc = BoolSetting("Всегда отправлять в IRC", "Отправлять все сообщения в IRC без префикса #", false);
    IRC() : ModuleBase("IRC", "Общайтесь с другими игроками через IRC", ModuleCategory::Misc, 0, false) {
        addSetting(&mShowNamesInChat);
        addSetting(&mAlwaysSendToIrc);

        mNames = {
            {Lowercase, "irc"},
            {LowercaseSpaced, "irc"},
            {Normal, "IRC"},
            {NormalSpaced, "IRC"}
        };

        gFeatureManager->mDispatcher->listen<BaseTickEvent, &IRC::onBaseTickEvent>(this);
        gFeatureManager->mDispatcher->listen<ModuleStateChangeEvent, &IRC::onModuleStateChangeEvent, nes::event_priority::FIRST>(this);
    }

    void onEnable() override;
    void onDisable() override;
    void onModuleStateChangeEvent(ModuleStateChangeEvent& event);
    void onBaseTickEvent(BaseTickEvent& event);
};