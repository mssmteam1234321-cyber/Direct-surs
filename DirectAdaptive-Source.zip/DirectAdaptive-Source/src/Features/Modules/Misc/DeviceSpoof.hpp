#pragma once





class DeviceSpoof : public ModuleBase<DeviceSpoof>
{
public:
    DeviceSpoof() : ModuleBase("DeviceSpoof", "Спуфит все ваши идентификаторы", ModuleCategory::Misc, 0, false)
    {
        mNames = {
            {Lowercase, "devicespoof"},
            {LowercaseSpaced, "device spoof"},
            {Normal, "DeviceSpoof"},
            {NormalSpaced, "Device Spoof"}
        };
    }

    static inline unsigned char originalData[7];
    static inline unsigned char patch[] = {0x48, 0xBA, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0 };
    static inline void* patchPtr = nullptr;
    static inline bool HasGeneratedValues = false;
    static inline std::string CustomDeviceId;
    static inline std::string CustomSelfSignedId;
    static inline std::string CustomDeviceModel;
    static inline std::string CustomSkinId;
    static inline std::string CustomClientRandomId;

    static void loadSpooferConfig();
    static void saveSpooferConfig();
    static void generateRandomValues();

    void inject();
    void eject();
    void spoofMboard();

    void onInit() override;
    void onEnable() override;
    void onDisable() override;
    void onConnectionRequestEvent(class ConnectionRequestEvent& event);
};
