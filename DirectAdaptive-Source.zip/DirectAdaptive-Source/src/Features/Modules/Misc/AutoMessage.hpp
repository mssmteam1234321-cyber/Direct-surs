#pragma once




#include <Features/Modules/Module.hpp>

class AutoMessage : public ModuleBase<AutoMessage> {
public:
    BoolSetting mOnVote = BoolSetting("При голосовании", "Отправлять сообщение при голосовании за карту", false);
    BoolSetting mOnDimensionChange = BoolSetting("При смене измерения", "Отправлять сообщение при смене измерения", false);

    AutoMessage() : ModuleBase("AutoMessage", "Автоматически отправляет сообщение в чат в зависимости от триггеров", ModuleCategory::Misc, 0, false)
    {
        addSettings(&mOnVote, &mOnDimensionChange);

        mNames = {
            {Lowercase, "automessage"},
            {LowercaseSpaced, "auto message"},
            {Normal, "AutoMessage"},
            {NormalSpaced, "Auto Message"}
        };
    }

    std::map<int64_t, std::string> mQueuedMessages;
    MessageTemplate mVoteMessageTemplate = MessageTemplate("voteMessageTemplate", "Yo @here! Vote for !mapName!!!", std::make_pair("!mapName!", "Имя карты, за которую вы проголосовали"));
    MessageTemplate mDimensionChangeMessageTemplate = MessageTemplate("dimensionChangeMessageTemplate", "hey!! #LAWL #GG #XD");

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
};