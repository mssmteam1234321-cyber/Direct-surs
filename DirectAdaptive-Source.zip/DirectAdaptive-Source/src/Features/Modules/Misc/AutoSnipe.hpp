


#include <Features/Modules/Module.hpp>
#pragma once

class AutoSnipe : public ModuleBase<AutoSnipe> {
public:

    BoolSetting mQueueWhenTargetsLost = BoolSetting("Поиск при потере целей", "Искать игру, когда все цели потеряны", true);
    BoolSetting mQueueWhenNoTargetsFound = BoolSetting("Поиск без целей", "Искать игру, если цели не найдены и голосование завершено", true);
    BoolSetting mQueueWhenFull = BoolSetting("Поиск при полной игре", "Искать игру, если игра полна и цели не найдены", true);
    BoolSetting mRetryQueue = BoolSetting("Повтор очереди", "Повторить попытку поиска игры при ошибке", true);

    AutoSnipe() : ModuleBase("AutoSnipe", "Снайпит добавленные цели", ModuleCategory::Misc, 0, false){
        addSettings( &mQueueWhenTargetsLost, &mQueueWhenNoTargetsFound, &mQueueWhenFull, &mRetryQueue);

        mNames = {
                {NamingStyle::Lowercase, "autosnipe"},
                {NamingStyle::LowercaseSpaced, "auto snipe"},
                {NamingStyle::Normal, "AutoSnipe"},
                {NamingStyle::NormalSpaced, "Auto Snipe"}
        };
    }

    static std::vector<std::string> Targets;

    void onEnable() override;
    void onDisable() override;
    bool AnyTargetsFound();
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);

};
