#pragma once





class NetSkip : public ModuleBase<NetSkip>
{
public:
    enum class Mode {
        Ticks,
        Milliseconds
    };
    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим задержки", Mode::Ticks, "Тики", "Миллисекунды");

    
    BoolSetting mRandomizeTicks = BoolSetting("Случайные тики", "Рандомизировать задержку", false);
    NumberSetting mTicks = NumberSetting("Тики", "Задержка в тиках для пропуска пакетов", 1, 0, 100, 1);
    NumberSetting mTicksMin = NumberSetting("Мин. тики", "Минимальная задержка", 0, 0, 100, 1);
    NumberSetting mTicksMax = NumberSetting("Макс. тики", "Максимальная задержка", 100, 0, 100, 1);


    
    BoolSetting mRandomizeDelayMs = BoolSetting("Случайная задержка", "Рандомизировать задержку", false);
    NumberSetting mDelayMs = NumberSetting("Задержка", "Задержка в мс для пропуска пакетов", 101, 0, 1000, 1);
    NumberSetting mRandomizeMinMs = NumberSetting("Мин. задержка", "Минимальная задержка", 0, 0, 1000, 1);
    NumberSetting mRandomizeMaxMs = NumberSetting("Макс. задержка", "Максимальная задержка", 100, 0, 1000, 1);

    BoolSetting mDamageOnly = BoolSetting("Только при уроне", "Пропускать только при получении урона", false);
    NumberSetting mDamageTime = NumberSetting("Время урона", "Время пропуска после получения урона (мс)", 0, 0, 10000, 1);

    NetSkip() : ModuleBase<NetSkip>("NetSkip", "Пропускает пакеты", ModuleCategory::Misc, 0, false) {
        addSettings(
            &mMode,

            &mRandomizeTicks,
            &mTicks,
            &mTicksMin,
            &mTicksMax,

            &mRandomizeDelayMs,
            &mDelayMs,
            &mRandomizeMinMs,
            &mRandomizeMaxMs,

            &mDamageOnly,
            &mDamageTime
        );

        VISIBILITY_CONDITION(mTicks, mMode.mValue == Mode::Ticks);
        VISIBILITY_CONDITION(mTicksMin, mMode.mValue == Mode::Ticks && mRandomizeTicks.mValue);
        VISIBILITY_CONDITION(mTicksMax, mMode.mValue == Mode::Ticks && mRandomizeTicks.mValue);
        VISIBILITY_CONDITION(mRandomizeTicks, mMode.mValue == Mode::Ticks);

        VISIBILITY_CONDITION(mDelayMs, mMode.mValue == Mode::Milliseconds);
        VISIBILITY_CONDITION(mRandomizeMinMs, mMode.mValue == Mode::Milliseconds && mRandomizeDelayMs.mValue);
        VISIBILITY_CONDITION(mRandomizeMaxMs, mMode.mValue == Mode::Milliseconds && mRandomizeDelayMs.mValue);
        VISIBILITY_CONDITION(mRandomizeDelayMs, mMode.mValue == Mode::Milliseconds);

        VISIBILITY_CONDITION(mDamageTime, mDamageOnly.mValue);

        mNames = {
            {Lowercase, "netskip"},
            {LowercaseSpaced, "net skip"},
            {Normal, "NetSkip"},
            {NormalSpaced, "Net Skip"}
        };
    }

    int mCurrentTick = 0;
    int mTickDelay = 0;
    int64_t mLastDamage = 0;

    void onEnable() override;
    void onDisable() override;
    void onRunUpdateCycleEvent(class RunUpdateCycleEvent& event);
    void onPacketInEvent(class PacketInEvent& event);

    std::string getSettingDisplay() override {
        return mMode.mValues[mMode.as<int>()];
    }
};