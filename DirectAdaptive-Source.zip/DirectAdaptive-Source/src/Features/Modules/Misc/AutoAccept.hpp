#pragma once





class AutoAccept : public ModuleBase<AutoAccept> {
public:
    BoolSetting mAcceptPartyInvites = BoolSetting("Принимать пати", "Автоматически принимает приглашения в пати", true);
    BoolSetting mAcceptFriendRequests = BoolSetting("Принимать друзей", "Автоматически принимает запросы в друзья", true);

    AutoAccept() : ModuleBase("AutoAccept", "Автоматически принимает приглашения в пати и друзья", ModuleCategory::Misc, 0, false)
    {
        addSettings(
            &mAcceptPartyInvites,
            &mAcceptFriendRequests
        );

        mNames = {
            {Lowercase, "autoaccept"},
            {LowercaseSpaced, "auto accept"},
            {Normal, "AutoAccept"},
            {NormalSpaced, "Auto Accept"}
        };
    }

    std::vector<std::pair<uintptr_t, std::string>> mQueuedCommands;
    uint64_t mLastCommandTime = 0;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
};