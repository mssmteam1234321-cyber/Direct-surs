#pragma once





class NoPacket : public ModuleBase<NoPacket> {
public:
    BoolSetting mMoveOnly = BoolSetting("Только движение", "Отменять только пакеты движения", false);

    NoPacket() : ModuleBase("NoPacket", "Предотвращает отправку пакетов на сервер", ModuleCategory::Misc, 0, false)
    {
        addSetting(&mMoveOnly);

        mNames = {
            {Lowercase, "nopacket"},
            {LowercaseSpaced, "no packet"},
            {Normal, "NoPacket"},
            {NormalSpaced, "No Packet"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onPacketOutEvent(class PacketOutEvent& event) const;

};