#pragma once




#include <Features/Modules/Module.hpp>


class AutoQueue : public ModuleBase<AutoQueue> {
public:
    enum class Mode {
        Auto,
        Random
    };
    EnumSettingT<Mode> mMode = EnumSettingT("Режим", "Режим работы модуля", Mode::Auto, "Авто", "Рандом");
    NumberSetting mQueueDelay = NumberSetting("Задержка очереди", "Задержка между поиском игры (в секундах)", 1.f, 0.f, 5.f, 0.01f);
    BoolSetting mShowInChat = BoolSetting("Показывать в чате", "Показывать текущую игру в чате", true);
    BoolSetting mQueueOnDeath = BoolSetting("Поиск при смерти", "Искать игру после смерти", true);
    BoolSetting mQueueOnGameEnd = BoolSetting("Поиск при конце игры", "Искать игру после окончания матча", true);

    AutoQueue() : ModuleBase("AutoQueue", "Автоматически ищет игры", ModuleCategory::Misc, 0, false){
        addSettings(&mMode, &mQueueDelay, &mShowInChat, &mQueueOnDeath, &mQueueOnGameEnd);

        mNames = {
            {NamingStyle::Lowercase, "autoqueue"},
            {NamingStyle::LowercaseSpaced, "auto queue"},
            {NamingStyle::Normal, "AutoQueue"},
            {NamingStyle::NormalSpaced, "Auto Queue"}
        };
    }

    bool mQueueForGame = false;
    std::string mLastGame = "sky";
    uint64_t mLastQueueTime = 0;
    uint64_t mLastCommandExecuted = 0;
    std::map<uint64_t, std::string> mQueuedCommands = {};
    std::vector<std::string> mGamemodes = { "sky", "sky-duos", "sky-squads", "sky-mega", "ctf", "bed", "bed-duos", "bed-squads", "sg", "sg-duos" };

    void onEnable() override;
    void onDisable() override;
    void queueForGame();
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);

    std::string getSettingDisplay() override {
        return mMode.mValues[mMode.as<int>()];
    }
};
