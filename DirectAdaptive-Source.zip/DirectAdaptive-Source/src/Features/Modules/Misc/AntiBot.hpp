#pragma once



#include <Features/Modules/Module.hpp>

class AntiBot : public ModuleBase<AntiBot>
{
public:
    enum class Mode {
        Simple,
        Custom
    };

    enum class EntitylistMode {
        EnttView,
        RuntimeActorList
    };

    enum class ArmorMode
    {
        Full,
        OneElement
    };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим работы AntiBot.", Mode::Simple, "Простой", "Кастомный");
    EnumSettingT<EntitylistMode> mEntitylistMode = EnumSettingT<EntitylistMode>("Режим списка существ", "Режим списка существ.\nEntt View: Используйте, если сущности не отображаются\nRuntime Actor List: Используйте при проблемах со стабильностью", EntitylistMode::RuntimeActorList, "Entt View", "Уровень");
    BoolSetting mHitboxCheck = BoolSetting("Проверка хитбокса", "Проверять ли хитбокс сущности.", true);
    BoolSetting mPlayerCheck = BoolSetting("Проверка игрока", "Проверять ли, является ли сущность игроком.", true);
    BoolSetting mInvisibleCheck = BoolSetting("Проверка невидимости", "Проверять ли, является ли сущность невидимой.", true);
    BoolSetting mNameCheck = BoolSetting("Проверка имени", "Проверять ли имя сущности (больше одной строки).", true);
    BoolSetting mPlayerListCheck = BoolSetting("Проверка Tab-листа", "Проверять ли наличие игрока в табе.", true);
    BoolSetting mHasArmorCheck = BoolSetting("Проверка брони", "Проверять ли наличие брони у сущности", false);
    EnumSettingT<ArmorMode> mArmorMode = EnumSettingT<ArmorMode>("Режим брони", "Способ проверки брони.", ArmorMode::Full, "Полная", "Один элемент");

    AntiBot() : ModuleBase("AntiBot", "Фильтрует ботов из списка сущностей", ModuleCategory::Misc, 0, true) {
        addSettings(&mMode, &mEntitylistMode, &mHitboxCheck, &mPlayerCheck, &mInvisibleCheck, &mNameCheck, &mPlayerListCheck, &mHasArmorCheck, &mArmorMode);

        VISIBILITY_CONDITION(mHitboxCheck, mMode.mValue == Mode::Custom);
        VISIBILITY_CONDITION(mPlayerCheck, mMode.mValue == Mode::Custom);
        VISIBILITY_CONDITION(mInvisibleCheck, mMode.mValue == Mode::Custom);
        VISIBILITY_CONDITION(mNameCheck, mMode.mValue == Mode::Custom);
        VISIBILITY_CONDITION(mPlayerListCheck, mMode.mValue == Mode::Custom);
        VISIBILITY_CONDITION(mHasArmorCheck, mMode.mValue == Mode::Custom);
        VISIBILITY_CONDITION(mArmorMode, mMode.mValue == Mode::Custom && mHasArmorCheck.mValue);

        mNames = {
            {Lowercase, "antibot"},
            {LowercaseSpaced, "anti bot"},
            {Normal, "AntiBot"},
            {NormalSpaced, "Anti Bot"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    static std::vector<std::string> getPlayerNames();
    bool isBot(Actor* actor);
    bool hasArmor(Actor* actor);

    std::string getSettingDisplay() override {
        return mMode.mValues[mMode.as<int>()];
    }
};