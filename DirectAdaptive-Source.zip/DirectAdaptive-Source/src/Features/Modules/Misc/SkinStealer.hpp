#pragma once





class SkinStealer : public ModuleBase<SkinStealer> {
public:
    BoolSetting mApplySkin = BoolSetting("Применить скин", "Автоматически применять украденный скин", false);

    SkinStealer() : ModuleBase("SkinStealer", "Крадет скины у других игроков", ModuleCategory::Misc, 0, false) {
#ifdef __PRIVATE_BUILD__
        addSettings(&mApplySkin);
#endif

        mNames = {
            {Lowercase, "skinstealer"},
            {LowercaseSpaced, "skin stealer"},
            {Normal, "SkinStealer"},
            {NormalSpaced, "Skin Stealer"},
        };
    }

    static std::vector<uint8_t> convToPng(const std::vector<uint8_t>& data, int width, int height);

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void saveSkin(class Actor* skin);
    void applySkin(Actor* actor, const std::vector<uint8_t>& skinData, const std::vector<uint8_t>& capeData, int capeWidth, int capeHeight, const std::string& resourcePatch);
};