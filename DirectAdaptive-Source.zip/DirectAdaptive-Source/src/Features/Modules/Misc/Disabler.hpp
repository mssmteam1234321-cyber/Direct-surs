#pragma once




class Disabler : public ModuleBase<Disabler> {
public:
    enum class Mode {
        Flareon,
        Sentinel,
        Lifeboat,
#ifdef __PRIVATE_BUILD__ 
        SentinelNew,
#endif
        Custom,
        BDSPrediction
    };
    enum class DisablerType {
        PingSpoof,
        PingHolder,
#ifdef __PRIVATE_BUILD__
        MoveFix,
        MoveFixV2
#endif
    };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим работы Disabler.", Mode::Flareon, "Flareon", "Sentinel", "Lifeboat",
#ifdef __PRIVATE_BUILD__
        "SentinelNew",
#endif
        "Custom", "BDS Prediction");
    EnumSettingT<DisablerType> mDisablerType = EnumSettingT<DisablerType>("Тип Disabler", "Тип Disabler для использования.", DisablerType::PingSpoof, "Спуф пинга", "Холдер пинга"
#ifdef __PRIVATE_BUILD__
        ,"Move Fix", "Move Fix V2"
#endif
        );
#ifdef __PRIVATE_BUILD__
    NumberSetting mQueuedPackets = NumberSetting("Пакеты в очереди", "Количество пакетов в очереди", 120, 0, 300, 1);
    BoolSetting mReverseQueue = BoolSetting("Обратная очередь", "Развернуть очередь", false);
    NumberSetting mDropChance = NumberSetting("Шанс сброса", "Шанс сбросить пакет", 0, 0, 100, 1);
#endif
    BoolSetting mRandomizeDelay = BoolSetting("Случайная задержка", "Рандомизировать задержку", true);
    NumberSetting mDelay = NumberSetting("Задержка", "Задержка для Disabler", 10000, 0, 100000, 1);
    NumberSetting mMinDelay = NumberSetting("Мин. задержка", "Минимальная задержка", 6000, 0, 100000, 1);
    NumberSetting mMaxDelay = NumberSetting("Макс. задержка", "Максимальная задержка", 10000, 0, 100000, 1);
    BoolSetting mInteract = BoolSetting("Взаимодействие", "Отправлять пакет взаимодействия перед атакой", false);
    BoolSetting mCancel = BoolSetting("Отмена", "Отменять пакет networkstacklatency", false);
    BoolSetting mGlide = BoolSetting("Скольжение", "Отправлять пакет начала скольжения", false);
    BoolSetting mOnGroundSpoof = BoolSetting("На земле", "Спуфить состояние на земле", false);
    BoolSetting mInputSpoof = BoolSetting("Ввод", "Спуфить режим ввода", false);
    BoolSetting mClickPosFix = BoolSetting("Испр. позиции клика", "Исправлять позицию клика", false);

    Disabler() : ModuleBase<Disabler>("Disabler", "Пытается отключить проверки античита", ModuleCategory::Misc, 0, false){
        addSetting(&mMode);
        addSetting(&mDisablerType);
#ifdef __DEBUG__
        addSetting(&mQueuedPackets);
        addSetting(&mReverseQueue);
        addSetting(&mDropChance);
#endif
        addSetting(&mRandomizeDelay);
        addSetting(&mDelay);
        addSetting(&mMinDelay);
        addSetting(&mMaxDelay);
        addSettings(&mInteract, &mCancel, &mGlide, &mOnGroundSpoof, &mInputSpoof, &mClickPosFix);

        VISIBILITY_CONDITION(mDisablerType, mMode.mValue == Mode::Flareon);
#ifdef __DEBUG__
        VISIBILITY_CONDITION(mQueuedPackets, mMode.mValue == Mode::SentinelNew);
        VISIBILITY_CONDITION(mReverseQueue, mMode.mValue == Mode::SentinelNew);
        VISIBILITY_CONDITION(mDropChance, mMode.mValue == Mode::SentinelNew);
#endif
        VISIBILITY_CONDITION(mRandomizeDelay, mMode.mValue == Mode::Flareon && mDisablerType.mValue == DisablerType::PingSpoof);

        VISIBILITY_CONDITION(mDelay, mMode.mValue == Mode::Flareon && mDisablerType.mValue == DisablerType::PingSpoof && !mRandomizeDelay.mValue);
        VISIBILITY_CONDITION(mMinDelay, mMode.mValue == Mode::Flareon && mDisablerType.mValue == DisablerType::PingSpoof && mRandomizeDelay.mValue);
        VISIBILITY_CONDITION(mMaxDelay, mMode.mValue == Mode::Flareon && mDisablerType.mValue == DisablerType::PingSpoof && mRandomizeDelay.mValue);

        VISIBILITY_CONDITION(mInteract, mMode.mValue == Mode::Custom);
        VISIBILITY_CONDITION(mCancel, mMode.mValue == Mode::Custom);
        VISIBILITY_CONDITION(mGlide, mMode.mValue == Mode::Custom);
        VISIBILITY_CONDITION(mOnGroundSpoof, mMode.mValue == Mode::Custom);
        VISIBILITY_CONDITION(mInputSpoof, mMode.mValue == Mode::Custom);
        VISIBILITY_CONDITION(mClickPosFix, mMode.mValue == Mode::Custom);

        mNames = {
            {Lowercase, "disabler"},
            {LowercaseSpaced, "disabler"},
            {Normal, "Disabler"},
            {NormalSpaced, "Disabler"}
        };
    }

    uint64_t mClientTicks = 0;
    bool mShouldUpdateClientTicks = false;
    glm::vec3 mLastPosition = { 0, 0, 0 };
    Actor* mFirstAttackedActor = nullptr;

    std::map<int64_t, uint64_t> mPacketQueue;
    void sortQueueByTime()
    {
        
        mPacketQueue = std::map<int64_t, uint64_t>(mPacketQueue.begin(), mPacketQueue.end());
    }

    void onEnable() override;
    void onDisable() override;
    void onPacketInEvent(class PacketInEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
    void onRunUpdateCycleEvent(class RunUpdateCycleEvent& event);
    int64_t getDelay() const;
    void onPingUpdateEvent(class PingUpdateEvent& event);
    void onSendImmediateEvent(class SendImmediateEvent& event);
};