#pragma once





class NoFilter : public ModuleBase<NoFilter> {
public:
    NoFilter() : ModuleBase("NoFilter", "Убирает фильтр чата.\nУчтите, что это НЕ обойдет серверный фильтр.", ModuleCategory::Misc, 0, true)
    {
        mNames = {
            {Lowercase, "nofilter"},
            {LowercaseSpaced, "no filter"},
            {Normal, "NoFilter"},
            {NormalSpaced, "No Filter"}
        };
    }

    void onEnable() override;
    void onDisable() override;
};