#pragma once




#include <Features/Modules/Module.hpp>

class  Killsults : public ModuleBase<Killsults> {
public:
    enum class Mode {
        None,
        Custom
    };

    enum class KillSound {
        None,
        PopDing,
        Cash
    };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим Killsults", Mode::None, "Нет", "Кастом");
    BoolSetting mAutoGG = BoolSetting("Авто GG", "Отправлять сообщение при убийстве", false);
    EnumSettingT<KillSound> mKillSound = EnumSettingT<KillSound>("Звук убийства", "Звук при убийстве", KillSound::None, "Нет", "Pop+Ding", "Звук монет");
    NumberSetting mSoundVolume = NumberSetting("Громкость звука", "Громкость звука убийства", 1.0f, 0.0f, 1.0f, 0.01f);
    BoolSetting mShowNotification = BoolSetting("Показывать уведомление", "Показывать уведомление при убийстве", true);

    Killsults() : ModuleBase("Killsults", "Автоматически отправляет сообщение в чат при убийстве.", ModuleCategory::Misc, 0, false    )
    {
        addSettings(&mMode, &mAutoGG, &mKillSound, &mSoundVolume, &mShowNotification);

        VISIBILITY_CONDITION(mSoundVolume, mKillSound.mValue != KillSound::None);

        mNames = {
            {Lowercase, "killsults"},
            {LowercaseSpaced, "killsults"},
            {Normal, "Killsults"},
            {NormalSpaced, "Killsults"}
        };
    }

    MessageTemplate mCustomKillsults = MessageTemplate("customKillsults", "Wow! I just killed !target! using my favorite client!",
        std::make_pair("!target!", "The player you killed"), std::make_pair("!localPlayer!", "Your username"), std::make_pair("!killCount!", "The number of kills you got this round (so far)"));
    MessageTemplate mAutoGGTemplate = MessageTemplate("autoGG", "GG. I got !killCount! kills this round.",
        std::make_pair("!killCount!", "The number of kills you got this round"), std::make_pair("!localPlayer!", "Your username"));

    std::map<int64_t, int64_t> mLastAttacked = {};
    std::map<int64_t, int64_t> mLastHurt = {};
    std::vector<std::string> mLastChatMessages = {};
    int mKillCount = 0;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);

    std::string getSettingDisplay() override
    {
        return mMode.mValues[mMode.as<int>()];
    }
};