


#pragma once
#include <Features/Modules/Module.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>

class AutoLootbox : public ModuleBase<AutoLootbox> {
public:

    NumberSetting mRange = NumberSetting("Дистанция", "Максимальная дистанция до лутбоксов", 5.f, 0.f, 10.f, 1.f);
    BoolSetting mRotate = BoolSetting("Поворот", "Включить поворот", true);

    AutoLootbox() : ModuleBase("AutoLootbox", "Автоматически ломает death treasures на Hive", ModuleCategory::Player, 0, false) {

        addSettings(&mRange);
        addSettings(&mRotate);

        mNames = {
                {Lowercase, "autolootbox"},
                {LowercaseSpaced, "auto lootbox"},
                {Normal, "AutoLootbox"},
                {NormalSpaced, "Auto Lootbox"},
        };
    }

    static AABB mTargetedAABB;
    static bool mRotating;
    static uint64_t lastHit;

    void onEnable() override;
    void onDisable() override;
    void RotateToTreasure(class Actor* actor);
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
};