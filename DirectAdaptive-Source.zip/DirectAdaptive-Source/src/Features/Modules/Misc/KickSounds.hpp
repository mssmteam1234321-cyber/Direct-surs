#pragma once




#include <Features/FeatureManager.hpp>


class KickSounds : public ModuleBase<KickSounds> {
public:
    enum Sound {
        Fard,
        Mario,
        Windows
    };

    EnumSettingT<Sound> mSound = EnumSettingT<Sound>("Звук", "Звук при получении DisconnectPacket (кик)", Sound::Fard, "Fard", "Марио", "Windows");
    NumberSetting mVolume = NumberSetting("Громкость", "Громкость звука", 1.f, 0.f, 1.f, 0.1f);

    KickSounds() : ModuleBase("KickSounds", "Проигрывает звук при получении DisconnectPacket", ModuleCategory::Misc, 0, false) {
        addSetting(&mSound);
        addSetting(&mVolume);

        mNames = {
            {Lowercase, "kicksounds"},
            {LowercaseSpaced, "kick sounds"},
            {Normal, "KickSounds"},
            {NormalSpaced, "Kick Sounds"}
        };
    }

    void onEnable() override;
    void onDisable() override;

    void onPacketInEvent(class PacketInEvent& event);

    std::string getSettingDisplay() override {
        return mSound.mValues[mSound.as<int>()];
    }

};