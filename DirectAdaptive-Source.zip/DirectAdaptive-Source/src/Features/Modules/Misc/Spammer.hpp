#pragma once




class Spammer : public ModuleBase<Spammer> {
public:
    enum class Mode {
        Custom
    };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим спамера", Mode::Custom, "Custom");
    NumberSetting mDelayMs = NumberSetting("Задержка", "Задержка сообщения в мс", 1000, 0, 5000, 50);
    BoolSetting mAvoidKicks = BoolSetting("Анти-кик", "Избегать кика за спам", false);
    NumberSetting mAddedDelay = NumberSetting("Доб. задержка", "Добавочная задержка в мс во избежание кика", 0, 0, 5000, 50);

    Spammer();

    MessageTemplate mSpammerMessageTemplate = MessageTemplate("spammerMessageTemplate", "Good game!", std::make_pair("!randMention!", "Randomly mention a player, excluding yourself"));
    uint64_t mLastMessageSent = 0;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
};