#pragma once



#include <Features/Modules/Module.hpp>


class AutoDodge : public ModuleBase<AutoDodge> {
public:

    BoolSetting mBalance = BoolSetting("Balance", "Ливать с карты Balance", false);
    BoolSetting mBaroque = BoolSetting("Baroque", "Ливать с карты Baroque", false);
    BoolSetting mEuropa = BoolSetting("Europa", "Ливать с карты Europa", false);
    BoolSetting mGrove = BoolSetting("Grove", "Ливать с карты Grove", false);
    BoolSetting mIvory = BoolSetting("Ivory", "Ливать с карты Ivory", false);
    BoolSetting mLush = BoolSetting("Lush", "Ливать с карты Lush", false);
    BoolSetting mMonastery = BoolSetting("Monastery", "Ливать с карты Monastery", false);
    BoolSetting mPillars = BoolSetting("Pillars", "Ливать с карты Pillars", false);
    BoolSetting mPineconePoint = BoolSetting("Pinecone Point", "Ливать с карты Pinecone Point", false);
    BoolSetting mTurmoil = BoolSetting("Turmoil", "Ливать с карты Turmoil", false);
    BoolSetting mVillage = BoolSetting("Village", "Ливать с карты Village", false);
    BoolSetting mVioletKeep = BoolSetting("VioletKeep", "Ливать с карты Violet Keep", false);
    BoolSetting mVolcano = BoolSetting("Volcano", "Ливать с карты Volcano", false);
    BoolSetting mWildWood = BoolSetting("WildWood", "Ливать с карты Wild Wood", false);
    BoolSetting mWoodpine = BoolSetting("Wood pine", "Ливать с карты Woodpine", false);

    AutoDodge() : ModuleBase("AutoDodge", "Автоматически ливает с выбранных карт на Hive", ModuleCategory::Misc, 0, false){
        addSettings(
                &mBalance,
                &mBaroque,
                &mEuropa,
                &mGrove,
                &mIvory,
                &mLush,
                &mMonastery,
                &mPillars,
                &mPineconePoint,
                &mTurmoil,
                &mVillage,
                &mVioletKeep,
                &mVolcano,
                &mWildWood,
                &mWoodpine
        );

        mNames = {
                {NamingStyle::Lowercase, "autododge"},
                {NamingStyle::LowercaseSpaced, "auto dodge"},
                {NamingStyle::Normal, "AutoDodge"},
                {NamingStyle::NormalSpaced, "Auto Dodge"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onPacketInEvent(class PacketInEvent& event);
};
