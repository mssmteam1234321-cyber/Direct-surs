#pragma once




#include <Features/Modules/Module.hpp>


class PacketLogger : public ModuleBase<PacketLogger>
{
public:
    BoolSetting mIncoming = BoolSetting("Входящие", "Логировать входящие пакеты", true);
    BoolSetting mOutgoing = BoolSetting("Исходящие", "Логировать исходящие пакеты", true);
    PacketLogger() : ModuleBase("PacketLogger", "Логирует пакеты", ModuleCategory::Misc, 0, false)
    {
        addSettings(&mIncoming, &mOutgoing);
        mNames = {
            {Lowercase, "packetlogger"},
            {LowercaseSpaced, "packet logger"},
            {Normal, "PacketLogger"},
            {NormalSpaced, "Packet Logger"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onPacketOutEvent(class PacketOutEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
};