#include "DeviceSpoof.hpp"
#include <Utils/FileUtils.hpp>
#include <Utils/StringUtils.hpp>
#include <nlohmann/json.hpp>
#include <Utils/Logger.hpp>
#include <fstream>
#include <random>
#include <spdlog/spdlog.h>

using json = nlohmann::json;

void DeviceSpoof::loadSpooferConfig() {
    std::string path = FileUtils::getRoamingStatePath() + "\\Direct\\spoofer.json";
    if (!FileUtils::fileExists(path)) {
        generateRandomValues();
        saveSpooferConfig();
        return;
    }

    try {
        std::ifstream file(path);
        json j;
        file >> j;

        if (j.contains("CustomDeviceId")) CustomDeviceId = j["CustomDeviceId"];
        if (j.contains("CustomSelfSignedId")) CustomSelfSignedId = j["CustomSelfSignedId"];
        if (j.contains("CustomDeviceModel")) CustomDeviceModel = j["CustomDeviceModel"];
        if (j.contains("CustomSkinId")) CustomSkinId = j["CustomSkinId"];
        if (j.contains("CustomClientRandomId")) CustomClientRandomId = j["CustomClientRandomId"];
        
        HasGeneratedValues = true;
    } catch (const std::exception& e) {
        spdlog::info("[{}] {}", "DeviceSpoof", "Failed to load spoofer config: " + std::string(e.what()));
    }
}

void DeviceSpoof::saveSpooferConfig() {
    std::string path = FileUtils::getRoamingStatePath() + "\\Direct\\spoofer.json";
    json j;
    j["CustomDeviceId"] = CustomDeviceId;
    j["CustomSelfSignedId"] = CustomSelfSignedId;
    j["CustomDeviceModel"] = CustomDeviceModel;
    j["CustomSkinId"] = CustomSkinId;
    j["CustomClientRandomId"] = CustomClientRandomId;

    try {
        std::ofstream file(path);
        file << j.dump(4);
    } catch (const std::exception& e) {
        spdlog::info("[{}] {}", "DeviceSpoof", "Failed to save spoofer config: " + std::string(e.what()));
    }
}

std::string randomString(size_t length) {
    auto randchar = []() -> char
    {
        const char charset[] =
        "0123456789"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz";
        const size_t max_index = (sizeof(charset) - 1);
        return charset[rand() % max_index];
    };
    std::string str(length, 0);
    std::generate_n(str.begin(), length, randchar);
    return str;
}

std::string randomUuid() {
    std::string res = randomString(8) + "-" + randomString(4) + "-" + randomString(4) + "-" + randomString(4) + "-" + randomString(12);
    return res;
}

void DeviceSpoof::generateRandomValues() {
    CustomDeviceId = randomUuid();
    CustomSelfSignedId = randomUuid();
    CustomDeviceModel = randomString(10); 
    CustomSkinId = randomUuid();
    CustomClientRandomId = std::to_string(rand()); 
    HasGeneratedValues = true;
}

void DeviceSpoof::inject() {
    
}

void DeviceSpoof::eject() {
    
}

void DeviceSpoof::spoofMboard() {
    
}

void DeviceSpoof::onInit() {
    loadSpooferConfig();
}

void DeviceSpoof::onEnable() {
    
}

void DeviceSpoof::onDisable() {
    
}

void DeviceSpoof::onConnectionRequestEvent(ConnectionRequestEvent& event) {
    
}