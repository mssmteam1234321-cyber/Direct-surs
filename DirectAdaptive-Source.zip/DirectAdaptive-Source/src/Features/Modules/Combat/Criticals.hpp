


#include <Features/Modules/Module.hpp>
#include <Features/Modules/Setting.hpp>
#pragma once

class Criticals : public ModuleBase<Criticals> {
public:

    enum class Mode {
        Sentinel,
    };

    enum class AnimationState {
        START,
        MID_AIR,
        MID_AIR2,
        LANDING,
        FINISHED
    };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим критикалов", Mode::Sentinel, "Sentinel");
    BoolSetting mVelocity = BoolSetting("Скорость", "Изменять вело (оптимизация)", true);
    BoolSetting mPositionChange = BoolSetting("Позиция", "Менять позицию", true);
    BoolSetting mBiggerPositionChange = BoolSetting("Большая смена поз.", "Сильнее менять позицию", true);
    BoolSetting mSendJumping = BoolSetting("Слать прыжки", "Слать пакеты прыжка", true);
    BoolSetting mOffSprint = BoolSetting("Отключить спринт", "Отключать спринт при ударе", true);
    NumberSetting mPositionChangePersent = NumberSetting("Процент смены", "Процент изменения позиции", 1.5, 0, 2, 0.01);

    Criticals() : ModuleBase("Criticals", "Гарантирует критические удары по противнику", ModuleCategory::Combat, 0, false) {

        addSetting(&mMode);
        addSetting(&mVelocity);
        addSetting(&mPositionChange);
        addSetting(&mBiggerPositionChange);
        addSetting(&mSendJumping);
        addSetting(&mOffSprint);
        addSetting(&mPositionChangePersent);

        mNames = {
                {Lowercase, "criticals"},
                {LowercaseSpaced, "criticals"},
                {Normal, "Criticals"},
                {NormalSpaced, "Criticals"}
        };
    }

    bool mWasSprinting = true;
    AnimationState mAnimationState = AnimationState::START;

    float mJumpPositions[4] = {0, 0.8200100660324097 - 0.6200100183486938, 0.741610050201416 - 0.6200100183486938, 0}; 
    float mJumpPositionsMini[4] = {0, 0.02, 0.01, 0}; 
    float mJumpVelocities[4] = {-0.07840000092983246, -0.07840000092983246, -0.1552319973707199f, -0.07840000092983246};

    void onEnable() override;
    void onDisable() override;
    void onPacketOutEvent(class PacketOutEvent& event);
};