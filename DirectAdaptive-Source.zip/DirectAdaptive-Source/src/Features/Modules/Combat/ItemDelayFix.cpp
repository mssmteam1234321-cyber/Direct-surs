﻿#include "ItemDelayFix.hpp"

#include <Features/FeatureManager.hpp>
#include <Features/Events/BaseTickEvent.hpp>
#include <Features/Events/PacketOutEvent.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Inventory/PlayerInventory.hpp>
#include <SDK/Minecraft/Network/Packets/MobEquipmentPacket.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>

ItemDelayFix::ItemDelayFix()
    : ModuleBase(
        "ItemDelayFix",
        "Исправляет задержку предметов",
        ModuleCategory::Combat,
        0,
        false) {

    mNames = {
        {Lowercase,        "itemdelayfix"},
        {LowercaseSpaced,  "item delay fix"},
        {Normal,           "ItemDelayFix"},
        {NormalSpaced,     "Item Delay Fix"},
    };
}

void ItemDelayFix::onEnable() {
    gFeatureManager->mDispatcher->listen<BaseTickEvent, &ItemDelayFix::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketOutEvent, &ItemDelayFix::onPacketOutEvent>(this);

    auto player = ClientInstance::get()->getLocalPlayer();
    if (player) {
        mLastSelectedSlot = player->getSupplies()->mSelectedSlot;
    }
}

void ItemDelayFix::onDisable() {
    gFeatureManager->mDispatcher->deafen<BaseTickEvent, &ItemDelayFix::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketOutEvent, &ItemDelayFix::onPacketOutEvent>(this);

    mWasSwitchedManually = false;
    mLastSelectedSlot = -1;
    
    
    mIsAuraSpoofing = false;
    mAuraSpoofedSlot = -1;
    mSlotBeforeAuraSpoof = -1;
    mAuraSpoofTime = 0;
}

void ItemDelayFix::onBaseTickEvent(BaseTickEvent& event) {
    auto player = event.mActor;
    if (!player) return;

    auto supplies = player->getSupplies();
    if (!supplies) return;

    int currentSlot = supplies->mSelectedSlot;
    
    
    if (mIsAuraSpoofing && currentSlot == mSlotBeforeAuraSpoof && NOW - mAuraSpoofTime < 1000) {
        
        supplies->mSelectedSlot = mAuraSpoofedSlot;
        return;
    }
    
    
    if (mIsAuraSpoofing && (NOW - mAuraSpoofTime > 1000 || currentSlot != mSlotBeforeAuraSpoof && currentSlot != mAuraSpoofedSlot)) {
        mIsAuraSpoofing = false;
        mAuraSpoofedSlot = -1;
        mSlotBeforeAuraSpoof = -1;
    }

    
    if (currentSlot != mLastSelectedSlot) {
        
        if (!mIsAuraSpoofing || currentSlot != mAuraSpoofedSlot) {
            mWasSwitchedManually = true;
            mLastManualSwitch = NOW;
            mLastSelectedSlot = currentSlot;
        }
    }

    
    if (mWasSwitchedManually && (NOW - mLastManualSwitch) > mDelayTime) {
        mWasSwitchedManually = false;
    }
}

void ItemDelayFix::onPacketOutEvent(PacketOutEvent& event) {
    if (!event.mPacket || event.mPacket->getId() != PacketID::MobEquipment)
        return;

    auto pkt = event.getPacket<MobEquipmentPacket>();
    if (!pkt) return;

    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    if (pkt->mRuntimeId != player->getRuntimeID())
        return;

    auto supplies = player->getSupplies();
    if (!supplies) return;

    int currentSlot = supplies->mSelectedSlot;
    
    
    
    if (pkt->mSlot != currentSlot && !mIsAuraSpoofing) {
        
        mSlotBeforeAuraSpoof = currentSlot;
        mAuraSpoofedSlot = pkt->mSlot;
        mAuraSpoofTime = NOW;
        mIsAuraSpoofing = true;
    }
    
    
    if (mIsAuraSpoofing && pkt->mSlot == mSlotBeforeAuraSpoof && NOW - mAuraSpoofTime < 1000) {
        
        event.cancel();
        return;
    }
    
    
    if (mIsAuraSpoofing && (NOW - mAuraSpoofTime > 1000 || currentSlot != mSlotBeforeAuraSpoof)) {
        mIsAuraSpoofing = false;
        mAuraSpoofedSlot = -1;
        mSlotBeforeAuraSpoof = -1;
    }

    
    if (mWasSwitchedManually) {
        if (pkt->mSlot != mLastSelectedSlot) {
            event.cancel();
        }
    }
}