#include "Aura.hpp"

#include <Features/FeatureManager.hpp>
#include <Features/Events/BaseTickEvent.hpp>
#include <Features/Events/BobHurtEvent.hpp>
#include <Features/Events/BoneRenderEvent.hpp>
#include <Features/Events/PacketInEvent.hpp>
#include <Features/Events/PacketOutEvent.hpp>
#include <Features/Events/RenderEvent.hpp>
#include <Features/Modules/Misc/Friends.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Options.hpp>
#include <Utils/GameUtils/ActorUtils.hpp>
#include <Utils/GameUtils/ItemUtils.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>
#include <Utils/MiscUtils/MathUtils.hpp>
#include <Utils/MiscUtils/RenderUtils.hpp>
#include <Utils/MemUtils.hpp>
#include <Utils/GameUtils/PacketUtils.hpp>
#include <Utils/GameUtils/ChatUtils.hpp>
#include <algorithm>
#include <SDK/Minecraft/Actor/Actor.hpp>
#include <SDK/Minecraft/Actor/GameMode.hpp>
#include <SDK/Minecraft/World/Level.hpp>
#include <SDK/Minecraft/World/HitResult.hpp>
#include <SDK/Minecraft/Inventory/PlayerInventory.hpp>
#include <SDK/Minecraft/Network/LoopbackPacketSender.hpp>
#include <SDK/Minecraft/Network/Packets/MovePlayerPacket.hpp>
#include <SDK/Minecraft/Network/Packets/PlayerAuthInputPacket.hpp>
#include <SDK/Minecraft/Network/Packets/RemoveActorPacket.hpp>
#include <SDK/Minecraft/Network/Packets/InventoryTransactionPacket.hpp>
#include <SDK/Minecraft/Rendering/GuiData.hpp>
#include <SDK/Minecraft/Actor/Components/ActorTypeComponent.hpp>
#include <SDK/Minecraft/KeyboardMouseSettings.hpp>
#include <Utils/Keyboard.hpp>
#include <spdlog/spdlog.h>
#include <imgui.h>
#include <algorithm>
#include <unordered_map>
#include <chrono>

#include "backtrack.hpp"

int Aura::getSword(Actor* target) {
    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player || !player->isValid()) return -1;
    auto supplies = player->getSupplies();
    if (!supplies) return -1;
    auto container = supplies->getContainer();
    if (!container) return -1;

    int bestSword = ItemUtils::getBestItem(SItemType::Sword, false);

    if (bestSword != -1) {
        return bestSword;
    }

    return player->getSupplies()->mSelectedSlot;
}



void Aura::onEnable()
{
    mLockedTarget = nullptr;
    mCritHitPerformed = false;
    gFeatureManager->mDispatcher->listen<BaseTickEvent, &Aura::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketOutEvent, &Aura::onPacketOutEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketInEvent, &Aura::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->listen<RenderEvent, &Aura::onRenderEvent>(this);
    gFeatureManager->mDispatcher->listen<BobHurtEvent, &Aura::onBobHurtEvent, nes::event_priority::FIRST>(this);
    gFeatureManager->mDispatcher->listen<BoneRenderEvent, &Aura::onBoneRenderEvent, nes::event_priority::FIRST>(this);


}

void Aura::onDisable()
{
    mLockedTarget = nullptr;
    mCritHitPerformed = false;
    gFeatureManager->mDispatcher->deafen<BaseTickEvent, &Aura::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketOutEvent, &Aura::onPacketOutEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketInEvent, &Aura::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->deafen<RenderEvent, &Aura::onRenderEvent>(this);
    gFeatureManager->mDispatcher->deafen<BobHurtEvent, &Aura::onBobHurtEvent>(this);
    sHasTarget = false;
    sTarget = nullptr;
    mRotating = false;

}
float EaseInOutExpo(float pct)
{
    if (pct < 0.5f) {
        return (pow(2.f, 16.f * pct) - 1.f) / 510.f;
    }
    else {
        return 1.f - 0.5f * pow(2.f, -16.f * (pct - 0.5f));
    }
}

void Aura::onRenderEvent(RenderEvent& event)
{


    if (false)
    {
        auto player = ClientInstance::get()->getLocalPlayer();
        if (!player) return;

        if (mRotating)
        {
            glm::vec2 rots = MathUtils::getRots(*player->getPos(), mTargetedAABB);
            auto rot = player->getActorRotationComponent();
            rot->mPitch = rots.x;
            rot->mYaw = rots.y;
            rot->mOldPitch = rots.x;
            rot->mOldYaw = rots.y;

        }
    }

    if (false) {
        auto player = ClientInstance::get()->getLocalPlayer();
        if (!player) return;

        auto actor = Aura::sTarget;

        if (!actor || !actor->isValid())
        {
            Aura::sTarget = nullptr;
            Aura::sHasTarget = false;
            return;
        }

        if (!TRY_CALL([&]() { bool isPlayer = actor->isPlayer(); }))
        {
            Aura::sTarget = nullptr;
            Aura::sHasTarget = false;
            return;
        }

        if (!actor->isPlayer()) return;

        auto playerPos = player->getRenderPositionComponent()->mPosition;
        auto actorPos = actor->getRenderPositionComponent()->mPosition;
        auto state = actor->getStateVectorComponent();
        auto shape = player->getAABBShapeComponent();

        glm::vec3 pos = actorPos - glm::vec3(0.f, 1.62f, 0.f);
        glm::vec3 pos2 = state->mPos - glm::vec3(0.f, 1.62f, 0.f);
        glm::vec3 posOld = state->mPosOld - glm::vec3(0.f, 1.62f, 0.f);
        pos = posOld + (pos2 - posOld) * ImGui::GetIO().DeltaTime;

        float hitboxWidth = shape->mWidth;
        float hitboxHeight = shape->mHeight;

        glm::vec3 aabbMin = glm::vec3(pos.x - hitboxWidth / 2, pos.y, pos.z - hitboxWidth / 2);
        glm::vec3 aabbMax = glm::vec3(pos.x + hitboxWidth / 2, pos.y + hitboxHeight, pos.z + hitboxWidth / 2);

        aabbMin = aabbMin - glm::vec3(0.1f, 0.1f, 0.1f);
        aabbMax = aabbMax + glm::vec3(0.1f, 0.1f, 0.1f);

        float distance = glm::distance(playerPos, actorPos) + 2.5f;
        if (distance < 0) distance = 0;

        float scaledSphereSize = 1.0f / distance * 100.0f;
        if (scaledSphereSize < 1.0f) scaledSphereSize = 1.0f;


        glm::vec3 bottomOfHitbox = aabbMin;
        glm::vec3 topOfHitbox = aabbMax;
        bottomOfHitbox.x = pos.x;
        bottomOfHitbox.z = pos.z;
        topOfHitbox.x = pos.x;
        topOfHitbox.z = pos.z;
        topOfHitbox.y += 0.1f;

        static float pct = 0.f;
        static bool reversed = false;
        static uint64_t lastTime = NOW;

        float speed = 1.0f;
        uint64_t visualTime = 800 / (speed - 0.2);

        if (NOW - lastTime > visualTime) {
            reversed = !reversed;
            lastTime = NOW;
            pct = reversed ? 1.f : 0.f;
        }

        pct += !reversed ? (speed * ImGui::GetIO().DeltaTime) : -(speed * ImGui::GetIO().DeltaTime);
        pct = MathUtils::lerp(0.f, 1.f, pct);
        pos = MathUtils::lerp(bottomOfHitbox, topOfHitbox, EaseInOutExpo(pct));

        auto corrected = RenderUtils::transform.mMatrix;

        glm::vec2 screenPos = { 0, 0 };

        static float angleOffset = 0.f;
        angleOffset += (1.0f * 30.f) * ImGui::GetIO().DeltaTime;
        float radius = 1.0f;

        for (int i = 0; i < 1; i++) {
            float angle = (i / 1.0f) * 360.f;
            angle += angleOffset;
            angle = MathUtils::wrap(angle, -180.f, 180.f);

            float rad = angle * (PI / 180.0f);

            float x = pos.x + radius * cosf(rad);
            float y = pos.y;
            float z = pos.z + radius * sinf(rad);

            glm::vec3 thisPos = { x, y, z };

            if (!corrected.OWorldToScreen(
                RenderUtils::transform.mOrigin,
                thisPos, screenPos, MathUtils::fov,
                ClientInstance::get()->getGuiData()->mResolution))
                continue;

            ImColor color = ColorUtils::getThemedColor(0);
            ImColor glowColor = color;
            glowColor.Value.w = 0.3f;

            ImGui::GetBackgroundDrawList()->AddCircleFilled(ImVec2(screenPos.x, screenPos.y), scaledSphereSize * 1.5f, glowColor);
            ImGui::GetBackgroundDrawList()->AddCircleFilled(ImVec2(screenPos.x, screenPos.y), scaledSphereSize, color);
        }
    }

}

void Aura::onBaseTickEvent(BaseTickEvent& event)
{
    auto player = event.mActor; 
    if (!player || !player->isValid()) return;
    if (player->getHealth() <= 0) return; 
    auto supplies = player->getSupplies();

    auto actors = ActorUtils::getActorList(false, true);
    static std::unordered_map<Actor*, int64_t> lastAttacks = {};
    bool isMoving = Keyboard::isUsingMoveKeys();



    static int64_t lastAttack = 0;
    int64_t now = NOW;
    float aps = mAPS.mValue;

    int64_t delay = 1000 / aps;

    bool foundAttackable = false;

    if (mTargetLock.mValue)
    {
        if (mLockedTarget && mLockedTarget->isValid() && mLockedTarget->isPlayer() && mLockedTarget->getHealth() > 0)
        {
            actors.clear();
            actors.push_back(mLockedTarget);
        }
    }

    const int IDX_CONTAINER = 0;
    const int IDX_EATING = 1;

    if (mDontAttackWhen.hasValue(IDX_CONTAINER)) {
        auto screenName = ClientInstance::get()->getScreenName();
        if (screenName == "chest_screen" || screenName == "container_screen" ||
            screenName == "inventory_screen" || screenName == "furnace_screen" ||
            screenName == "crafting_screen" || screenName == "anvil_screen") {
            return;
        }
    }

    if (mDontAttackWhen.hasValue(IDX_EATING)) {
        if (player->getStatusFlag(ActorFlags::Usingitem) || player->getStatusFlag(ActorFlags::Eating)) {
            return;
        }
    }

    if (mWeaponOnly.mValue) {
        auto item = supplies->getContainer()->getItem(supplies->mSelectedSlot);
        if (!item || !item->mItem) return;

        auto itemType = item->getItem()->getItemType();
        bool isSword = itemType == SItemType::Sword;
        bool isTrident = item->getItem()->mItemId == 455;

        if (!isSword && !isTrident) return;
    }

    if (mHoldSpace.mValue) {
        auto keyboard = ClientInstance::get()->getKeyboardSettings();
        if (!keyboard) return;
        int jumpKey = keyboard->operator[]("key.jump");
        bool holdingJump = Keyboard::mPressedKeys[jumpKey];
        if (!holdingJump) return;
    }

    std::vector<Actor*> validTargets;

    for (auto actor : actors)
    {
        if (actor == player) continue;

        if (!actor || !actor->isValid()) continue;
        if (actor->getHealth() <= 0) continue;

        float range = mRange.mValue;
        Backtrack::Record backRec{};
        bool hasBackRec = false;
        if (mBacktrackOnly.mValue)
        {
            auto bt = gFeatureManager->mModuleManager->getModule<Backtrack>();
            if (!bt || !bt->mEnabled) continue;
            if (!bt->getBestRecord(player, actor, backRec)) continue;
            hasBackRec = true;
        }
        float distance = hasBackRec ? glm::distance(*player->getPos(), backRec.mPos)
            : (mTPSSync.mValue ? getSyncedDistance(player, actor) : actor->distanceTo(player));
        if (distance > range) continue;
        if (!mAttackThroughWalls.mValue && !player->canSee(actor)) continue;

        
        const int IDX_PLAYERS = 0;
        const int IDX_INVIS = 1;
        const int IDX_FRIENDS = 2;
        const int IDX_NAKED = 3;
        const int IDX_MOBS = 4;

        auto typeComp = actor->getActorTypeComponent();
        ActorType aType = typeComp ? typeComp->mType : ActorType::None;

        if (actor->isPlayer()) {
            if (!mTargetFilters.hasValue(IDX_PLAYERS)) continue;

            if (gFriendManager && gFriendManager->mEnabled && gFriendManager->isFriend(actor)) {
                if (!mTargetFilters.hasValue(IDX_FRIENDS)) continue;
            }

            auto armor = actor->getArmorContainer();
            bool hasArmor = false;
            if (armor) {
                auto h = armor->getItem(0);
                auto c = armor->getItem(1);
                auto l = armor->getItem(2);
                auto b = armor->getItem(3);
                hasArmor = (h && h->mItem) || (c && c->mItem) || (l && l->mItem) || (b && b->mItem);
            }

            if (mTargetPriority.mValue == TargetPriority::Armor) {
                if (!hasArmor) continue;
            }
            else {
                if (!hasArmor && !mTargetFilters.hasValue(IDX_NAKED)) continue;
            }
        }
        else {
            bool isMob = (static_cast<uint32_t>(aType) & static_cast<uint32_t>(ActorType::Mob)) != 0;

            if (!mTargetFilters.hasValue(IDX_MOBS)) continue;
            if (!isMob) continue;
        }

        if (actor->getStatusFlag(ActorFlags::Invisible) && !mTargetFilters.hasValue(IDX_INVIS)) continue;

        validTargets.push_back(actor);
    }

    if (!validTargets.empty())
    {
        std::sort(validTargets.begin(), validTargets.end(), [&](Actor* a, Actor* b) {
            switch (mTargetPriority.mValue)
            {
            case TargetPriority::Distance:
            {
                float distA = mTPSSync.mValue ? getSyncedDistance(player, a) : a->distanceTo(player);
                float distB = mTPSSync.mValue ? getSyncedDistance(player, b) : b->distanceTo(player);
                return distA < distB;
            }

            case TargetPriority::Health:
                return a->getHealth() < b->getHealth();

            case TargetPriority::Armor:
            {
                auto armorA = a->getArmorContainer();
                auto armorB = b->getArmorContainer();
                int countA = 0, countB = 0;
                if (armorA) {
                    for (int i = 0; i < 4; i++) {
                        auto item = armorA->getItem(i);
                        if (item && item->mItem) countA++;
                    }
                }
                if (armorB) {
                    for (int i = 0; i < 4; i++) {
                        auto item = armorB->getItem(i);
                        if (item && item->mItem) countB++;
                    }
                }
                return countA < countB;
            }

            case TargetPriority::FieldOfView:
            {
                auto playerRot = player->getActorRotationComponent();
                if (!playerRot) return false;

                auto playerPos = *player->getPos();
                glm::vec2 rotsA = MathUtils::getRots(playerPos, a->getAABB());
                glm::vec2 rotsB = MathUtils::getRots(playerPos, b->getAABB());

                float yawDiffA = std::abs(MathUtils::wrap(rotsA.y - playerRot->mYaw, -180.f, 180.f));
                float pitchDiffA = std::abs(rotsA.x - playerRot->mPitch);
                float yawDiffB = std::abs(MathUtils::wrap(rotsB.y - playerRot->mYaw, -180.f, 180.f));
                float pitchDiffB = std::abs(rotsB.x - playerRot->mPitch);

                float totalDiffA = yawDiffA + pitchDiffA;
                float totalDiffB = yawDiffB + pitchDiffB;

                return totalDiffA < totalDiffB;
            }

            case TargetPriority::All:
            {
                float distA = mTPSSync.mValue ? getSyncedDistance(player, a) : a->distanceTo(player);
                float distB = mTPSSync.mValue ? getSyncedDistance(player, b) : b->distanceTo(player);
                float scoreA = distA * 0.3f + a->getHealth() * 0.3f;
                float scoreB = distB * 0.3f + b->getHealth() * 0.3f;

                auto armorA = a->getArmorContainer();
                auto armorB = b->getArmorContainer();
                int countA = 0, countB = 0;
                if (armorA) {
                    for (int i = 0; i < 4; i++) {
                        auto item = armorA->getItem(i);
                        if (item && item->mItem) countA++;
                    }
                }
                if (armorB) {
                    for (int i = 0; i < 4; i++) {
                        auto item = armorB->getItem(i);
                        if (item && item->mItem) countB++;
                    }
                }
                scoreA += countA * 0.2f;
                scoreB += countB * 0.2f;

                auto playerRot = player->getActorRotationComponent();
                if (playerRot) {
                    auto playerPos = *player->getPos();
                    glm::vec2 rotsA = MathUtils::getRots(playerPos, a->getAABB());
                    glm::vec2 rotsB = MathUtils::getRots(playerPos, b->getAABB());

                    float yawDiffA = std::abs(MathUtils::wrap(rotsA.y - playerRot->mYaw, -180.f, 180.f));
                    float pitchDiffA = std::abs(rotsA.x - playerRot->mPitch);
                    float yawDiffB = std::abs(MathUtils::wrap(rotsB.y - playerRot->mYaw, -180.f, 180.f));
                    float pitchDiffB = std::abs(rotsB.x - playerRot->mPitch);

                    float fovDiffA = yawDiffA + pitchDiffA;
                    float fovDiffB = yawDiffB + pitchDiffB;

                    scoreA += fovDiffA * 0.2f;
                    scoreB += fovDiffB * 0.2f;
                }

                return scoreA < scoreB;
            }
            }
            return false;
            });
    }

    for (auto actor : validTargets)
    {
        foundAttackable = true;
        if (mTargetLock.mValue)
            mLockedTarget = actor;
        sTarget = actor;
        sTargetRuntimeID = actor->getRuntimeID();

        if (mTargetingType.mValue == TargetingType::Legit || mTargetingType.mValue == TargetingType::NeverTime || mTargetingType.mValue == TargetingType::Snap)
            rotate(actor);

        if (mCritOnly.mValue)
        {
            if (player->isOnGround())
            {
                mCritHitPerformed = false;

                if (now - lastAttack >= delay)
                {
                    player->jumpFromGround();
                }
                break;
            }
            if (player->getFallDistance() > 0.0f && !mCritHitPerformed)
            {
                mCritHitPerformed = true;
            }
            else if (mCritHitPerformed)
            {
                break;
            }
            else
            {
                break;
            }
        }

        if (now - lastAttack < delay) break;

        
        if (mBacktrackOnly.mValue)
        {
            auto backtrack = gFeatureManager->mModuleManager->getModule<Backtrack>();
            if (!backtrack || !backtrack->mEnabled)
                continue;

            Backtrack::Record rec{};
            if (!backtrack->getBestRecord(player, actor, rec))
                continue;
        }

        player->swing();
        int slot = -1;
        int bestWeapon = getSword(actor);
        slot = player->getSupplies()->mSelectedSlot;

        auto ogActor = actor;
        if (mTargetingType.mValue == TargetingType::NeverTime)
            actor = findObstructingActor(player, actor);

        if (!actor || !actor->isValid()) continue;
        if (actor->getHealth() <= 0) continue;

        player->getLevel()->getHitResult()->mType = HitType::ENTITY;


        if (false)
        {
            
            
            
        }
        else {
            int oldSlot = supplies->mSelectedSlot;
            auto gameMode = player->getGameMode();
            if (gameMode) {
                gameMode->attack(actor);
            }
            supplies->mSelectedSlot = oldSlot;
        }

        lastAttack = now;
        lastAttacks[actor] = now;
        break;
    }

    if (!foundAttackable)
    {
        mRotating = false;
        sTarget = nullptr;
        if (mTargetLock.mValue) mLockedTarget = nullptr;
    }
    sHasTarget = foundAttackable;


}

void Aura::onPacketOutEvent(PacketOutEvent& event)
{
    if (!mRotating) return;

    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    if (event.mPacket->getId() == PacketID::PlayerAuthInput) {
        auto pkt = event.getPacket<PlayerAuthInputPacket>();
        glm::vec2 rots = MathUtils::getRots(*player->getPos(), mTargetedAABB);

        if (mTargetingType.mValue == TargetingType::Legit) {
            auto rot = player->getActorRotationComponent();
            if (!rot) return;
            auto head = player->getActorHeadRotationComponent();
            auto body = player->getMobBodyRotationComponent();
            float curYaw = rot->mYaw;
            float curPitch = rot->mPitch;
            float targetYaw = rots.y;
            float targetPitch = rots.x;
            float dyaw = MathUtils::wrap(targetYaw - curYaw, -180.f, 180.f);
            float dpitch = targetPitch - curPitch;
            float yawSpeed = MathUtils::randomFloat(15.0f, 25.0f);
            float pitchSpeed = MathUtils::randomFloat(10.0f, 20.0f);
            float yawStep = yawSpeed * ImGui::GetIO().DeltaTime * 60.0f;
            float pitchStep = pitchSpeed * ImGui::GetIO().DeltaTime * 60.0f;
            float newYaw = curYaw + MathUtils::clamp(dyaw, -yawStep, yawStep);
            float newPitch = curPitch + MathUtils::clamp(dpitch, -pitchStep, pitchStep);
            newPitch = MathUtils::clamp(newPitch, -89.9f, 89.9f);
            float wrappedYaw = MathUtils::wrap(newYaw, -180.f, 180.f);
            rot->mPitch = newPitch;
            rot->mYaw = wrappedYaw;
            rot->mOldPitch = newPitch;
            rot->mOldYaw = wrappedYaw;
            if (head) { head->mHeadRot = wrappedYaw; head->mOldHeadRot = wrappedYaw; }
            if (body) { body->yBodyRot = wrappedYaw; body->yOldBodyRot = wrappedYaw; }
            pkt->mRot = { newPitch, wrappedYaw };
            pkt->mYHeadRot = wrappedYaw;
        }
        else if (mTargetingType.mValue == TargetingType::Snap || mTargetingType.mValue == TargetingType::NeverTime) {
            auto rot = player->getActorRotationComponent();
            auto head = player->getActorHeadRotationComponent();
            auto body = player->getMobBodyRotationComponent();
            float clampedPitch = MathUtils::clamp(rots.x, -89.9f, 89.9f);
            float wrappedYaw = MathUtils::wrap(rots.y, -180.f, 180.f);
            rot->mPitch = clampedPitch;
            rot->mYaw = wrappedYaw;
            rot->mOldPitch = clampedPitch;
            rot->mOldYaw = wrappedYaw;
            if (head) { head->mHeadRot = wrappedYaw; head->mOldHeadRot = wrappedYaw; }
            if (body) { body->yBodyRot = wrappedYaw; body->yOldBodyRot = wrappedYaw; }
            pkt->mRot = { clampedPitch, wrappedYaw };
            pkt->mYHeadRot = wrappedYaw;
        }
    }
    else if (event.mPacket->getId() == PacketID::MovePlayer) {
        auto pkt = event.getPacket<MovePlayerPacket>();
        glm::vec2 rots = MathUtils::getRots(*player->getPos(), mTargetedAABB);

        if (mTargetingType.mValue == TargetingType::Legit) {
            auto rot = player->getActorRotationComponent();
            if (!rot) return;
            auto head = player->getActorHeadRotationComponent();
            auto body = player->getMobBodyRotationComponent();
            float curYaw = rot->mYaw;
            float curPitch = rot->mPitch;
            float targetYaw = rots.y;
            float targetPitch = rots.x;
            float dyaw = MathUtils::wrap(targetYaw - curYaw, -180.f, 180.f);
            float dpitch = targetPitch - curPitch;
            float yawSpeed = MathUtils::randomFloat(15.0f, 25.0f);
            float pitchSpeed = MathUtils::randomFloat(10.0f, 20.0f);
            float yawStep = yawSpeed * ImGui::GetIO().DeltaTime * 60.0f;
            float pitchStep = pitchSpeed * ImGui::GetIO().DeltaTime * 60.0f;
            float newYaw = curYaw + MathUtils::clamp(dyaw, -yawStep, yawStep);
            float newPitch = curPitch + MathUtils::clamp(dpitch, -pitchStep, pitchStep);
            newPitch = MathUtils::clamp(newPitch, -89.9f, 89.9f);
            float wrappedYaw = MathUtils::wrap(newYaw, -180.f, 180.f);
            rot->mPitch = newPitch;
            rot->mYaw = wrappedYaw;
            rot->mOldPitch = newPitch;
            rot->mOldYaw = wrappedYaw;
            if (head) { head->mHeadRot = wrappedYaw; head->mOldHeadRot = wrappedYaw; }
            if (body) { body->yBodyRot = wrappedYaw; body->yOldBodyRot = wrappedYaw; }
            pkt->mRot = { newPitch, wrappedYaw };
            pkt->mYHeadRot = wrappedYaw;
        }
        else if (mTargetingType.mValue == TargetingType::Snap || mTargetingType.mValue == TargetingType::NeverTime) {
            auto rot = player->getActorRotationComponent();
            auto head = player->getActorHeadRotationComponent();
            auto body = player->getMobBodyRotationComponent();
            float clampedPitch = MathUtils::clamp(rots.x, -89.9f, 89.9f);
            float wrappedYaw = MathUtils::wrap(rots.y, -180.f, 180.f);
            rot->mPitch = clampedPitch;
            rot->mYaw = wrappedYaw;
            rot->mOldPitch = clampedPitch;
            rot->mOldYaw = wrappedYaw;
            if (head) { head->mHeadRot = wrappedYaw; head->mOldHeadRot = wrappedYaw; }
            if (body) { body->yBodyRot = wrappedYaw; body->yOldBodyRot = wrappedYaw; }
            pkt->mRot = { clampedPitch, wrappedYaw };
            pkt->mYHeadRot = wrappedYaw;
        }
    }
    else if (event.mPacket->getId() == PacketID::Animate)
    {
        mLastSwing = NOW;
    }
    else if (event.mPacket->getId() == PacketID::InventoryTransaction)
    {
        auto pkt = event.getPacket<InventoryTransactionPacket>();
        auto cit = pkt->mTransaction.get();

        if (cit->type == ComplexInventoryTransaction::Type::ItemUseTransaction)
        {
            const auto iut = reinterpret_cast<ItemUseInventoryTransaction*>(cit);
            if (iut->mActionType == ItemUseInventoryTransaction::ActionType::Place) {
            }
        }

        if (cit->type == ComplexInventoryTransaction::Type::ItemUseOnEntityTransaction)
        {
            const auto iut = reinterpret_cast<ItemUseOnActorInventoryTransaction*>(cit);
            if (iut->mActionType == ItemUseOnActorInventoryTransaction::ActionType::Attack)
            {
                
            }
        }
    }

}

void Aura::onPacketInEvent(PacketInEvent& event)
{
    if (event.mPacket->getId() == PacketID::RemoveActor)
    {
        auto packet = event.getPacket<RemoveActorPacket>();
        if (sTarget && sTargetRuntimeID == packet->mRuntimeID)
        {
            
            sHasTarget = false;
            sTarget = nullptr;
        }
    }

    if (event.mPacket->getId() == PacketID::ChangeDimension)
    {
        if (mDisableOnDimensionChange.mValue)
        {
            this->setEnabled(false);
        }
    }
}

void Aura::onBobHurtEvent(BobHurtEvent& event)
{
    if (sHasTarget)
    {
        event.mDoBlockAnimation = true;
    }
}

void Aura::onBoneRenderEvent(BoneRenderEvent& event)
{
    if (sHasTarget)
    {
        event.mDoBlockAnimation = true;
    }
}

Actor* Aura::findObstructingActor(Actor* player, Actor* target)
{
    if (!player || !target || !player->isValid() || !target->isValid()) return target;

    auto actors = ActorUtils::getActorList(false, false);

    glm::vec3 playerPos = *player->getPos();
    glm::vec3 targetPos = *target->getPos();
    glm::vec3 direction = glm::normalize(targetPos - playerPos);
    float maxDistance = glm::distance(playerPos, targetPos);

    Actor* closestObstruction = nullptr;
    float closestDistToPlayer = maxDistance;

    for (auto actor : actors)
    {
        if (!actor || !actor->isValid() || actor == player || actor == target) continue;

        float distToPlayer = actor->distanceTo(player);
        if (distToPlayer >= closestDistToPlayer) continue;

        if (distToPlayer > maxDistance + 1.0f) continue;

        auto shape = actor->getAABBShapeComponent();
        if (!shape) continue;

        AABB actorAABB = actor->getAABB();

        if (MathUtils::rayIntersectsAABB(playerPos, targetPos, actorAABB.mMin, actorAABB.mMax))
        {
            if (distToPlayer < closestDistToPlayer)
            {
                closestObstruction = actor;
                closestDistToPlayer = distToPlayer;
            }
        }
    }

    return closestObstruction ? closestObstruction : target;
}

AABB Aura::getSyncedAABB(Actor* actor) const
{
    if (!actor || !actor->isValid()) return AABB();

    auto stateVector = actor->getStateVectorComponent();
    if (!stateVector) return actor->getAABB();

    auto shape = actor->getAABBShapeComponent();
    if (!shape) return actor->getAABB();

    glm::vec3 syncedPos = stateVector->mPos;
    float width = shape->mWidth;
    float height = shape->mHeight;

    AABB syncedAABB;
    syncedAABB.mMin = glm::vec3(syncedPos.x - width / 2.0f, syncedPos.y, syncedPos.z - width / 2.0f);
    syncedAABB.mMax = glm::vec3(syncedPos.x + width / 2.0f, syncedPos.y + height, syncedPos.z + width / 2.0f);

    return syncedAABB;
}

float Aura::getSyncedDistance(Actor* player, Actor* target) const
{
    if (!player || !target || !player->isValid() || !target->isValid()) return 999.0f;

    auto playerState = player->getStateVectorComponent();
    auto targetState = target->getStateVectorComponent();

    if (!playerState || !targetState) return player->distanceTo(target);

    glm::vec3 playerPos = playerState->mPos;
    glm::vec3 targetPos = targetState->mPos;

    return glm::distance(playerPos, targetPos);
}

void Aura::rotate(Actor* target)
{
    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;
    if (!target || !target->isValid()) return;

    if (mBacktrackOnly.mValue) {
        auto bt = gFeatureManager->mModuleManager->getModule<Backtrack>();
        Backtrack::Record rec{};
        if (bt && bt->mEnabled && bt->getBestRecord(player, target, rec)) {
            mTargetedAABB = rec.mBox;
        }
        else {
            mTargetedAABB = mTPSSync.mValue ? getSyncedAABB(target) : target->getAABB();
        }
    }
    else {
        mTargetedAABB = mTPSSync.mValue ? getSyncedAABB(target) : target->getAABB();
    }

    mRotating = true;
}
