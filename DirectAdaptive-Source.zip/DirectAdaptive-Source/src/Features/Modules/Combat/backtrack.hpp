#pragma once

#include <Features/Modules/Module.hpp>
#include <Features/Events/BaseTickEvent.hpp>
#include <Features/Events/PacketOutEvent.hpp>
#include <Features/Events/RenderEvent.hpp>

#include <SDK/Minecraft/Actor/Actor.hpp>

#include <deque>
#include <unordered_map>
#include <mutex>

class Backtrack : public ModuleBase<Backtrack>
{
public:
    struct Record
    {
        glm::vec3 mPos;
        AABB mBox;
        uint64_t mTime;
    };

    NumberSetting mBacktrackMs = NumberSetting("Backtrack (мс)", "Время отката позиций в мс", 150.0f, 0.0f, 400.0f, 10.0f);
    BoolSetting   mRender      = BoolSetting("Визуализация", "Отображать прошлые позиции", true);

    Backtrack() : ModuleBase<Backtrack>("Backtrack", "Откатывает позиции игроков, чтобы бить их в прошлом", ModuleCategory::Combat, 0, false)
    {
        addSettings(&mBacktrackMs, &mRender);

        mNames = {
            {Lowercase, "backtrack"},
            {LowercaseSpaced, "backtrack"},
            {Normal, "Backtrack"},
            {NormalSpaced, "Backtrack"}
        };
    }

    void onEnable() override;
    void onDisable() override;

    void onBaseTickEvent(BaseTickEvent& event);
    void onPacketOutEvent(PacketOutEvent& event);
    void onRenderEvent(RenderEvent& event);

    bool getBestRecord(Actor* local, Actor* target, Record& outRecord);

private:
    using History = std::deque<Record>;

    std::unordered_map<int64_t, History> mHistory;
    std::mutex mMutex;
    uint64_t mLastSampleTime = 0;

    void sampleActors(Actor* local);
    void purgeOld(uint64_t now);
};
