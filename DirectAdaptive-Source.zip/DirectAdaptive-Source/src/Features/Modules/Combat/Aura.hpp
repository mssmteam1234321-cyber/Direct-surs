#pragma once




#include <Features/Modules/Module.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>


class Aura : public ModuleBase<Aura> {
public:
    enum class TargetingType {
        Legit,
        NeverTime,
        Snap
    };

    enum class TargetPriority {
        Distance,
        Health,
        Armor,
        FieldOfView,
        All
    };

    EnumSettingT<TargetingType> mTargetingType = EnumSettingT("Тип наведения", "Тип наведения", TargetingType::Legit, "Легитный", "NeverTime", "Снапы");
    EnumSettingT<TargetPriority> mTargetPriority = EnumSettingT("Приоритет по", "Приоритет", TargetPriority::Distance, "Дистанция", "Здоровье", "Броня", "Полю зрения", "Всему сразу");
    MultiEnumSetting mTargetFilters = MultiEnumSetting(
        "Кого атаковать",
        "Фильтры для целей ауры",
        std::vector<std::string>{
            "Бить игроков",
            "Бить невидимых",
            "Бить Друзей",
            "Бить Голых",
            "Бить Мобов"
        },
        std::vector<bool>{
            true,  
            false, 
            false, 
            false, 
            true   
        }
    );
    NumberSetting mRange = NumberSetting("Радиус атаки", "Радиус атаки", 3, 0, 7, 0.01);
    NumberSetting mAPS = NumberSetting("Скорость ударов", "Скорость ударов", 1, 1, 20, 0.1);

    BoolSetting mCritOnly = BoolSetting("Бить только критами", "Бить только критами", false);
    BoolSetting mAttackThroughWalls = BoolSetting("Бить через стены", "Бить через стены", true);
    BoolSetting mWeaponOnly = BoolSetting("Только с оружием", "Атаковать только с мечом или трезубцем в руке", false);
    BoolSetting mHoldSpace = BoolSetting("Только с пробелом", "Атаковать только при зажатом пробеле", false);
    BoolSetting mTPSSync = BoolSetting("Синхронизация с ТПС", "Синхронизация позиций с сервером", false);
    BoolSetting mTargetLock = BoolSetting("Бить только одну цель", "Бить только одну цель", false);
    BoolSetting mDisableOnDimensionChange = BoolSetting("Авто отключение", "Авто отключение", true);

    MultiEnumSetting mDontAttackWhen = MultiEnumSetting(
        "Не бить если",
        "Условия, при которых не атаковать",
         std::vector<std::string>{
            "Открыт контейнер",
            "Используешь еду"
        }
    );

    BoolSetting mBacktrackOnly = BoolSetting("Бить только по Backtrack", "Атака только через backtrack-позиции (требует включенный Backtrack)", false);

    Aura() : ModuleBase("AttackAura", "Аура атаки", ModuleCategory::Combat, 0, false) {
        addSettings(
            &mTargetingType,
            &mTargetPriority,
            &mTargetFilters,
            &mDontAttackWhen,
            &mRange,
            &mAPS,
            &mCritOnly,
            &mAttackThroughWalls,
            &mWeaponOnly,
            &mHoldSpace,
            &mTPSSync,
            &mTargetLock,
            &mDisableOnDimensionChange,
            &mBacktrackOnly
        );

        mNames = {
            {Lowercase, "attack aura"},
            {LowercaseSpaced, "attackaura"},
            {Normal, "AttackAura"},
            {NormalSpaced, "Attack Aura"}
        };
    }

    AABB mTargetedAABB = AABB();
    bool mRotating = false;
    static inline bool sHasTarget = false;
    static inline Actor* sTarget = nullptr;
    static inline int64_t sTargetRuntimeID = 0;
    int64_t mLastSwing = 0;
    bool mCritHitPerformed = false; 

    int getSword(Actor* target);
    void onEnable() override;
    void onDisable() override;
    void rotate(Actor* target);
    void onRenderEvent(class RenderEvent& event);
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onBobHurtEvent(class BobHurtEvent& event);
    void onBoneRenderEvent(class BoneRenderEvent& event);
    Actor* findObstructingActor(Actor* player, Actor* target);

    Actor* mLockedTarget = nullptr;

private:
    AABB getSyncedAABB(Actor* actor) const;
    float getSyncedDistance(Actor* player, Actor* target) const;
};
