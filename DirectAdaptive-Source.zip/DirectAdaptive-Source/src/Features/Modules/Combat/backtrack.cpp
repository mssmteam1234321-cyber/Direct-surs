#include "backtrack.hpp"

#include <Features/FeatureManager.hpp>
#include <Features/Modules/Misc/Friends.hpp>

#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/World/Level.hpp>
#include <SDK/Minecraft/World/HitResult.hpp>
#include <SDK/Minecraft/Inventory/PlayerInventory.hpp>
#include <SDK/Minecraft/Network/Packets/InventoryTransactionPacket.hpp>

#include <Utils/GameUtils/ActorUtils.hpp>
#include <Utils/MiscUtils/MathUtils.hpp>
#include <Utils/MiscUtils/RenderUtils.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>

#include <imgui.h>

static constexpr uint64_t kBacktrackSampleStepMs         = 50;   
static constexpr uint64_t kBacktrackHistoryExtraMs       = 50;   
static constexpr size_t   kBacktrackMaxRecordsPerPlayer  = 12;   

void Backtrack::onEnable()
{
    gFeatureManager->mDispatcher->listen<BaseTickEvent, &Backtrack::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketOutEvent, &Backtrack::onPacketOutEvent>(this);
    gFeatureManager->mDispatcher->listen<RenderEvent, &Backtrack::onRenderEvent>(this);

    std::scoped_lock lock(mMutex);
    mHistory.clear();
    mLastSampleTime = 0;
}

void Backtrack::onDisable()
{
    gFeatureManager->mDispatcher->deafen<BaseTickEvent, &Backtrack::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketOutEvent, &Backtrack::onPacketOutEvent>(this);
    gFeatureManager->mDispatcher->deafen<RenderEvent, &Backtrack::onRenderEvent>(this);

    std::scoped_lock lock(mMutex);
    mHistory.clear();
}

void Backtrack::onBaseTickEvent(BaseTickEvent& event)
{
    auto player = event.mActor;
    if (!player || !player->isValid()) return;

    uint64_t now = NOW;

    if (mLastSampleTime && now - mLastSampleTime < kBacktrackSampleStepMs)
        return;

    mLastSampleTime = now;

    sampleActors(player);
    purgeOld(now);
}

void Backtrack::sampleActors(Actor* local)
{
    auto actors = ActorUtils::getActorList(true, true);
    if (actors.empty()) return;

    auto friends = gFriendManager;

    std::scoped_lock lock(mMutex);

    for (auto actor : actors)
    {
        if (!actor || !actor->isValid()) continue;
        if (actor == local) continue;
        if (friends && friends->mEnabled && friends->isFriend(actor)) continue;

        auto uid = actor->getActorUniqueIDComponent();
        if (!uid) continue;

        int64_t id = uid->mUniqueID;

        AABB box = actor->getAABB();
        glm::vec3 pos = *actor->getPos();

        Record rec{ pos, box, NOW };

        auto& hist = mHistory[id];
        hist.emplace_back(rec);

        while (hist.size() > kBacktrackMaxRecordsPerPlayer)
            hist.pop_front();
    }
}

void Backtrack::purgeOld(uint64_t now)
{
    uint64_t window = static_cast<uint64_t>(mBacktrackMs.mValue) + kBacktrackHistoryExtraMs;

    std::scoped_lock lock(mMutex);

    for (auto it = mHistory.begin(); it != mHistory.end();)
    {
        auto& hist = it->second;
        while (!hist.empty() && now - hist.front().mTime > window)
            hist.pop_front();

        if (hist.empty())
            it = mHistory.erase(it);
        else
            ++it;
    }
}

bool Backtrack::getBestRecord(Actor* local, Actor* target, Record& outRecord)
{
    if (!local || !target) return false;

    auto uid = target->getActorUniqueIDComponent();
    if (!uid) return false;

    int64_t id = uid->mUniqueID;

    std::scoped_lock lock(mMutex);

    auto it = mHistory.find(id);
    if (it == mHistory.end()) return false;

    auto& hist = it->second;
    if (hist.empty()) return false;

    uint64_t now = NOW;
    uint64_t desiredDelta = static_cast<uint64_t>(mBacktrackMs.mValue);
    uint64_t window       = desiredDelta + kBacktrackHistoryExtraMs;

    Record* best = nullptr;
    uint64_t bestDiff = (uint64_t)-1;

    for (auto& rec : hist)
    {
        uint64_t age = now - rec.mTime;
        if (age > window) continue;

        uint64_t diff = (desiredDelta > age) ? (desiredDelta - age) : (age - desiredDelta);
        if (diff < bestDiff)
        {
            bestDiff = diff;
            best = &rec;
        }
    }

    if (!best) return false;

    outRecord = *best;
    return true;
}

void Backtrack::onPacketOutEvent(PacketOutEvent& event)
{
    if (!mEnabled) return;

    if (event.mPacket->getId() != PacketID::InventoryTransaction)
        return;

    auto pkt = event.getPacket<InventoryTransactionPacket>();
    if (!pkt || !pkt->mTransaction) return;

    auto cit = pkt->mTransaction.get();
    if (cit->type != ComplexInventoryTransaction::Type::ItemUseOnEntityTransaction)
        return;

    auto iut = reinterpret_cast<ItemUseOnActorInventoryTransaction*>(cit);
    if (iut->mActionType != ItemUseOnActorInventoryTransaction::ActionType::Attack)
        return;

    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player || !player->isValid()) return;

    Actor* target = ActorUtils::getActorFromUniqueId(iut->mActorId);
    if (!target || !target->isValid()) return;

    Record rec{};
    if (!getBestRecord(player, target, rec))
        return;

    
    iut->mClickPos = rec.mPos;
    iut->mPlayerPos = *player->getPos();
}

void Backtrack::onRenderEvent(RenderEvent&)
{
    if (!mEnabled || !mRender.mValue)
        return;

    auto ci = ClientInstance::get();
    auto player = ci ? ci->getLocalPlayer() : nullptr;
    if (!player || !player->isValid()) return;

    uint64_t now = NOW;
    uint64_t desiredDelta = static_cast<uint64_t>(mBacktrackMs.mValue);
    uint64_t window = desiredDelta + kBacktrackHistoryExtraMs;

    std::scoped_lock lock(mMutex);

    for (auto& [id, hist] : mHistory)
    {
        if (hist.empty())
            continue;

        Record* best = nullptr;
        uint64_t bestDiff = (uint64_t)-1;

        for (auto& rec : hist)
        {
            uint64_t age = now - rec.mTime;
            if (age > window) continue;

            uint64_t diff = (desiredDelta > age) ? (desiredDelta - age) : (age - desiredDelta);
            if (diff < bestDiff)
            {
                bestDiff = diff;
                best = &rec;
            }
        }

        if (!best)
            continue;

        uint64_t age = now - best->mTime;
        float t = 1.0f - (static_cast<float>(age) / static_cast<float>(window));
        t = MathUtils::clamp(t, 0.0f, 1.0f);

        ImColor col = ColorUtils::getThemedColor(static_cast<float>(id & 0xFF));
        col.Value.w *= t;

        RenderUtils::drawOutlinedAABB(best->mBox, false, col);
    }
}

