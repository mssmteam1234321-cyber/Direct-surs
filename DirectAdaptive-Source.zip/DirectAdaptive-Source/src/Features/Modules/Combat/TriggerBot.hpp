#pragma once




#include <Features/Modules/Setting.hpp>
#include <Features/Modules/Module.hpp>
#include <SDK/Minecraft/Actor/EntityId.hpp>

class TriggerBot : public ModuleBase<TriggerBot>
{
public:
    NumberSetting mAPSMin = NumberSetting("Мин. APS", "Минимальное кол-во ударов в секунду", 12, 1, 20, 1);
    NumberSetting mAPSMax = NumberSetting("Макс. APS", "Максимальное кол-во ударов в секунду", 16, 1, 20, 1);
    BoolSetting mUseAntibot = BoolSetting("Антибот", "Использовать Antibot для фильтрации целей", true);
    BoolSetting mHive = BoolSetting("Hive", "Попытаться обойти античит Hive", true);

    TriggerBot() : ModuleBase<TriggerBot>("TriggerBot", "Automatically attacks the entity that you're aiming at", ModuleCategory::Combat, 0, false) {
        mNames = {
                {Lowercase, "triggerbot"},
                {LowercaseSpaced, "trigger bot"},
                {Normal, "TriggerBot"},
                {NormalSpaced, "Trigger Bot"}
        };

        addSettings(&mAPSMin, &mAPSMax, &mUseAntibot, &mHive);
    }
    Actor* getActorFromEntityId(EntityId entityId);
    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
};