﻿#pragma once

#include "src/Features/Modules/Module.hpp"

class ItemDelayFix : public ModuleBase<ItemDelayFix> {
public:
    ItemDelayFix();

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);

private:
    uint64_t mLastManualSwitch = 0;
    int mLastSelectedSlot = -1;
    bool mWasSwitchedManually = false;
    int mDelayTime = 500;
    
    
    int mAuraSpoofedSlot = -1;
    int mSlotBeforeAuraSpoof = -1;
    uint64_t mAuraSpoofTime = 0;
    bool mIsAuraSpoofing = false;
};