﻿
#pragma once
#include "Features/Modules/Module.hpp"

class AirAura : public ModuleBase<AirAura> {
public:
    NumberSetting mRange = NumberSetting("Дистанция", "Дистанция обнаружения целей", 50.0f, 5.0f, 100.0f, 1.0f);
    NumberSetting mHorizontal = NumberSetting("Горизонталь", "Скорость следования по горизонтали", 8.0f, 1.0f, 20.0f, 0.5f);
    NumberSetting mVertical = NumberSetting("Вертикаль", "Скорость следования по вертикали", 5.0f, 1.0f, 15.0f, 0.5f);
    NumberSetting mHeight = NumberSetting("Высота", "Высота над целью", 2.5f, 1.0f, 10.0f, 0.5f);
    BoolSetting mOnElytra = BoolSetting("On Elytra", "Only work when using elytra", false);

    AirAura();

    void onEnable() override;
    void onDisable() override;

    void onBaseTickEvent(class BaseTickEvent& event);

private:
    bool mShouldFollow = false;
    class Actor* mCurrentTarget = nullptr;

    void handleAirMovement(class Actor* player, class Actor* target);
    void findTarget(class Actor* player);
};