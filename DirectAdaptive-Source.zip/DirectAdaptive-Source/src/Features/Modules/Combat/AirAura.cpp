﻿
#include "AirAura.hpp"
#include "Features/FeatureManager.hpp"
#include "Features/Events/BaseTickEvent.hpp"
#include "SDK/Minecraft/ClientInstance.hpp"
#include "SDK/Minecraft/Actor/Actor.hpp"
#include "SDK/Minecraft/Actor/Components/StateVectorComponent.hpp"
#include "SDK/Minecraft/Actor/Components/ActorRotationComponent.hpp"
#include "Utils/GameUtils/ActorUtils.hpp"
#include "Utils/MiscUtils/MathUtils.hpp"

AirAura::AirAura()
    : ModuleBase("AirAura", "Летает над игроками и следует за ними", ModuleCategory::Movement, 0, false) {

    addSettings(
        &mRange,
        &mHorizontal,
        &mVertical,
        &mHeight,
        &mOnElytra
    );

    mNames = {
        {Lowercase, "airaura"},
        {LowercaseSpaced, "air aura"},
        {Normal, "AirAura"},
        {NormalSpaced, "Air Aura"}
    };
}

void AirAura::onEnable() {
    if (gFeatureManager) {
        gFeatureManager->mDispatcher->listen<BaseTickEvent, &AirAura::onBaseTickEvent>(this);
    }
}

void AirAura::onDisable() {
    if (gFeatureManager) {
        gFeatureManager->mDispatcher->deafen<BaseTickEvent, &AirAura::onBaseTickEvent>(this);
    }

    mShouldFollow = false;
    mCurrentTarget = nullptr;
}

void AirAura::onBaseTickEvent(BaseTickEvent& event) {
    auto player = event.mActor;
    if (!player) return;

    
    if (mOnElytra.mValue) {
        
        
        mShouldFollow = false;
        mCurrentTarget = nullptr;
        return;
    }

    findTarget(player);

    if (mCurrentTarget && mShouldFollow) {
        handleAirMovement(player, mCurrentTarget);
    }
}

void AirAura::findTarget(Actor* player) {
    auto actors = ActorUtils::getActorList(false, true);
    Actor* closestTarget = nullptr;
    float closestDistance = mRange.mValue;

    for (auto actor : actors) {
        if (!actor || actor == player || !actor->isPlayer()) continue;

        float distance = actor->distanceTo(player);
        if (distance < closestDistance && distance > 0) {
            closestTarget = actor;
            closestDistance = distance;
        }
    }

    mCurrentTarget = closestTarget;
    mShouldFollow = (closestTarget != nullptr);
}

void AirAura::handleAirMovement(Actor* player, Actor* target) {
    if (!player || !target) return;

    glm::vec3 playerPos = *player->getPos();
    glm::vec3 targetPos = *target->getPos();

    
    glm::vec3 targetPosition = glm::vec3(
        targetPos.x,
        targetPos.y + mHeight.mValue, 
        targetPos.z
    );

    
    glm::vec3 direction = targetPosition - playerPos;
    float distance = glm::length(direction);

    if (distance > 0.5f) {
        
        direction = glm::normalize(direction);

        
        if (auto state = player->getStateVectorComponent()) {
            
            float horizontalSpeed = mHorizontal.mValue / 10.0f;
            state->mVelocity.x = direction.x * horizontalSpeed;
            state->mVelocity.z = direction.z * horizontalSpeed;

            
            float verticalSpeed = mVertical.mValue / 10.0f;
            state->mVelocity.y = direction.y * verticalSpeed;
        }
    }
    else {
        
        if (auto state = player->getStateVectorComponent()) {
            state->mVelocity.x = 0;
            state->mVelocity.z = 0;
            state->mVelocity.y = 0.02f; 
        }
    }

    
    glm::vec2 rots = MathUtils::getRots(playerPos, target->getAABB());
    if (auto rot = player->getActorRotationComponent()) {
        rot->mPitch = rots.x;
        rot->mYaw = rots.y;
        rot->mOldPitch = rots.x;
        rot->mOldYaw = rots.y;
    }
}