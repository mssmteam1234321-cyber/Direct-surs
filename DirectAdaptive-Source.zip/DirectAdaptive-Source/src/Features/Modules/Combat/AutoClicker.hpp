#pragma once




#include <Features/Modules/Setting.hpp>
#include <Features/Modules/Module.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>

class AutoClicker : public ModuleBase<AutoClicker>
{
public:
    enum class ClickMode
    {
        Left,
        Right,
        Both
    };

    EnumSettingT<ClickMode> mClickMode = EnumSettingT<ClickMode>("Режим", "Режим кликера", ClickMode::Left, "Левая", "Правая", "Обе");
    BoolSetting mHold = BoolSetting("Удержание", "Кликать только при удержании", false);
    BoolSetting mRandomizeCPS = BoolSetting("Рандом CPS", "Рандомизировать CPS", false);
    BoolSetting mWeaponsOnly = BoolSetting("Только оружие", "Кликать только с оружием в руках", false);
    NumberSetting mCPS = NumberSetting("КПС", "Количество кликов в секунду (CPS).", 16, 1, 60, 1);
    NumberSetting mRandomCPSMin = NumberSetting("Мин. CPS", "Минимальное кол-во кликов в секунду.", 10, 1, 60, 1);
    NumberSetting mRandomCPSMax = NumberSetting("Макс. CPS", "Максимальное кол-во кликов в секунду.", 20, 1, 60, 1);
    BoolSetting mAllowBlockBreaking = BoolSetting("Ломать блоки", "Разрешить ломать блоки", false);

    AutoClicker() : ModuleBase<AutoClicker>("AutoClicker", "Автоматически кликает за вас", ModuleCategory::Combat, 0, false) {
        addSettings(
            &mClickMode,
            &mRandomizeCPS,
            &mCPS,
            &mRandomCPSMin,
            &mRandomCPSMax,
            &mHold,
            &mWeaponsOnly,
            &mAllowBlockBreaking
        );

        VISIBILITY_CONDITION(mCPS, !mRandomizeCPS.mValue);
        VISIBILITY_CONDITION(mRandomCPSMin, mRandomizeCPS.mValue);
        VISIBILITY_CONDITION(mRandomCPSMax, mRandomizeCPS.mValue);
        VISIBILITY_CONDITION(mAllowBlockBreaking, mClickMode.mValue == ClickMode::Left);

        mNames = {
                {Lowercase, "autoclicker"},
                {LowercaseSpaced, "auto clicker"},
                {Normal, "AutoClicker"},
                {NormalSpaced, "Auto Clicker"}
        };
    }

    int mCurrentCPS = 10;

    void randomizeCPS()
    {
        mCurrentCPS = getCPS();
    }

    int getCPS()
    {
        if (mRandomizeCPS.mValue)
        {
            return MathUtils::random(mRandomCPSMin.as<int>(), mRandomCPSMax.as<int>());
        }

        return mCPS.mValue;
    }

    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(class RenderEvent& event);
};