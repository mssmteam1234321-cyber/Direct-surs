#pragma once




#include <Features/Modules/Module.hpp>

class Derp : public ModuleBase<Derp>
{
public:
    enum class Mode
    {
        None,
        Spin,
        Random,
        Headroll
    };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим работы модуля", Mode::None, "Нет", "Вращение", "Рандом", "Голова");
    NumberSetting mSpeed = NumberSetting("Скорость", "Скорость вращения", 1.0f, 0.1f, 10.0f, 0.01f);
    BoolSetting mHeadYawDesync = BoolSetting("Рассинхрон головы", "Включить рассинхронизацию поворота головы", false);
    BoolSetting mHeadYawFlip = BoolSetting("Отражение головы", "Отражать поворот головы", false);
    NumberSetting mFlipTick = NumberSetting("Тики отражения", "Тик, на котором происходит отражение головы", 20.0f, 1.0f, 20.0f, 1.0f);

    Derp() : ModuleBase("Derp", "Заставляет вас крутиться как дерп", ModuleCategory::Player, 0, false)
    {
        addSettings(&mMode, &mSpeed, &mHeadYawDesync, &mHeadYawFlip, &mFlipTick);

        VISIBILITY_CONDITION(mSpeed, mMode.mValue != Mode::None);
        VISIBILITY_CONDITION(mHeadYawFlip, mHeadYawDesync.mValue);
        VISIBILITY_CONDITION(mFlipTick, mHeadYawFlip.mValue && mHeadYawDesync.mValue);

        mNames = {
            {Lowercase, "derp"},
            {LowercaseSpaced, "derp"},
            {Normal, "Derp"},
            {NormalSpaced, "Derp"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
    void onPacketOutEvent2(class PacketOutEvent& event);
};