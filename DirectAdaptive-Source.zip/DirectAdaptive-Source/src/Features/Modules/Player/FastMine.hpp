#pragma once




#include <Features/Modules/Module.hpp>

class FastMine : public ModuleBase<FastMine> {
public:
    enum class Mode 
    {
        Hive,
        BDS,
        
    };

    EnumSettingT<Mode> mMode = EnumSettingT("Режим", "Режим быстрого майнинга", Mode::Hive, "Hive", "BDS");
    NumberSetting mDestroySpeed = NumberSetting("Скорость разрушения", "Скорость разрушения для быстрого майнинга", 1, 0.01, 1, 0.01);
    BoolSetting mInfiniteDurability = BoolSetting("Бесконечная прочность", "Бесконечная прочность для инструментов (может вызвать проблемы!)", false);
    FastMine() : ModuleBase("FastMine", "Увеличивает скорость майнинга", ModuleCategory::Player, 0, false)
    {
        addSettings(&mMode, &mDestroySpeed, &mInfiniteDurability);

        VISIBILITY_CONDITION(mInfiniteDurability, mMode.mValue == Mode::Hive);

        mNames = {
              {Lowercase, "fastmine"},
                {LowercaseSpaced, "fast mine"},
                {Normal, "FastMine"},
                {NormalSpaced, "Fast Mine"}
        };
    };

    void onEnable();
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
};