#pragma once

class FastUse : public ModuleBase<FastUse> {
public:
    NumberSetting mUseRate = NumberSetting("Скорость", "Использований в секунду", 12.f, 1.f, 40.f, 1.f);
    NumberSetting mUseAmount = NumberSetting("Берст", "Использований за тик", 2.f, 1.f, 10.f, 1.f);
    BoolSetting mHoldRMB = BoolSetting("Удержание ПКМ", "Работать только при удержании правой кнопки мыши", true);

    FastUse() : ModuleBase("FastUse", "Позволяет использовать предметы быстрее", ModuleCategory::Player, 0, false)
    {
        addSettings(&mUseRate, &mUseAmount, &mHoldRMB);

        mNames = {
            {Lowercase, "fastuse"},
            {LowercaseSpaced, "fast use"},
            {Normal, "FastUse"},
            {NormalSpaced, "Fast Use"}
        };
    };

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);

private:
    uint64_t mLastUse = 0;
};

