#pragma once
#include <Features/Modules/Module.hpp>

class Regen : public ModuleBase<Regen>
{
public:
    enum class Mode {
        Hive,
    };
    enum class CalcMode {
        Minecraft,
#ifdef __PRIVATE_BUILD__
        Test 
#endif
    };
    enum class UncoverMode {
        Normal,
        Fast 
    };
    enum class StealPriority {
        Mine,
        Steal
    };
    enum class ConfuseMode {
        Always,
        Auto
    };
    enum class AntiConfuseMode {
        RedstoneCheck,
        ExposedCheck
    };
    enum class OreSelectionMode {
        Normal,
        Closest
    };
    enum class ProgressBarStyle
    {
        Old,
        New
    };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим Regen", Mode::Hive, "Hive");
    EnumSettingT<CalcMode> mCalcMode = EnumSettingT<CalcMode>("Режим расчета", "Режим расчета скорости разрушения", CalcMode::Minecraft, "Minecraft"
#ifdef __PRIVATE_BUILD__
     ,"Fast"
#endif
                                                              );
    NumberSetting mRange = NumberSetting("Дистанция", "Максимальная дистанция для разрушения", 5, 0, 10, 0.01);
    NumberSetting mDestroySpeed = NumberSetting("Скорость разрушения", "Скорость разрушения для Regen", 1, 0.01, 1, 0.01);
    NumberSetting mOtherDestroySpeed = NumberSetting("Другая скорость", "Другая скорость разрушения для Regen", 1, 0.01, 1, 0.01);
    BoolSetting mSwing = BoolSetting("Взмах", "Махать рукой при разрушении блоков", false);
    BoolSetting mHotbarOnly = BoolSetting("Только хотбар", "Использовать только инструменты из хотбара", false);
    BoolSetting mUncover = BoolSetting("Раскрытие", "Раскрывать редстоун, если ничего вокруг не открыто", false);
    EnumSettingT<UncoverMode> mUncoverMode = EnumSettingT<UncoverMode>("Режим раскрытия", "Режим раскрытия", UncoverMode::Normal, "Normal"
#ifdef __PRIVATE_BUILD__
    ,"Fast"
#endif
    );
#ifdef __PRIVATE_BUILD__
    NumberSetting mUncoverRange = NumberSetting("Дистанция раскрытия", "Максимальная дистанция раскрытия блоков", 3, 1, 8, 1);
#else
    NumberSetting mUncoverRange = NumberSetting("Дистанция раскрытия", "Максимальная дистанция раскрытия блоков", 3, 1, 3, 1);
#endif
    BoolSetting mQueueRedstone = BoolSetting("Очередь редстоуна", "Добавить редстоун в очередь на разрушение при макс. поглощении", false);
    BoolSetting mSteal = BoolSetting("Кража", "Красть руду врага", false);
    NumberSetting mStealerTimeout = NumberSetting("Таймаут кражи", "Максимальная длительность кражи", 1500, 500, 5000, 250);
    EnumSettingT<StealPriority> mStealPriority = EnumSettingT<StealPriority>("Приоритет кражи", "Приоритет кражи руды", StealPriority::Mine, "Добыча", "Кража");
    BoolSetting mAlwaysSteal = BoolSetting("Всегда красть", "Красть руду врага при достижении макс. поглощения", false);
    BoolSetting mDelayedSteal = BoolSetting("Задержка кражи", "Добавить задержку при краже", false);
    NumberSetting mOpponentDestroySpeed = NumberSetting("Скорость противника", "Указать скорость разрушения противника", 1, 0.01, 1, 0.01);
    BoolSetting mAntiSteal = BoolSetting("Анти-кража", "Прекратить майнинг, если враг пытается украсть руду", false);
    BoolSetting mConfuse = BoolSetting("Запутать", "Запутать вора", false);
    BoolSetting mConfuse2 = BoolSetting("Запутать 2", "Запутать вора", false);
    EnumSettingT<ConfuseMode> mConfuseMode = EnumSettingT<ConfuseMode>("Режим путаницы", "Режим для запутывания", ConfuseMode::Always, "Всегда", "Авто");
    NumberSetting mConfuseDuration = NumberSetting("Длительность путаницы", "Время запутывания", 3000, 1000, 10000, 500);
    BoolSetting mAntiConfuse = BoolSetting("Анти-путаница", "Игнорировать запутанные блоки из-за ложной кражи", false);
    EnumSettingT<AntiConfuseMode> mAntiConfuseMode = EnumSettingT<AntiConfuseMode>("Режим анти-путаницы", "Режим анти-путаницы", AntiConfuseMode::RedstoneCheck, "Redstone"
#ifdef __PRIVATE_BUILD__
        ,"Exposed"
#endif
        );
    BoolSetting mBlockOre = BoolSetting("Блокировать руду", "Закрывать руду, которую ломает противник", false);
    NumberSetting mBlockRange = NumberSetting("Дистанция блока", "Максимальная дистанция для блокировщика руды", 5, 0, 10, 0.01);
    BoolSetting mMulti = BoolSetting("Мульти", "Разрешить установку нескольких блоков", false);
    BoolSetting mAntiCover = BoolSetting("Анти-покрытие", "Продолжать майнинг, даже если руда закрыта", false);
    NumberSetting mCompensation = NumberSetting("Компенсация", "Минимальный процент прогресса разрушения для продолжения майнинга", 1, 0.01, 1, 0.01);
    BoolSetting mInfiniteDurability = BoolSetting("Бесконечная прочность", "Бесконечная прочность для инструментов (может вызвать проблемы!)", false);
    EnumSettingT<OreSelectionMode> mOreSelectionMode = EnumSettingT<OreSelectionMode>("Выбор руды", "Режим выбора руды", OreSelectionMode::Normal, "Обычный", "Ближайший");
    BoolSetting mDynamicDestroySpeed = BoolSetting("Динамич. скорость", "Использовать быструю скорость для указанного блока", false);
    BoolSetting mOnGroundOnly = BoolSetting("Только на земле", "Использовать динамическую скорость только на земле", false);
    BoolSetting mNuke = BoolSetting("Нюкер", "Разрушать блок мгновенно", false);
    BoolSetting mAlwaysMine = BoolSetting("Всегда майнить", "Продолжать майнить руду", false);
    BoolSetting mDebug = BoolSetting("Отладка", "Отправлять отладочные сообщения в чат", false);
    BoolSetting mConfuseNotify = BoolSetting("Увед. о путанице", "Сообщать в чат, когда вор запутан", true);
    BoolSetting mBlockNotify = BoolSetting("Увед. о блоке", "Сообщать в чат, когда вы заблокировали руду/руда была закрыта", true);
    BoolSetting mFastOreNotify = BoolSetting("Увед. о быстрой руде", "Сообщать в чат, когда найдена быстрая руда", true);
    BoolSetting mSyncSpeedNotify = BoolSetting("Увед. о синхр. скорости", "Сообщать в чат, когда блок сломан быстрее", true);
    BoolSetting mNukeNotify = BoolSetting("Увед. о Nuke", "Сообщать в чат при уничтожении блока Nuke", true);
    BoolSetting mStealNotify = BoolSetting("Увед. о краже", "Сообщать в чат, когда вы украли руду / вашу руду украли", true);
    BoolSetting mDynamicUncoverNotify = BoolSetting("Увед. о динам. раскрытии", "Инфо о динамическом раскрытии", true);
    BoolSetting mRaperNotify = BoolSetting("Уведомление Raper", "Отправлять сообщение в чат при атаке", true);
    BoolSetting mStealerDetectorNotify = BoolSetting("Увед. детектора вора", "Send message in chat when u raping enemy", true);
    BoolSetting mRenderBlock = BoolSetting("Рендер блока", "Рендерить блок, который вы ломаете", true);
    EnumSettingT<ProgressBarStyle> mProgressBarStyle = EnumSettingT<ProgressBarStyle>("Стиль прогрессбара", "Режим отображения прогресса", ProgressBarStyle::New, "Старый", "Новый");
    NumberSetting mOffset = NumberSetting("Отступ от центра", "Отступ позиции рендера от центра", 20, 0, 200, 0.1);
    BoolSetting mRenderProgressBar = BoolSetting("Рендер прогрессбара", "Рендерить прогрессбар", true);
    BoolSetting mOreFaker = BoolSetting("Фейк руды", "Подменяет целевую руду", false);
    BoolSetting mExposed = BoolSetting("Открытые", "Включать открытую руду", false);
    BoolSetting mUnexposed = BoolSetting("Закрытые", "Включать закрытую руду", false);
    BoolSetting mCovering = BoolSetting("Триггер кражи", "Включать закрывающий блок", false);
    BoolSetting mRenderFakeOre = BoolSetting("Рендер фейк руды", "Рендерить руду, которую вы фейкуете", false);
    BoolSetting mReplace = BoolSetting("Кикер", "Кикает других хакеров на hvh", false);
    BoolSetting mChecker = BoolSetting("Проверка", "Проверяет успешность замены блока", false);
    BoolSetting mDynamicUncover = BoolSetting("Динамич. раскрытие", "Отключает раскрытие, если враг раскрывает руды", false);
    NumberSetting mDisableDuration = NumberSetting("Длительность откл.", "Время динамического отключения раскрытия", 3, 1, 10, 1);
    BoolSetting mNoUncoverWhileStealing = BoolSetting("Не раскрывать при краже", "Отключает раскрытие на 5 сек при краже руды", false);
    BoolSetting mStealerDetecter = BoolSetting("Детектор вора", "Делает приколы, если обнаружен вор :>", false);
    NumberSetting mAmountOfBlocksToDetect = NumberSetting("Блоков для детекта", "Количество украденных блоков за 5 сек для детекта", 4, 1, 10, 1);
    BoolSetting mDisableUncover = BoolSetting("Отключить раскрытие", "Отключает раскрытие на несколько секунд", false);
    NumberSetting mDisableSeconds = NumberSetting("Длительность откл. 2", "Количество секунд отключения раскрытия", 5, 1, 15, 1);
    BoolSetting mEnableAntiSteal = BoolSetting("Вкл Анти-Вор", "Включает анти-вор, отключает, если враг не крал 5 сек", false);
    BoolSetting mAvoidEnemyOre = BoolSetting("Избегать руду врага", "Избегать руду, которую ломает враг", false);

    Regen() : ModuleBase("Regen", "Автоматически ломает редстоун", ModuleCategory::Player, 0, false) {
        addSettings(
            &mProgressBarStyle,
            &mOffset,
            &mRenderProgressBar,
            &mRenderBlock,
            &mMode,
            &mCalcMode,
            &mRange,
            &mDestroySpeed,
            &mOtherDestroySpeed,
            &mSwing,
            &mHotbarOnly,
            &mUncover,
            &mUncoverMode,
            &mUncoverRange,
            &mQueueRedstone,
#ifdef __PRIVATE_BUILD__
            &mSteal,
            &mStealerTimeout,
            &mStealPriority,
            &mAlwaysSteal,
            &mDelayedSteal,
            &mOpponentDestroySpeed,
#endif
#ifdef __DEBUG__
            &mReplace,
#endif
#ifdef __PRIVATE_BUILD__
            &mAntiSteal,
            &mConfuse,
            &mConfuse2,
            &mConfuseMode,
            &mConfuseDuration,
            &mAntiConfuse,
            &mAntiConfuseMode,
            &mBlockOre,
            &mBlockRange,
            &mMulti,
            &mAntiCover,
            &mCompensation,
#endif
#ifdef __DEBUG__
            &mAvoidEnemyOre,
#endif
            &mInfiniteDurability,
            &mOreSelectionMode,
#ifdef __PRIVATE_BUILD__
            &mDynamicDestroySpeed,
            &mOnGroundOnly,
            &mNuke,
#endif
            &mAlwaysMine,
            &mDebug,
#ifdef __PRIVATE_BUILD__
            &mDynamicUncoverNotify,
            &mStealerDetectorNotify,
#endif
#ifdef __DEBUG__
            &mRaperNotify,
#endif
#ifdef __PRIVATE_BUILD__
            &mConfuseNotify,
            &mBlockNotify,
            &mSyncSpeedNotify,
            &mNukeNotify,
            &mStealNotify,
#endif
            &mFastOreNotify
        );

#ifdef __DEBUG__
        VISIBILITY_CONDITION(mReplace, mSteal.mValue);
#endif

#ifdef __PRIVATE_BUILD__
        addSetting(&mOreFaker);
        addSettings(&mExposed, &mUnexposed);
#endif

#ifdef __DEBUG__
        addSetting(&mCovering);
        VISIBILITY_CONDITION(mCovering, mOreFaker.mValue);
#endif
        
#ifdef __PRIVATE_BUILD__
        addSetting(&mRenderFakeOre);
        VISIBILITY_CONDITION(mExposed, mOreFaker.mValue);
        VISIBILITY_CONDITION(mUnexposed, mOreFaker.mValue);
        VISIBILITY_CONDITION(mRenderFakeOre, mOreFaker.mValue);
        addSetting(&mNoUncoverWhileStealing);
        addSettings(&mDynamicUncover, &mDisableDuration);
        VISIBILITY_CONDITION(mDynamicUncover, mUncover.mValue);
        VISIBILITY_CONDITION(mDisableDuration, mUncover.mValue && mDynamicUncover.mValue);
        addSettings(&mStealerDetecter, &mAmountOfBlocksToDetect);
        VISIBILITY_CONDITION(mAmountOfBlocksToDetect, mStealerDetecter.mValue);
        addSetting(&mDisableUncover);
        addSetting(&mDisableSeconds);
        addSetting(&mEnableAntiSteal);
        VISIBILITY_CONDITION(mDisableUncover, mStealerDetecter.mValue);
        VISIBILITY_CONDITION(mDisableSeconds, mDisableUncover.mValue && mStealerDetecter.mValue);
        VISIBILITY_CONDITION(mEnableAntiSteal, mStealerDetecter.mValue);

        VISIBILITY_CONDITION(mDelayedSteal, mSteal.mValue);
        VISIBILITY_CONDITION(mOpponentDestroySpeed, mSteal.mValue && mDelayedSteal.mValue);
#endif

        VISIBILITY_CONDITION(mDestroySpeed, mCalcMode.mValue == CalcMode::Minecraft);
        VISIBILITY_CONDITION(mOtherDestroySpeed, mCalcMode.mValue == CalcMode::Minecraft);

        VISIBILITY_CONDITION(mUncoverMode, mUncover.mValue);
        VISIBILITY_CONDITION(mUncoverRange, mUncover.mValue && mUncoverMode.mValue == UncoverMode::Normal);

#ifdef __PRIVATE_BUILD__
        VISIBILITY_CONDITION(mStealerTimeout, mSteal.mValue);
        VISIBILITY_CONDITION(mStealPriority, mSteal.mValue);
        VISIBILITY_CONDITION(mAlwaysSteal, mSteal.mValue);

        VISIBILITY_CONDITION(mConfuseMode, mConfuse.mValue || mConfuse2.mValue);
        VISIBILITY_CONDITION(mConfuseDuration, (mConfuse.mValue || mConfuse2.mValue) && mConfuseMode.mValue == ConfuseMode::Auto);

        VISIBILITY_CONDITION(mAntiConfuseMode, mAntiConfuse.mValue);

        VISIBILITY_CONDITION(mBlockRange, mBlockOre.mValue);
        VISIBILITY_CONDITION(mMulti, mBlockOre.mValue);

        VISIBILITY_CONDITION(mCompensation, mAntiCover.mValue);

        VISIBILITY_CONDITION(mOnGroundOnly, mDynamicDestroySpeed.mValue);
        VISIBILITY_CONDITION(mNuke, mDynamicDestroySpeed.mValue && mOnGroundOnly.mValue);
#endif
        
        VISIBILITY_CONDITION(mFastOreNotify, mDebug.mValue);

#ifdef __PRIVATE_BUILD__
        VISIBILITY_CONDITION(mConfuseNotify, mDebug.mValue);
        VISIBILITY_CONDITION(mBlockNotify, mDebug.mValue);
        VISIBILITY_CONDITION(mSyncSpeedNotify, mDebug.mValue);
        VISIBILITY_CONDITION(mStealNotify, mDebug.mValue);
        VISIBILITY_CONDITION(mNukeNotify, mDebug.mValue);
        VISIBILITY_CONDITION(mDynamicUncoverNotify, mDebug.mValue);
        VISIBILITY_CONDITION(mStealerDetectorNotify, mDebug.mValue);
#endif
#ifdef __PRIVATE_BUILD__
        VISIBILITY_CONDITION(mRaperNotify, mDebug.mValue);
#endif

        VISIBILITY_CONDITION(mOffset, mProgressBarStyle.mValue == ProgressBarStyle::New);

        mNames = {
            {Lowercase, "regen"},
            {LowercaseSpaced, "regen"},
            {Normal, "Regen"},
            {NormalSpaced, "Regen"}
        };

        gFeatureManager->mDispatcher->listen<RenderEvent, &Regen::onRenderEvent, nes::event_priority::LAST>(this);
    }

    bool stealEnabled = false;

    uint64_t lastStoleTime = 0;
    bool antiStealerEnabled = false;
    bool stealerDetected = false;
    int amountOfStolenBlocks = 0;
    uint64_t stealerDetectionStartTime = 0;
    bool startedStealerDetection = false;
    uint64_t uncoverDisabledTime = 0;
    bool uncoverEnabled = true;
    uint64_t lastStealerDetected = 0;

    struct PathFindingResult {
        glm::ivec3 blockPos;
        float time;
    };

    static inline glm::ivec3 mCurrentBlockPos = { INT_MAX, INT_MAX, INT_MAX };
    glm::ivec3 mTargettingBlockPos = { INT_MAX, INT_MAX, INT_MAX };
    glm::ivec3 mLastTargettingBlockPos = { INT_MAX, INT_MAX, INT_MAX };
    glm::ivec3 mEnemyTargettingBlockPos = { INT_MAX, INT_MAX, INT_MAX };
    glm::ivec3 mLastEnemyLayerBlockPos = { INT_MAX, INT_MAX, INT_MAX };
    bool mCanSteal = false;
    bool mIsStealing = false;
    bool mCurrentUncover = false;
    int mCurrentBlockFace = -1;
    float mBreakingProgress = 0.f;
    float mCurrentDestroySpeed = 1.f;
    static inline bool mIsMiningBlock = false;
    static inline bool mWasMiningBlock = false;
    bool mIsUncovering = false;
    bool mWasUncovering = false;
    float mLastTargettingBlockPosDestroySpeed = 1.f;
    int mLastToolSlot = 0;
    bool mIsConfuserActivated = false;
    glm::ivec3 mLastConfusedPos = { INT_MAX, INT_MAX, INT_MAX };
    bool mOffGround = false;

    bool mShouldRotate = false;
    bool mShouldRotateToPlacePos = false;
    bool mShouldSpoofSlot = false;
    bool mShouldSetbackSlot = false;
    glm::ivec3 mBlackListedOrePos = { INT_MAX, INT_MAX, INT_MAX };
    int mPreviousSlot = -1;
    int mToolSlot = -1;

    std::vector<glm::ivec3> miningRedstones;
    glm::ivec3 mCurrentPlacePos = { INT_MAX, INT_MAX, INT_MAX };

    uint64_t mLastBlockPlace = 0;
    uint64_t mLastStealerUpdate = 0;
    uint64_t mLastStealerDetected = 0;
    uint64_t mLastConfuse = 0;
    uint64_t mLastUncoverDetected = 0;
    uint64_t mLastReplaced = 0;
    int mLastPlacedBlockSlot = 0;

    
    bool mCanReplace = false;
    int mStartDestroyCount = 0;
    glm::ivec3 mLastReplacedPos = { INT_MAX, INT_MAX, INT_MAX };

    uint64_t mPing = 100;
    uint64_t mEventDelay = 0;

    std::vector<glm::ivec3> mFakePositions;
    
    std::vector<glm::ivec3> mLastBrokenOrePos;
    std::vector<glm::ivec3> mLastBrokenCoveringBlockPos;
    std::vector<glm::ivec3> mOreBlackList;

    std::vector<glm::ivec3> mOffsetList = {
        glm::ivec3(0, -1, 0),
        glm::ivec3(0, 1, 0),
        glm::ivec3(0, 0, -1),
        glm::ivec3(0, 0, 1),
        glm::ivec3(-1, 0, 0),
        glm::ivec3(1, 0, 0),
    };

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onRenderEvent(class RenderEvent& event);
    void renderProgressBar();
    void renderNewProgressBar();
    void renderBlock();
    void renderFakeOres();
    void onPacketOutEvent(class PacketOutEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onSendImmediateEvent(class SendImmediateEvent& event);
    void onPingUpdateEvent(class PingUpdateEvent& event);
    void initializeRegen();
    void resetSyncSpeed();
    void queueBlock(glm::ivec3 blockPos);
    bool isValidBlock(glm::ivec3 blockPos, bool redstoneOnly, bool exposedOnly, bool isStealing = false);
    bool isValidRedstone(glm::ivec3 blockPos);
    PathFindingResult getBestPathToBlock(glm::ivec3 blockPos);

    std::string getSettingDisplay() override {
        return mMode.mValues[mMode.as<int>()];
    }
};
