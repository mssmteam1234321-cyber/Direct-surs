#pragma once




#include <Features/Modules/Module.hpp>
#include <Features/Modules/Setting.hpp>

class Timer : public ModuleBase<Timer> {
public:
    NumberSetting mSpeed = NumberSetting("Скорость", "Скорость игры", 20.0f, 1.f, 60.0f, 0.01f);
    Timer() : ModuleBase("Timer", "Изменяет скорость игры (тиков)", ModuleCategory::Player, VK_F4, false) {
        addSetting(&mSpeed);

        mNames = {
            {Lowercase, "timer"},
            {LowercaseSpaced, "timer"},
            {Normal, "Timer"},
            {NormalSpaced, "Timer"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);

    std::string getSettingDisplay() override {
        
        return fmt::format("{:.1f}", mSpeed.mValue);
    }
};