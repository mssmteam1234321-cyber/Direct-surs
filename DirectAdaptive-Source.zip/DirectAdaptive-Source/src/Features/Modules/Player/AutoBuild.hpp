﻿#pragma once
#include "Features/Modules/Module.hpp"
#include "Utils/MiscUtils/BlockUtils.hpp"
#include "Utils/MiscUtils/MathUtils.hpp"

class AutoBuild : public ModuleBase<AutoBuild> {
public:
    enum class BuildMode {
        AutoBrewingStand,
        AutoFarm
    };

    NumberSetting mBuildRange = NumberSetting("Build Range", "The range at which to build structures", 10, 0, 50, 0.1);
    NumberSetting mBuildSpeed = NumberSetting("Build Speed", "The speed of building", 1, 0, 10, 0.1);
    EnumSettingT<BuildMode> mBuildMode = EnumSettingT<BuildMode>("Build Mode", "The structure to build", BuildMode::AutoBrewingStand, "Auto Brewing Stand", "Auto Farm");
    BoolSetting mAutoMove = BoolSetting("Auto Move", "Whether to automatically move to build positions", true);
    BoolSetting mJumpPlace = BoolSetting("Jump Place", "Whether to jump when placing high blocks", true);
    BoolSetting mAvoidObstacles = BoolSetting("Avoid Obstacles", "Whether to avoid obstacles while moving", true);
    BoolSetting mShowProgress = BoolSetting("Show Progress", "Whether to show building progress", true);

    AutoBuild() : ModuleBase("AutoBuild", "Автоматически строит структуры", ModuleCategory::Player, 0, false) {
        addSettings(
            &mBuildRange,
            &mBuildSpeed,
            &mBuildMode,
            &mAutoMove,
            &mJumpPlace,
            &mAvoidObstacles,
            &mShowProgress
        );

        mNames = {
            {Lowercase, "autobuild"},
            {LowercaseSpaced, "auto build"},
            {Normal, "AutoBuild"},
            {NormalSpaced, "Auto Build"}
        };

        gFeatureManager->mDispatcher->listen<RenderEvent, &AutoBuild::onRenderEvent>(this);
    }

private:
    bool mIsBuilding = false;
    glm::vec3 mStartPosition = glm::vec3(0, 0, 0);
    std::vector<glm::vec3> mBuildQueue;
    std::vector<std::string> mBlockQueue;
    std::vector<int> mFaceQueue; 
    size_t mCurrentBuildIndex = 0;
    uint64_t mLastBuildTime = 0;

    
    void setupBrewingStandLayout();

    
    bool moveToBuildPosition(class Actor* player, const glm::vec3& target);
    bool canReachPosition(class Actor* player, const glm::vec3& pos);
    void handleObstacleAvoidance(class Actor* player);
    void jumpAndPlaceIfNeeded(class Actor* player, const glm::vec3& target);
    bool placeCurrentBlock(class Actor* player);
    void handleKeyInput(class Actor* player, bool pressingW, bool pressingA, bool pressingS, bool pressingD);

public:
    void startBuilding(const glm::vec3& startPos);
    void stopBuilding();
    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onRenderEvent(class RenderEvent& event);

    bool isBuilding() const { return mIsBuilding; }
};