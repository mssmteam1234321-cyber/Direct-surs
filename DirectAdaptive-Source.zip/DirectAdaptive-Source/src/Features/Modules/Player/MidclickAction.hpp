#pragma once




#include <Features/Modules/Module.hpp>

class MidclickAction : public ModuleBase<MidclickAction> {
public:
    BoolSetting mThrowPearls = BoolSetting("Бросок перла", "Бросать эндер-перл при нажатии на колесико", false);
    BoolSetting mHotbarOnly = BoolSetting("Только хотбар", "Бросать перлы только из хотбара", false);
    BoolSetting mAddFriend = BoolSetting("Добавить друга", "Добавлять игрока в друзья при нажатии на колесико", false);
    BoolSetting mSetNukerBlock = BoolSetting("Блок для Nuker", "Устанавливать блок для Nuker при нажатии на колесико", false);
    MidclickAction() : ModuleBase("MidclickAction", "Выполняет действие при нажатии на колесико мыши", ModuleCategory::Player, 0, false)
    {
        addSetting(&mThrowPearls);
        addSetting(&mHotbarOnly);
        addSetting(&mAddFriend);
        addSetting(&mSetNukerBlock);

        VISIBILITY_CONDITION(mHotbarOnly, mThrowPearls.mValue == true);

        mNames = {
              {Lowercase, "midclickaction"},
                {LowercaseSpaced, "midclick action"},
                {Normal, "MidclickAction"},
                {NormalSpaced, "Midclick Action"}
        };
    };

    bool mThrowNextTick = false;
    bool mRotateNextTick = false;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
};