#pragma once




#include <Features/Modules/Module.hpp>

class Scaffold : public ModuleBase<Scaffold> {
public:
    enum class RotateMode {
        None,
        Normal,
        Down,
        Backwards
    };

    enum class FlickMode {
        None,
        Combat,
        Always
    };

    enum class PlacementMode {
        Normal,
        Flareon
    };

    enum class SwitchMode {
        None,
        Full,
        Fake,
        Spoof
    };

    enum class SwitchPriority {
        First,
        Highest
    };

    enum class TowerMode {
        Vanilla,
        Velocity,
        Clip
    };

    enum class BlockHUDStyle {
        None,
        Solstice,
    };

    NumberSetting mPlaces = NumberSetting("Блоков за тик", "Количество блоков за тик", 1, 0, 20, 0.01);
    NumberSetting mRange = NumberSetting("Дистанция", "Дистанция установки блоков", 5, 0, 10, 0.01);
    NumberSetting mExtend = NumberSetting("Расширение", "Дистанция расширения", 3, 0, 10, 1);
    EnumSettingT<RotateMode> mRotateMode = EnumSettingT<RotateMode>("Ротация", "Режим поворота головы", RotateMode::Normal, "Нет", "Обычная", "Вниз", "Назад");
    EnumSettingT<FlickMode> mFlickMode = EnumSettingT<FlickMode>("Флики", "Режим быстрых поворотов (фликов)", FlickMode::Combat, "Нет", "Бой", "Всегда");
    EnumSettingT<PlacementMode> mPlacementMode = EnumSettingT<PlacementMode>("Установка", "Режим установки блоков", PlacementMode::Normal, "Обычный", "Flareon");
    EnumSettingT<SwitchMode> mSwitchMode = EnumSettingT<SwitchMode>("Свап слотов", "Режим переключения слотов", SwitchMode::Full, "Нет", "Полный", "Фейк", "Спуф");
    EnumSettingT<SwitchPriority> mSwitchPriority = EnumSettingT<SwitchPriority>("Приоритет свапа", "Приоритет выбора блока", SwitchPriority::First, "Первый", "Высокий");
    BoolSetting mHotbarOnly = BoolSetting("Только хотбар", "Брать блоки только из хотбара", false);
    EnumSettingT<TowerMode> mTowerMode = EnumSettingT<TowerMode>("Тавер", "Режим строительства вверх", TowerMode::Vanilla, "Ванилла", "Велосити", "Клип");
    NumberSetting mTowerSpeed = NumberSetting("Скорость тавера", "Скорость поднятия вверх", 8.5, 0, 20, 0.01);
    BoolSetting mFallDistanceCheck = BoolSetting("Проверка падения", "Не строить вверх, если падаешь", false);
    BoolSetting mAllowMovement = BoolSetting("Движение в тавере", "Разрешить движение при строительстве вверх", false);
    EnumSettingT<BlockHUDStyle> mBlockHUDStyle = EnumSettingT<BlockHUDStyle>("Стиль HUD", "Стиль отображения количества блоков", BlockHUDStyle::Solstice, "Нет", "Solstice");
    
    BoolSetting mAvoidUnderplace = BoolSetting("Без подстройки", "Избегать установки блоков под себя", false);
    BoolSetting mFastClutch = BoolSetting("Фаст клатч", "Быстрое сохранение от падения", false);
    NumberSetting mClutchFallDistance = NumberSetting("Дистанция клатча", "Дистанция падения для срабатывания", 3, 0, 20, 0.01);
    NumberSetting mCluchPlaces = NumberSetting("Блоков клатча", "Количество блоков при клатче", 1, 0, 20, 0.01);
    BoolSetting mLockY = BoolSetting("Лок Y", "Блокировать позицию по Y", false);
    BoolSetting mSwing = BoolSetting("Свинг", "Визуализировать удар рукой", false);
    BoolSetting mTest = BoolSetting("Диагональный обход", "Тестовая функция обхода.", false);

    Scaffold() : ModuleBase("Scaffold", "Автоматически ставит блоки под вами", ModuleCategory::Player, 0, false) {
        addSettings(
            &mPlaces,
            &mRange,
            &mExtend,
            &mRotateMode,
            &mFlickMode,
            &mPlacementMode,
            &mSwitchMode,
            &mSwitchPriority,
            &mHotbarOnly,
            &mTowerMode,
            &mTowerSpeed,
            &mFallDistanceCheck,
            &mAllowMovement,
            &mBlockHUDStyle,
            
            &mAvoidUnderplace,
            &mFastClutch,
            &mClutchFallDistance,
            &mCluchPlaces,
            &mLockY,
            &mSwing,
            &mTest);

        VISIBILITY_CONDITION(mFlickMode, mRotateMode.mValue != RotateMode::None);

        VISIBILITY_CONDITION(mSwitchPriority, mSwitchMode.mValue != SwitchMode::None);
        VISIBILITY_CONDITION(mHotbarOnly, mSwitchMode.mValue != SwitchMode::None);
        VISIBILITY_CONDITION(mTowerSpeed, mTowerMode.mValue != TowerMode::Vanilla);

        VISIBILITY_CONDITION(mClutchFallDistance, mFastClutch.mValue);
        VISIBILITY_CONDITION(mCluchPlaces, mFastClutch.mValue);

        mNames = {
            {Lowercase, "scaffold"},
            {LowercaseSpaced, "scaffold"},
            {Normal, "Scaffold"},
            {NormalSpaced, "Scaffold"}
        };

        gFeatureManager->mDispatcher->listen<RenderEvent, &Scaffold::onRenderEvent>(this);
    }

    float mStartY = 0;
    glm::vec3 mLastBlock = { 0, 0, 0 };
    int mLastFace = -1;
    bool mShouldRotate = false;
    uint64_t mLastSwitchTime = 0;
    int mLastSlot = -1;
    bool mShouldClip = false;


    
    bool mIsTowering = false;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    bool tickPlace(class BaseTickEvent& event);
    void onRenderEvent(class RenderEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
    glm::vec3 getRotBasedPos(float extend, float yPos);
    glm::vec3 getPlacePos(float extend);

    std::string getSettingDisplay() override {
        return mRotateMode.mValues[mRotateMode.as<int>()];
    }


};