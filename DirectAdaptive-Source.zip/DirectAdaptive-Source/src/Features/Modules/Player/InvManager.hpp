#pragma once




#include <Features/Modules/Module.hpp>

class InvManager : public ModuleBase<InvManager> {
public:
    enum class Mode {
        Instant,
        Delayed
    };

    std::vector<std::string> mSlots = {
        "None",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9"
    };

    enum class SlotPreference {
        None,
        Slot1,
        Slot2,
        Slot3,
        Slot4,
        Slot5,
        Slot6,
        Slot7,
        Slot8,
        Slot9
    };

    enum class ManagementMode
    {
        Always,
        ContainerOnly,
        InvOnly
    };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим работы модуля", Mode::Instant, "Мгновенно", "С задержкой");
    NumberSetting mDelay = NumberSetting("Задержка", "Задержка в миллисекундах", 50, 0, 500, 1);
    EnumSettingT<ManagementMode> mManagementMode = EnumSettingT<ManagementMode>("Управление", "Когда управлять инвентарем", ManagementMode::Always, "Всегда", "Только контейнер", "Только инвентарь");
    BoolSetting mPreferredSlots = BoolSetting("Предпочтительные слоты", "Использовать предпочтительные слоты", true);
    EnumSettingT<int> mPreferredSwordSlot = EnumSettingT("Слот меча", "Слот, где находится ваш меч", 1, mSlots);
    EnumSettingT<int> mPreferredPickaxeSlot = EnumSettingT("Слот кирки", "Слот, где находится ваша кирка", 2, mSlots);
    EnumSettingT<int> mPreferredAxeSlot = EnumSettingT("Слот топора", "Слот, где находится ваш топор", 3, mSlots);
    EnumSettingT<int> mPreferredShovelSlot = EnumSettingT("Слот лопаты", "Слот, где находится ваша лопата", 4, mSlots);
    EnumSettingT<int> mPreferredFireSwordSlot = EnumSettingT("Слот огн. меча", "Слот, где находится ваш огненный меч", 5, mSlots);
    EnumSettingT<int> mPreferredBlocksSlot = EnumSettingT("Слот блоков", "Слот, где находятся ваши блоки", 6, mSlots);
    BoolSetting mDropExtraBows = BoolSetting("Выбрасывать лишние луки", "Выбрасывать лишние луки, если их больше одного", false);
    BoolSetting mIgnoreFireSword = BoolSetting("Игнорировать огн. меч", "Не выбрасывать огненный меч", false);
    BoolSetting mStealFireProtection = BoolSetting("Красть Fire Protection", "Оставлять броню с защитой от огня", false);

    InvManager() : ModuleBase("InvManager", "Управляет вашим инвентарем", ModuleCategory::Player, 0, false) {
        addSetting(&mMode);
        addSetting(&mDelay);
        addSetting(&mManagementMode);
        addSetting(&mPreferredSlots);
        addSetting(&mPreferredSwordSlot);
        addSetting(&mPreferredPickaxeSlot);
        addSetting(&mPreferredAxeSlot);
        addSetting(&mPreferredShovelSlot);
        addSetting(&mPreferredFireSwordSlot);
        addSetting(&mPreferredBlocksSlot);
        addSetting(&mDropExtraBows);
        addSetting(&mIgnoreFireSword);
#ifdef __PRIVATE_BUILD__
        addSetting(&mStealFireProtection);
#endif

        VISIBILITY_CONDITION(mPreferredSwordSlot, mPreferredSlots.mValue);
        VISIBILITY_CONDITION(mPreferredPickaxeSlot, mPreferredSlots.mValue);
        VISIBILITY_CONDITION(mPreferredAxeSlot, mPreferredSlots.mValue);
        VISIBILITY_CONDITION(mPreferredShovelSlot, mPreferredSlots.mValue);
        VISIBILITY_CONDITION(mDelay, mMode.mValue == Mode::Delayed);


        mNames = {
            {Lowercase, "invmanager"},
            {LowercaseSpaced, "inv manager"},
            {Normal, "InvManager"},
            {NormalSpaced, "Inv Manager"}
        };
    }

    int64_t mLastAction = NOW;
    int64_t mLastPing = 0;
    bool mHasOpenContainer = false;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
    void onPingUpdateEvent(class PingUpdateEvent& event);
    static bool isItemUseless(class ItemStack* item, int slot);

    std::string getSettingDisplay() override {
        return mMode.mValue == Mode::Instant ? "Instant" : std::to_string(static_cast<int>(mDelay.mValue));
    }
};
