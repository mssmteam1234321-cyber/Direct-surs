#pragma once





class AntiVoid : public ModuleBase<AntiVoid> {
public:
    NumberSetting mFallDistance = NumberSetting("Дистанция падения", "Дистанция, на которую нужно упасть, чтобы телепортироваться обратно", 5, 1, 15, 1);
    BoolSetting mTeleport = BoolSetting("Телепорт", "Телепортироваться обратно при падении", true);
    BoolSetting mTpOnce = BoolSetting("Телепорт один раз", "Телепортироваться только один раз", false);
    BoolSetting mToggleFreecam = BoolSetting("Freecam при телепорте", "Включать Freecam при телепортации", false);

    AntiVoid();

    std::vector<glm::vec3> mOnGroundPositions;
    bool mTeleported = false;
    bool mCanTeleport = true;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
};