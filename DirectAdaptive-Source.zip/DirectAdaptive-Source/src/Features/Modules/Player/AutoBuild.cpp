﻿#include "AutoBuild.hpp"
#include "Features/FeatureManager.hpp"
#include "Features/Events/BaseTickEvent.hpp"
#include "SDK/Minecraft/ClientInstance.hpp"
#include "SDK/Minecraft/Inventory/PlayerInventory.hpp"
#include "Utils/GameUtils/ActorUtils.hpp"
#include "Utils/MiscUtils/BlockUtils.hpp"
#include "Utils/MiscUtils/MathUtils.hpp"
#include "SDK/Minecraft/World/Level.hpp"
#include "SDK/Minecraft/World/BlockSource.hpp"
#include "Utils/GameUtils/ItemUtils.hpp"
#include "Utils/Keyboard.hpp"

void AutoBuild::onEnable() {
    gFeatureManager->mDispatcher->listen<BaseTickEvent, &AutoBuild::onBaseTickEvent, nes::event_priority::LAST>(this);

    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    glm::vec3 startPos = *player->getPos();
    startBuilding(startPos);
}

void AutoBuild::onDisable() {
    gFeatureManager->mDispatcher->deafen<BaseTickEvent, &AutoBuild::onBaseTickEvent>(this);
    stopBuilding();
}

void AutoBuild::startBuilding(const glm::vec3& startPos) {
    if (mIsBuilding) return;

    mIsBuilding = true;
    mStartPosition = startPos;
    mCurrentBuildIndex = 0;
    mBuildQueue.clear();
    mBlockQueue.clear();
    mFaceQueue.clear();
    mLastBuildTime = 0;

    
    switch (mBuildMode.mValue) {
    case BuildMode::AutoBrewingStand:
        setupBrewingStandLayout();
        break;
    case BuildMode::AutoFarm:
        
        break;
    }
}

void AutoBuild::stopBuilding() {
    mIsBuilding = false;
    mBuildQueue.clear();
    mBlockQueue.clear();
    mFaceQueue.clear();
    mCurrentBuildIndex = 0;
}

void AutoBuild::setupBrewingStandLayout() {
    glm::vec3 center = mStartPosition;

    
    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    float yaw = player->getActorRotationComponent()->mYaw;
    glm::vec3 forward = glm::vec3(-sin(glm::radians(yaw)), 0, cos(glm::radians(yaw)));
    glm::vec3 right = glm::vec3(forward.z, 0, -forward.x);

    
    glm::vec3 startPoint = center + forward * 2.0f;

    
    mBuildQueue.push_back(startPoint);
    mBlockQueue.push_back("chest");
    mFaceQueue.push_back(2); 

    
    glm::vec3 brewingPos = startPoint + forward * 1.0f;
    mBuildQueue.push_back(brewingPos + right * -1.0f);
    mBuildQueue.push_back(brewingPos);
    mBuildQueue.push_back(brewingPos + right * 1.0f);
    for (int i = 0; i < 3; i++) {
        mBlockQueue.push_back("brewing_stand");
        mFaceQueue.push_back(-1); 
    }

    
    glm::vec3 hopperUnderPos = brewingPos + glm::vec3(0, -1, 0);
    mBuildQueue.push_back(hopperUnderPos + right * -1.0f);
    mBuildQueue.push_back(hopperUnderPos);
    mBuildQueue.push_back(hopperUnderPos + right * 1.0f);
    for (int i = 0; i < 3; i++) {
        mBlockQueue.push_back("hopper");
        mFaceQueue.push_back(2); 
    }

    
    glm::vec3 hopperAbovePos = brewingPos + glm::vec3(0, 1, 0);
    mBuildQueue.push_back(hopperAbovePos + right * -1.0f);
    mBuildQueue.push_back(hopperAbovePos);
    mBuildQueue.push_back(hopperAbovePos + right * 1.0f);
    for (int i = 0; i < 3; i++) {
        mBlockQueue.push_back("hopper");
        mFaceQueue.push_back(1); 
    }

    
    glm::vec3 chestAbovePos = brewingPos + glm::vec3(0, 2, 0);
    mBuildQueue.push_back(chestAbovePos + right * -1.0f);
    mBuildQueue.push_back(chestAbovePos);
    mBuildQueue.push_back(chestAbovePos + right * 1.0f);
    for (int i = 0; i < 3; i++) {
        mBlockQueue.push_back("chest");
        mFaceQueue.push_back(2);
    }

    
    glm::vec3 redstoneBasePos = brewingPos + forward * 1.0f + glm::vec3(0, 1, 0);
    for (int i = -1; i <= 1; i++) {
        mBuildQueue.push_back(redstoneBasePos + right * (float)i);
        mBlockQueue.push_back("cobblestone");
        mFaceQueue.push_back(-1);
    }

    
    for (int i = -1; i <= 1; i++) {
        mBuildQueue.push_back(redstoneBasePos + right * (float)i + glm::vec3(0, 1, 0));
        mBlockQueue.push_back("redstone_wire");
        mFaceQueue.push_back(-1);
    }

    
    mBuildQueue.push_back(startPoint + right * -2.0f);
    mBlockQueue.push_back("lever");
    mFaceQueue.push_back(4); 

    
    glm::vec3 wireStart = startPoint + right * -2.0f + glm::vec3(0, 1, 0);
    for (int i = 0; i < 3; i++) {
        mBuildQueue.push_back(wireStart + forward * (float)i * 0.5f);
        mBlockQueue.push_back("redstone_wire");
        mFaceQueue.push_back(-1);
    }
}

void AutoBuild::onBaseTickEvent(BaseTickEvent& event) {
    if (!mIsBuilding || mCurrentBuildIndex >= mBuildQueue.size()) {
        if (mCurrentBuildIndex >= mBuildQueue.size()) {
            stopBuilding();
        }
        return;
    }

    auto player = event.mActor;
    if (!player) return;

    
    if (NOW - mLastBuildTime < (1000 / mBuildSpeed.mValue)) {
        return;
    }

    glm::vec3 currentTarget = mBuildQueue[mCurrentBuildIndex];

    
    if (mAutoMove.mValue) {
        if (!moveToBuildPosition(player, currentTarget)) {
            
            if (mAvoidObstacles.mValue) {
                handleObstacleAvoidance(player);
            }
            return; 
        }
    }

    
    bool placed = placeCurrentBlock(player);
    if (placed) {
        mCurrentBuildIndex++;
        mLastBuildTime = NOW;
    }
    else {
        
        if (mJumpPlace.mValue) {
            jumpAndPlaceIfNeeded(player, currentTarget);
        }
        else {
            
            mCurrentBuildIndex++;
        }
    }
}

bool AutoBuild::moveToBuildPosition(Actor* player, const glm::vec3& target) {
    if (!player) return false;

    glm::vec3 currentPos = *player->getPos();
    glm::vec3 direction = target - currentPos;

    
    float horizontalDistance = glm::length(glm::vec2(direction.x, direction.z));

    
    if (horizontalDistance < 2.5f) {
        
        handleKeyInput(player, false, false, false, false);

        
        auto actorRot = player->getActorRotationComponent();
        if (actorRot) {
            float targetYaw = atan2(direction.x, direction.z) * (180.0f / IM_PI);
            actorRot->mYaw = targetYaw;
        }

        return true;
    }

    
    glm::vec3 horizontalDir = glm::normalize(glm::vec3(direction.x, 0, direction.z));

    
    auto moveInput = player->getMoveInputComponent();
    auto stateVec = player->getStateVectorComponent();
    auto actorRot = player->getActorRotationComponent();

    if (moveInput && stateVec && actorRot) {
        
        float targetYaw = atan2(horizontalDir.x, horizontalDir.z) * (180.0f / IM_PI);
        actorRot->mYaw = targetYaw;

        
        handleKeyInput(player, true, false, false, false);

        
        if (target.y > currentPos.y + 1.5f && player->isOnGround()) {
            moveInput->mIsJumping = true;
        }
        else {
            moveInput->mIsJumping = false;
        }
    }

    return false;
}

bool AutoBuild::canReachPosition(Actor* player, const glm::vec3& pos) {
    if (!player) return false;

    glm::vec3 playerPos = *player->getPos();
    float horizontalDistance = glm::distance(
        glm::vec2(playerPos.x, playerPos.z),
        glm::vec2(pos.x, pos.z)
    );

    
    return horizontalDistance < 3.0f;
}

void AutoBuild::handleObstacleAvoidance(Actor* player) {
    if (!player) return;

    auto moveInput = player->getMoveInputComponent();
    auto stateVec = player->getStateVectorComponent();
    auto actorRot = player->getActorRotationComponent();

    if (!moveInput || !stateVec || !actorRot) return;

    
    if (player->isOnGround()) {
        moveInput->mIsJumping = true;
    }

    
    handleKeyInput(player, false, false, false, true);

    
    float yaw = actorRot->mYaw * (IM_PI / 180);
    stateVec->mVelocity.x = cos(yaw + IM_PI / 2) * 0.2f;
    stateVec->mVelocity.z = sin(yaw + IM_PI / 2) * 0.2f;
}

void AutoBuild::jumpAndPlaceIfNeeded(Actor* player, const glm::vec3& target) {
    if (!player) return;

    glm::vec3 playerPos = *player->getPos();

    
    if (target.y > playerPos.y + 1.0f && player->isOnGround()) {
        auto moveInput = player->getMoveInputComponent();
        if (moveInput) {
            moveInput->mIsJumping = true;
        }
    }
}

bool AutoBuild::placeCurrentBlock(Actor* player) {
    if (mCurrentBuildIndex >= mBuildQueue.size()) return false;
    if (!player) return false;

    glm::vec3 blockPos = mBuildQueue[mCurrentBuildIndex];
    std::string blockType = mBlockQueue[mCurrentBuildIndex];
    int face = mFaceQueue[mCurrentBuildIndex];

    BlockPos blockPosInt((int)blockPos.x, (int)blockPos.y, (int)blockPos.z);

    
    if (!BlockUtils::isAirBlock(blockPosInt)) {
        return true; 
    }

    
    int side = face;
    if (side == -1) {
        side = BlockUtils::getBlockPlaceFace(blockPosInt);
    }

    if (side == -1) {
        return false; 
    }

    
    int originalSlot = player->getSupplies()->mSelectedSlot;
    int targetSlot = ItemUtils::getPlaceableItemOnBlock(blockPosInt, true, true);

    if (targetSlot != -1) {
        player->getSupplies()->mSelectedSlot = targetSlot;

        
        BlockUtils::placeBlock(blockPosInt, side);

        
        player->getSupplies()->mSelectedSlot = originalSlot;
        return true;
    }

    return false;
}

void AutoBuild::handleKeyInput(Actor* player, bool pressingW, bool pressingA, bool pressingS, bool pressingD) {
    if (!player) return;

    auto moveInputComponent = player->getMoveInputComponent();

    moveInputComponent->mForward = pressingW;
    moveInputComponent->mLeft = pressingA;
    moveInputComponent->mBackward = pressingS;
    moveInputComponent->mRight = pressingD;
}

void AutoBuild::onRenderEvent(RenderEvent& event) {
    if (!mShowProgress.mValue || !mIsBuilding) return;

    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    
    float progress = 0.0f;
    if (!mBuildQueue.empty()) {
        progress = (float)mCurrentBuildIndex / (float)mBuildQueue.size();
    }

    
    ImVec2 pos = ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y * 0.75f);

    std::string progressText = "Building: " + std::to_string((int)(progress * 100)) + "%";
    std::string structureText = "Structure: " + mBuildMode.mValues[mBuildMode.as<int>()];
    std::string blocksText = "Blocks: " + std::to_string(mCurrentBuildIndex) + "/" + std::to_string(mBuildQueue.size());

    
    std::string targetText = "Target: ";
    if (mCurrentBuildIndex < mBuildQueue.size()) {
        glm::vec3 target = mBuildQueue[mCurrentBuildIndex];
        targetText += std::to_string((int)target.x) + ", " +
            std::to_string((int)target.y) + ", " +
            std::to_string((int)target.z);
    }
    else {
        targetText += "None";
    }

    auto drawList = ImGui::GetBackgroundDrawList();

    
    ImVec2 textSize = ImGui::GetFont()->CalcTextSizeA(20.0f, FLT_MAX, 0, progressText.c_str());
    ImVec2 blocksTextSize = ImGui::GetFont()->CalcTextSizeA(16.0f, FLT_MAX, 0, blocksText.c_str());
    ImVec2 targetTextSize = ImGui::GetFont()->CalcTextSizeA(14.0f, FLT_MAX, 0, targetText.c_str());

    float backgroundHeight = textSize.y + blocksTextSize.y + targetTextSize.y + 50;
    float backgroundWidth = fmax(fmax(textSize.x, blocksTextSize.x), targetTextSize.x) + 20;

    drawList->AddRectFilled(
        ImVec2(pos.x - backgroundWidth / 2, pos.y - 5),
        ImVec2(pos.x + backgroundWidth / 2, pos.y + backgroundHeight),
        ImColor(0, 0, 0, 150), 5.0f
    );

    
    drawList->AddText(
        ImGui::GetFont(), 20.0f,
        ImVec2(pos.x - textSize.x / 2, pos.y),
        ImColor(255, 255, 255, 255),
        progressText.c_str()
    );

    
    ImVec2 structTextSize = ImGui::GetFont()->CalcTextSizeA(16.0f, FLT_MAX, 0, structureText.c_str());
    drawList->AddText(
        ImGui::GetFont(), 16.0f,
        ImVec2(pos.x - structTextSize.x / 2, pos.y + textSize.y + 5),
        ImColor(200, 200, 200, 255),
        structureText.c_str()
    );

    
    drawList->AddText(
        ImGui::GetFont(), 16.0f,
        ImVec2(pos.x - blocksTextSize.x / 2, pos.y + textSize.y + structTextSize.y + 10),
        ImColor(150, 200, 255, 255),
        blocksText.c_str()
    );

    
    drawList->AddText(
        ImGui::GetFont(), 14.0f,
        ImVec2(pos.x - targetTextSize.x / 2, pos.y + textSize.y + structTextSize.y + blocksTextSize.y + 15),
        ImColor(255, 200, 100, 255),
        targetText.c_str()
    );

    
    float barWidth = backgroundWidth - 20;
    drawList->AddRect(
        ImVec2(pos.x - barWidth / 2, pos.y + textSize.y + structTextSize.y + blocksTextSize.y + targetTextSize.y + 20),
        ImVec2(pos.x + barWidth / 2, pos.y + textSize.y + structTextSize.y + blocksTextSize.y + targetTextSize.y + 25),
        ImColor(255, 255, 255, 255), 2.0f
    );

    drawList->AddRectFilled(
        ImVec2(pos.x - barWidth / 2, pos.y + textSize.y + structTextSize.y + blocksTextSize.y + targetTextSize.y + 20),
        ImVec2(pos.x - barWidth / 2 + barWidth * progress, pos.y + textSize.y + structTextSize.y + blocksTextSize.y + targetTextSize.y + 25),
        ImColor(0, 255, 0, 255), 2.0f
    );
}