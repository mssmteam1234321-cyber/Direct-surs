#pragma once





class ClickTp : public ModuleBase<ClickTp> {
public:

    ClickTp() : ModuleBase("ClickTp", "Телепортирует вас к блоку, на который вы смотрите", ModuleCategory::Player, 0, false)
    {
        mNames = {
            {Lowercase, "clicktp"},
              {LowercaseSpaced, "click tp"},
              {Normal, "ClickTp"},
              {NormalSpaced, "Click Tp"}
        };
    };

    void onEnable() override;
};
