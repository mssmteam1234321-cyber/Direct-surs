#pragma once




#include <Features/Modules/Module.hpp>

class AutoTool : public ModuleBase<AutoTool> {
public:
    BoolSetting mHotbarOnly = BoolSetting{ "Только хотбар", "Переключаться только на инструменты в хотбаре", false };
    BoolSetting mFakeSpoof = BoolSetting{ "Фейк спуф", "Подменять инструмент в хотбаре", false };
    AutoTool() : ModuleBase("AutoTool", "Автоматически переключается на лучший инструмент для ломаемого блока", ModuleCategory::Player, 0, false)
    {
        addSetting(&mHotbarOnly);
        addSetting(&mFakeSpoof);

        mNames = {
              {Lowercase, "autotool"},
                {LowercaseSpaced, "auto tool"},
                {Normal, "AutoTool"},
                {NormalSpaced, "Auto Tool"}
        };
    };

    int mOldSlot = -1;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
};