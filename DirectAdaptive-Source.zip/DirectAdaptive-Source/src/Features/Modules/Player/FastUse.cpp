﻿



#include "FastUse.hpp"

#include <algorithm>

#include <Features/FeatureManager.hpp>
#include <Features/Events/BaseTickEvent.hpp>
#include <Hook/Hooks/MiscHooks/MouseHook.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>
#include <SDK/Minecraft/Actor/GameMode.hpp>
#include <SDK/Minecraft/Inventory/PlayerInventory.hpp>
#include <SDK/Minecraft/Inventory/ItemStack.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>

void FastUse::onEnable()
{
    mLastUse = 0;
    gFeatureManager->mDispatcher->listen<BaseTickEvent, &FastUse::onBaseTickEvent>(this);
}

void FastUse::onDisable()
{
    gFeatureManager->mDispatcher->deafen<BaseTickEvent, &FastUse::onBaseTickEvent>(this);
}

void FastUse::onBaseTickEvent(BaseTickEvent& event)
{
    auto player = event.mActor;
    if (!player || !player->isValid() || !player->isPlayer())
        return;

    auto ci = ClientInstance::get();
    if (!ci || ci->getScreenName() != "hud_screen")
        return;

    bool isUsing = true;
    if (mHoldRMB.mValue)
    {
        const auto btn = MouseHook::mButtonStates.find(2); 
        isUsing = btn != MouseHook::mButtonStates.end() ? btn->second : ImGui::IsMouseDown(1);
    }

    if (!isUsing)
        return;

    auto supplies = player->getSupplies();
    if (!supplies)
        return;

    const int slot = supplies->mSelectedSlot;
    if (slot < 0)
        return;

    auto container = supplies->getContainer();
    if (!container)
        return;

    ItemStack* stack = container->getItem(slot);
    if (!stack || !stack->mItem || stack->mCount <= 0)
        return;

    
    auto item = stack->getItem();
    if (!item || item->mName != "experience_bottle")
        return;

    const uint64_t now = NOW;
    const float cappedRate = std::max(1.0f, mUseRate.mValue);
    const uint64_t interval = static_cast<uint64_t>(1000.f / cappedRate);

    if (now - mLastUse < interval)
        return;

    mLastUse = now;

    const int repeat = std::clamp(mUseAmount.as<int>(), 1, 10);
    for (int i = 0; i < repeat; i++)
    {
        container->startUsingItem(slot);
        player->getGameMode()->baseUseItem(stack);

        if (!stack->mItem || stack->mCount <= 0)
            break;
    }
}

