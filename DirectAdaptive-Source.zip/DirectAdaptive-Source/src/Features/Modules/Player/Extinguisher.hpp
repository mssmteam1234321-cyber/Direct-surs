


#pragma once
#include <Features/Modules/Module.hpp>

class Extinguisher : public ModuleBase<Extinguisher> {
public:

    NumberSetting mRange = NumberSetting("Дистанция", "Дистанция тушения", 7, 0, 10, 0.01);
    BoolSetting mRotate = BoolSetting("Поворот", "Включить поворот", true);

    Extinguisher() : ModuleBase("Extinguisher", "Тушит огонь", ModuleCategory::Player, 0, false) {

        addSetting(&mRange);
        addSetting(&mRotate);

        mNames = {
                {Lowercase, "extinguisher"},
                {LowercaseSpaced, "extinguisher"},
                {Normal, "Extinguisher"},
                {NormalSpaced, "Extinguisher"},
        };
    }

    bool mShouldRotate = false;
    glm::vec3 mCurrentPosition = {0.f, 0.f, 0.f};

    bool isValidBlock(glm::ivec3 blockPos);
    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
};