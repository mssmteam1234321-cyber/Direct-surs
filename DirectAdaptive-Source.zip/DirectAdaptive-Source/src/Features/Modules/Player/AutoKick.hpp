#pragma once




#include <Features/Modules/Module.hpp>

class AutoKick : public ModuleBase<AutoKick> {
public:
    enum class Mode {
        Push,
        Replace
    };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим работы модуля", Mode::Push, "Толкать", "Заменять");
    NumberSetting mRange = NumberSetting("Дистанция", "Дистанция для удара", 5, 3, 8, 0.1);
    NumberSetting mDelay = NumberSetting("Задержка", "Задержка в мс перед установкой блока", 1000, 100, 5000, 10);
    BoolSetting mHotbarOnly = BoolSetting("Только хотбар", "Использовать только блоки из хотбара", true);
    BoolSetting mAllowDiagonal = BoolSetting("Разрешить диагональ", "Разрешить диагональное предсказание", true);
    BoolSetting mOnGroundOnly = BoolSetting("Только на земле", "Ставить блок, когда цель на земле", true);
    NumberSetting mMaxOnGroundTicks = NumberSetting("Тики на земле", "Максимальное количество тиков на земле для установки блока", 10, 0, 100, 5);
    NumberSetting mOpponentPing = NumberSetting("Пинг противника", "Укажите пинг противника", 90, 0, 300, 10);
    BoolSetting mSpamPlace = BoolSetting("Спам установка", "Сбрасывать задержку, если блок призрачный", false);
    NumberSetting mDestroySpeed = NumberSetting("Скорость разрушения", "Скорость разрушения для быстрого майнинга", 1, 0.01, 1, 0.01);
    BoolSetting mInfiniteDurability = BoolSetting("Бесконечная прочность", "Бесконечная прочность для инструментов (может вызвать проблемы!)", false);
    BoolSetting mDebug = BoolSetting("Отладка", "Отправлять отладочные сообщения в чат", false);
    AutoKick() : ModuleBase("AutoKick", "Пытается кикнуть игроков, ставя блоки перед ними", ModuleCategory::Player, 0, false)
    {
        addSetting(&mMode);
        addSetting(&mRange);
        addSetting(&mDelay);
        addSetting(&mHotbarOnly);
        addSetting(&mAllowDiagonal);
        addSetting(&mOnGroundOnly);
        addSetting(&mMaxOnGroundTicks);
        addSetting(&mOpponentPing);
        addSetting(&mSpamPlace);
        addSetting(&mDestroySpeed);
        addSetting(&mInfiniteDurability);
        addSetting(&mDebug);

        VISIBILITY_CONDITION(mMaxOnGroundTicks, mOnGroundOnly.mValue);

        mNames = {
              {Lowercase, "autokick"},
                {LowercaseSpaced, "auto kick"},
                {Normal, "AutoKick"},
                {NormalSpaced, "Auto Kick"}
        };
    };

    int mPreviousSlot = 0;

    
    bool mSelectedSlot = false;
    bool mShouldRotate = false;

    glm::vec3 mLastTargetPos = { INT_MAX, INT_MAX, INT_MAX };
    bool mUsePrediction = false;
    int mOnGroundTicks = 0;

    uint64_t mLastBlockPlace = 0;
    glm::ivec3 mCurrentPlacePos = { INT_MAX, INT_MAX, INT_MAX };
    uint64_t mLastBlockUpdated = 0;
    glm::ivec3 mLastServerBlockPos = { INT_MAX, INT_MAX, INT_MAX };
    bool mFlagged = false;

    uint64_t mPing = 100;
    uint64_t mEventDelay = 0;

    std::vector<glm::ivec3> mRecentlyUpdatedBlockPositions;

    std::map<std::string, int> mFlagCounter;

    
    std::vector<glm::ivec3> mMiningBlocks;
    glm::ivec3 mCurrentBlockPos = { INT_MAX, INT_MAX, INT_MAX };
    int mCurrentBlockFace = 0;
    int mToolSlot = 0;
    bool mIsMiningBlock = false;
    bool mShouldRotateToBlock = false;
    bool mShouldSpoofSlot = false;
    bool mShouldSetbackSlot = false;
    bool mWasPlacingBlock = false;
    float mBreakingProgress = 0.f;

    void onEnable();
    void onDisable() override;
    void reset();
    bool isValidBlock(glm::ivec3 blockPos);
    void queueBlock(glm::ivec3 blockPos);
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onSendImmediateEvent(class SendImmediateEvent& event);
    void onPingUpdateEvent(class PingUpdateEvent& event);
};