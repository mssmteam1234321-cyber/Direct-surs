
#pragma once
#include <Features/Modules/Module.hpp>

class OreMiner : public ModuleBase<OreMiner> {
public:
    enum class UncoverMode {
        None,
        PathFind,
#ifdef __PRIVATE_BUILD__
        UnderGround,
#endif
    };
    enum class CalcMode {
        Normal,
        Dynamic
    };
    enum class OrePriority {
        High,
        Medium,
        Low
    };
    EnumSettingT<UncoverMode> mUncoverMode = EnumSettingT<UncoverMode>("Режим раскрытия", "Режим раскрытия блоков", UncoverMode::None, "Нет", "Поиск пути"
#ifdef __PRIVATE_BUILD__
    ,"Under Ground"
#endif
    );
    EnumSettingT<CalcMode> mCalcMode = EnumSettingT<CalcMode>("Режим расчета", "Режим расчета скорости разрушения", CalcMode::Normal, "Обычный", "Динамический");
    BoolSetting mOnGroundOnly = BoolSetting("Только на земле", "Использовать динамическую скорость только на земле", false);
    NumberSetting mRange = NumberSetting("Дистанция", "Максимальная дистанция разрушения", 5, 0, 10, 0.01);
    NumberSetting mUncoverRange = NumberSetting("Дистанция раскрытия", "Максимальная дистанция раскрытия блоков", 3, 1, 8, 1);
    NumberSetting mDestroySpeed = NumberSetting("Скорость разрушения", "Скорость разрушения руды", 1, 0.01, 1, 0.01);
    BoolSetting mEmerald = BoolSetting("Изумруд", "Ломать изумрудную руду", false);
    EnumSettingT<OrePriority> mEmeraldPriority = EnumSettingT<OrePriority>("Приоритет изумруда", "Приоритет изумрудной руды", OrePriority::Medium, "Высокий", "Средний", "Низкий");
    BoolSetting mDiamond = BoolSetting("Алмаз", "Ломать алмазную руду", false);
    EnumSettingT<OrePriority> mDiamondPriority = EnumSettingT<OrePriority>("Приоритет алмаза", "Приоритет алмазной руды", OrePriority::Medium, "Высокий", "Средний", "Низкий");
    BoolSetting mGold = BoolSetting("Золото", "Ломать золотую руду", false);
    EnumSettingT<OrePriority> mGoldPriority = EnumSettingT<OrePriority>("Приоритет золота", "Приоритет золотой руды", OrePriority::Medium, "Высокий", "Средний", "Низкий");
    BoolSetting mIron = BoolSetting("Железо", "Ломать железную руду", false);
    EnumSettingT<OrePriority> mIronPriority = EnumSettingT<OrePriority>("Приоритет железа", "Приоритет железной руды", OrePriority::Medium, "Высокий", "Средний", "Низкий");
    BoolSetting mCoal = BoolSetting("Уголь", "Ломать угольную руду", false);
    EnumSettingT<OrePriority> mCoalPriority = EnumSettingT<OrePriority>("Приоритет угля", "Приоритет угольной руды", OrePriority::Medium, "Высокий", "Средний", "Низкий");
    BoolSetting mRedstone = BoolSetting("Редстоун", "Ломать редстоуновую руду", false);
    EnumSettingT<OrePriority> mRedstonePriority = EnumSettingT<OrePriority>("Приоритет редстоуна", "Приоритет редстоуновой руды", OrePriority::Medium, "Высокий", "Средний", "Низкий");
    BoolSetting mLapis = BoolSetting("Лазурит", "Ломать лазуритовую руду", false);
    EnumSettingT<OrePriority> mLapisPriority = EnumSettingT<OrePriority>("Приоритет лазурита", "Приоритет лазуритовой руды", OrePriority::Medium, "Высокий", "Средний", "Низкий");
    BoolSetting mSwing = BoolSetting("Взмах", "Махать рукой при разрушении блоков", false);
    BoolSetting mHotbarOnly = BoolSetting("Только хотбар", "Использовать только инструменты из хотбара", false);
    BoolSetting mInfiniteDurability = BoolSetting("Бесконечная прочность", "Бесконечная прочность для инструментов (может вызвать проблемы!)", false);
    BoolSetting mRenderBlock = BoolSetting("Рендер блока", "Рендерить блок, который вы ломаете", true);

    OreMiner() : ModuleBase("OreMiner", "Автоматически ломает руды", ModuleCategory::Player, 0, false) {
        addSetting(&mUncoverMode);
        addSetting(&mCalcMode);
        addSetting(&mOnGroundOnly);
        addSetting(&mRange);
        addSetting(&mUncoverRange);
        addSetting(&mDestroySpeed);
        addSetting(&mEmerald);
        addSetting(&mEmeraldPriority);
        addSetting(&mDiamond);
        addSetting(&mDiamondPriority);
        addSetting(&mGold);
        addSetting(&mGoldPriority);
        addSetting(&mIron);
        addSetting(&mIronPriority);
        addSetting(&mCoal);
        addSetting(&mCoalPriority);
        addSetting(&mRedstone);
        addSetting(&mRedstonePriority);
        addSetting(&mLapis);
        addSetting(&mLapisPriority);
        addSetting(&mSwing);
        addSetting(&mHotbarOnly);
        addSetting(&mInfiniteDurability);
        addSetting(&mRenderBlock);

        VISIBILITY_CONDITION(mOnGroundOnly, mCalcMode.mValue == CalcMode::Dynamic);

        VISIBILITY_CONDITION(mEmeraldPriority, mEmerald.mValue);
        VISIBILITY_CONDITION(mDiamondPriority, mDiamond.mValue);
        VISIBILITY_CONDITION(mGoldPriority, mGold.mValue);
        VISIBILITY_CONDITION(mIronPriority, mIron.mValue);
        VISIBILITY_CONDITION(mCoalPriority, mCoal.mValue);
        VISIBILITY_CONDITION(mRedstonePriority, mRedstone.mValue);
        VISIBILITY_CONDITION(mLapisPriority, mLapis.mValue);
        
        mNames = {
            {Lowercase, "oreminer"},
            {LowercaseSpaced, "ore miner"},
            {Normal, "OreMiner"},
            {NormalSpaced, "Ore Miner"}
        };
    }

    struct PathFindResult {
        glm::ivec3 blockPos;
        bool foundPath;
    };

    static inline glm::ivec3 mCurrentBlockPos = { INT_MAX, INT_MAX, INT_MAX };
    glm::ivec3 mTargettingBlockPos = { INT_MAX, INT_MAX, INT_MAX };
    int mCurrentBlockFace = -1;
    float mBreakingProgress = 0.f;
    float mCurrentDestroySpeed = 1.f;
    static inline bool mIsMiningBlock = false;
    bool mWasMiningBlock = false;
    bool mIsUncovering = false;
    bool mShouldRotate = false;
    bool mShouldSpoofSlot = false;
    bool mShouldSetbackSlot = false;
    int mPreviousSlot = -1;
    int mToolSlot = -1;
    bool mOffGround = false;

    uint64_t mLastBlockPlace = 0;
    int mLastPlacedBlockSlot = 0;

    std::vector<glm::ivec3> mOffsetList = {
        glm::ivec3(0, -1, 0),
        glm::ivec3(0, 1, 0),
        glm::ivec3(0, 0, -1),
        glm::ivec3(0, 0, 1),
        glm::ivec3(-1, 0, 0),
        glm::ivec3(1, 0, 0),
    };

    std::vector<int> mEmeraldIds = {
        129,
        662,
    };

    std::vector<int> mDiamondIds = {
        56,
        660,
    };

    std::vector<int> mGoldIds = {
        14,
        657,
    };

    std::vector<int> mIronIds = {
        15,
        656,
    };

    std::vector<int> mCoalIds = {
        16,
        661,
    };

    std::vector<int> mRedstoneIds = {
        73,
        74,
        658,
        659,
    };

    std::vector<int> mLapisIds = {
        21,
        655,
    };

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onRenderEvent(class RenderEvent& event);
    void renderBlock();
    void onPacketOutEvent(class PacketOutEvent& event);
    void reset();
    void queueBlock(glm::ivec3 blockPos);
    bool isValidBlock(glm::ivec3 blockPos, bool oreOnly, bool exposedOnly, bool usePriority = false, OrePriority priority = OrePriority::Medium);
    PathFindResult getBestPathToBlock(glm::ivec3 blockPos);
    bool isOre(std::vector<int> Ids, int id);

    std::string getSettingDisplay() override {
        return mUncoverMode.mValues[mUncoverMode.as<int>()];
    }
};