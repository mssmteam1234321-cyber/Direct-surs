﻿#pragma once




#include <Features/Modules/Module.hpp>

class Surround : public ModuleBase<Surround> {
public:
    NumberSetting mRange = NumberSetting("Дистанция", "Дистанция на которой окружать сущностей", 5, 3, 8, 0.1);
    NumberSetting mDelay = NumberSetting("Задержка", "Задержка в мс перед установкой блока", 500, 0, 3000, 50);
    BoolSetting mHotbarOnly = BoolSetting("Только хотбар", "Использовать только блоки из хотбара", true);
    BoolSetting mDebug = BoolSetting("Отладка", "Отправлять сообщения отладки", false);
    Surround() : ModuleBase("Surround", "Окружает игрока блоками", ModuleCategory::Player, 0, false)
    {
        addSetting(&mRange);
        addSetting(&mDelay);
        addSetting(&mHotbarOnly);
        addSetting(&mDebug);

        mNames = {
              {Lowercase, "surround"},
                {LowercaseSpaced, "surround"},
                {Normal, "Surround"},
                {NormalSpaced, "Surround"}
        };
    };

    uint64_t mLastBlockPlaced = 0;
    int mLastSlot = 0;

    void onEnable();
    void onDisable() override;
    std::vector<glm::ivec3> getCollidingBlocks(Actor* target);
    std::vector<glm::ivec3> getPlacePositions(std::vector<glm::ivec3> blockList);
    glm::ivec3 getClosestPlacePos(glm::ivec3 pos, float distance, std::vector<glm::ivec3> collidingBlocks);
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
};