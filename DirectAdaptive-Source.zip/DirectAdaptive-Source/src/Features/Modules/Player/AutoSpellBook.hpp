#pragma once




class AutoSpellBook : public ModuleBase<AutoSpellBook>
{
public:
    BoolSetting mUseHealthSpell = BoolSetting("Исцеление", "Использовать заклинание исцеления, когда здоровье ниже 6 сердец", true);
    BoolSetting mUseSpeedSpell = BoolSetting("Скорость", "Использовать заклинание скорости при включении модуля Speed", true);
    BoolSetting mUseFireTrailSpell = BoolSetting("Огненный след", "Использовать заклинание огненного следа, когда у ауры есть цель", true);
    BoolSetting mShowNotification = BoolSetting("Уведомления", "Показывать уведомление при использовании книги заклинаний", true);

    AutoSpellBook() : ModuleBase("AutoSpellBook", "Автоматически использует ваши заклинания", ModuleCategory::Player, 0, false) {
        addSetting(&mUseHealthSpell);
        addSetting(&mUseSpeedSpell);
        addSetting(&mUseFireTrailSpell);
        addSetting(&mShowNotification);

        mNames = {
            {Lowercase, "autospellbook"},
            {LowercaseSpaced, "auto spell book"},
            {Normal, "AutoSpellBook"},
            {NormalSpaced, "Auto Spell Book"},
        };
    };

    int mHealthSpellSlot = -1;
    int mSpeedSpellSlot = -1;
    int mFireTrailSpellSlot = -1;

    int getHealthSpell();
    int getSpeedSpell();
    int getFireTrailSpell();
    void useSpell(int slot);
    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
};
