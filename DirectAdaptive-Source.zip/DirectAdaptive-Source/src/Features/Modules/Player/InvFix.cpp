﻿



#include "InvFix.hpp"

#include <Features/FeatureManager.hpp>
#include <Features/Events/PacketInEvent.hpp>
#include <Features/Events/PacketOutEvent.hpp>
#include <SDK/Minecraft/Network/Packets/ContainerClosePacket.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>

void InvFix::onEnable()
{
    mLastOpen = 0;
    mContainerOpen = false;
    gFeatureManager->mDispatcher->listen<PacketInEvent, &InvFix::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketOutEvent, &InvFix::onPacketOutEvent>(this);
}

void InvFix::onDisable()
{
    gFeatureManager->mDispatcher->deafen<PacketInEvent, &InvFix::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketOutEvent, &InvFix::onPacketOutEvent>(this);
    mContainerOpen = false;
}

void InvFix::onPacketInEvent(PacketInEvent& event)
{
    auto id = event.mPacket->getId();
    const uint64_t now = NOW;

    if (id == PacketID::ContainerOpen)
    {
        mContainerOpen = true;
        mLastOpen = now;
        return;
    }

    if (id == PacketID::ContainerClose)
    {
        const uint64_t debounce = static_cast<uint64_t>(mDelayMs.mValue);
        if (mContainerOpen && now - mLastOpen < debounce)
        {
            event.cancel();
            return;
        }
        mContainerOpen = false;
    }
}

void InvFix::onPacketOutEvent(PacketOutEvent& event)
{
    auto id = event.mPacket->getId();
    const uint64_t now = NOW;

    if (id == PacketID::ContainerClose)
    {
        const uint64_t debounce = static_cast<uint64_t>(mDelayMs.mValue);
        if (mContainerOpen && now - mLastOpen < debounce)
        {
            event.cancel();
        }
        else
        {
            mContainerOpen = false;
        }
    }
}

