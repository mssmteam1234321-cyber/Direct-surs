#pragma once




#include <Features/Modules/Module.hpp>
#include <SDK/Minecraft/Inventory/ContainerManagerModel.hpp>

class ChestStealer : public ModuleBase<ChestStealer> {
public:
    enum class Mode
    {
        Normal,
        Silent
    };

    EnumSettingT<Mode> mMode = EnumSettingT("Режим", "Режим работы ChestStealer", Mode::Normal, "Обычный", "Silent");
    BoolSetting mRandomizeDelay = BoolSetting("Рандомная задержка", "Рандомизировать задержку между взятием предметов", false);
    NumberSetting mDelay = NumberSetting("Задержка", "Задержка между взятием предметов (в мс)", 50, 0, 500, 1);
    NumberSetting mRandomizeMin = NumberSetting("Мин. задержка", "Минимальная задержка рандомизации", 50, 0, 500, 1);
    NumberSetting mRandomizeMax = NumberSetting("Макс. задержка", "Максимальная задержка рандомизации", 100, 0, 500, 1);
    BoolSetting mIgnoreUseless = BoolSetting("Игнорировать мусор", "Не брать бесполезные предметы", true);


    ChestStealer() : ModuleBase<ChestStealer>("ChestStealer", "Крадет предметы из сундуков", ModuleCategory::Player, 0, false)
    {
        addSettings(
#ifdef __PRIVATE_BUILD__
            &mMode,
#endif
            &mRandomizeDelay,
            &mDelay,
            &mRandomizeMin,
            &mRandomizeMax,
            &mIgnoreUseless
        );

        VISIBILITY_CONDITION(mRandomizeMin, mRandomizeDelay.mValue == true);
        VISIBILITY_CONDITION(mRandomizeMax, mRandomizeDelay.mValue == true);
        VISIBILITY_CONDITION(mDelay, mRandomizeDelay.mValue == false);

        mNames = {
            {Lowercase, "cheststealer"},
            {LowercaseSpaced, "chest stealer"},
            {Normal, "ChestStealer"},
            {NormalSpaced, "Chest Stealer"}
        };
    }

    bool mIsStealing = false;
    uint64_t mLastItemTaken = 0;
    bool mIsChestOpen = false;
    std::vector<ItemStack> mItemsToTake = {};
    bool mTotalDirty = false;
    int mTotalItems = 0;
    int mRemainingItems = 0;
    glm::vec3 mLastPos = glm::vec3(0);
    glm::vec3 mHighlightedPos = glm::vec3(0);
    ContainerID mCurrentContainerId = ContainerID::None;
    uint64_t mLastOpen = 0;

    void onContainerScreenTickEvent(class ContainerScreenTickEvent& event) const;
    void reset();
    void onEnable() override;
    void onDisable() override;
    void takeItem(int slot, ItemStack& item);
    void takeItems(std::map<int, ItemStack>& items);
    void onBaseTickEvent(class BaseTickEvent& event);
    bool doDelay();
    void onRenderEvent(class RenderEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    uint64_t getDelay() const;

    std::string getSettingDisplay() override {
        if (mRandomizeDelay.mValue)
        {
            return std::to_string(static_cast<int>(mRandomizeMin.mValue)) + " " + std::to_string(static_cast<int>(mRandomizeMax.mValue));
        }
        else
        {
            return std::to_string(static_cast<int>(mDelay.mValue)) + "";
        }
    }
};
