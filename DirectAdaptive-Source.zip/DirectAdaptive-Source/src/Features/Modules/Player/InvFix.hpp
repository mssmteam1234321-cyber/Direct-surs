#pragma once

class InvFix : public ModuleBase<InvFix> {
public:
    NumberSetting mDelayMs = NumberSetting("Delay", "Ignore closes for this long (ms)", 250.f, 50.f, 1000.f, 25.f);

    InvFix() : ModuleBase("InvFix", "Предотвращает закрытие инвентаря", ModuleCategory::Player, 0, false)
    {
        addSettings(&mDelayMs);
        mNames = {
            {Lowercase, "invfix"},
            {LowercaseSpaced, "inv fix"},
            {Normal, "InvFix"},
            {NormalSpaced, "Inv Fix"}
        };
    }

    void onEnable() override;
    void onDisable() override;

    void onPacketInEvent(class PacketInEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);

private:
    uint64_t mLastOpen = 0;
    bool mContainerOpen = false;
};

