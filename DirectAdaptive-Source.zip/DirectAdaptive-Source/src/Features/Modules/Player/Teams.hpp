


#pragma once
#include <Features/Modules/Module.hpp>

class Teams : public ModuleBase<Teams> {
public:
    static inline Teams* instance = nullptr;

    enum class Mode {
        Hive
    };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>("Режим", "Режим работы Teams", Mode::Hive, "Hive");

    Teams() : ModuleBase("Teams", "Игнорирует игроков вашей команды", ModuleCategory::Player, 0, false) {

        addSettings(&mMode);

        mNames = {
                {Lowercase, "teams"},
                {LowercaseSpaced, "teams"},
                {Normal, "Teams"},
                {NormalSpaced, "Teams"},
        };

        instance = this;
    }

    void onEnable() override;
    void onDisable() override;
    bool isOnTeam(class Actor* actor);
};