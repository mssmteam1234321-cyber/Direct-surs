#pragma once
#include <memory>
#include <Features/Modules/Module.hpp>
#include "HudEditor.hpp"

class KeyBinds : public ModuleBase<KeyBinds> {
public:
    KeyBinds()
    : ModuleBase("KeyBinds", "Показывает включенные бинды", ModuleCategory::Visual, 0, false)
    {
        mNames = {
            {Lowercase, "keybinds"},
            {LowercaseSpaced, "key binds"},
            {Normal, "KeyBinds"},
            {NormalSpaced, "Key Binds"}
        };
        mElement = std::make_unique<HudElement>();
        mElement->mPos = { 100, 160 };
        const char* ModuleBaseType = ModuleBase<KeyBinds>::getTypeID();
        mElement->mParentTypeIdentifier = const_cast<char*>(ModuleBaseType);
        HudEditor::gInstance->registerElement(mElement.get());
    }
    std::unique_ptr<HudElement> mElement;
    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(class RenderEvent& event);
};
