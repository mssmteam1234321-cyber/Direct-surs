#pragma once





class Glint : public ModuleBase<Glint>
{
public:
    NumberSetting mSaturation = NumberSetting("Насыщенность", "Насыщенность блеска", 1, 0, 1, 0.01f);

    Glint() : ModuleBase("Glint", "Делает блеск предметов более заметным", ModuleCategory::Visual, 0, false) {
        addSetting(&mSaturation);

        mNames = {
            {Lowercase, "glint"},
            {LowercaseSpaced, "glint"},
            {Normal, "Glint"},
            {NormalSpaced, "Glint"}
        };

    }

    void onEnable() override;
    void onDisable() override;
    void onRenderItemInHandDescriptionEvent(class RenderItemInHandDescriptionEvent& event);
};