#pragma once




#include <Features/FeatureManager.hpp>
#include <Features/Events/NotifyEvent.hpp>
#include <Features/Modules/Module.hpp>


class NotificationsMod : public ModuleBase<NotificationsMod> {
public:
    enum class Style {
        Solaris,
    };
    EnumSettingT<Style> mStyle = EnumSettingT<Style>("Стиль", "Стиль уведомлений", Style::Solaris, "Solaris");
    BoolSetting mShowOnToggle = BoolSetting("При переключении", "Показывать уведомление при переключении модуля", true);
    BoolSetting mShowOnJoin = BoolSetting("При входе", "Показывать уведомление при входе на сервер", true);
    BoolSetting mColorGradient = BoolSetting("Градиент", "Включить цветовой градиент для уведомлений", false);
    BoolSetting mLimitNotifications = BoolSetting("Лимит уведомлений", "Ограничить количество уведомлений", false);
    NumberSetting mMaxNotifications = NumberSetting("Макс. уведомлений", "Максимальное количество уведомлений", 6, 1, 25, 1);


    NotificationsMod() : ModuleBase("Notifications", "Показывает уведомления при переключении модулей и других событиях", ModuleCategory::Visual, 0, true) {
        addSetting(&mStyle);
        addSetting(&mShowOnToggle);
        addSetting(&mShowOnJoin);
        
        addSetting(&mLimitNotifications);
        addSetting(&mMaxNotifications);
        VISIBILITY_CONDITION(mMaxNotifications, mLimitNotifications.mValue == true);

        mNames = {
            {Lowercase, "notifications"},
            {LowercaseSpaced, "notifications"},
            {Normal, "Notifications"},
            {NormalSpaced, "Notifications"}
        };

        gFeatureManager->mDispatcher->listen<RenderEvent, &NotificationsMod::onRenderEvent, nes::event_priority::VERY_LAST>(this);
    }

    std::vector<Notification> mNotifications;

    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(class RenderEvent& event);
    void onModuleStateChange(ModuleStateChangeEvent& event);
    void onConnectionRequestEvent(class ConnectionRequestEvent& event);
    void onNotifyEvent(class NotifyEvent& event);

    std::string getSettingDisplay() override {
        return mStyle.mValues[mStyle.as<int>()];
    }
};
