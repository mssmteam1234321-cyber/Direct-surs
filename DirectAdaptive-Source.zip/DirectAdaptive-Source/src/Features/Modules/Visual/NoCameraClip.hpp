#pragma once




#include <Features/Modules/Module.hpp>

class CameraComponent; 

class NoCameraClip : public ModuleBase<NoCameraClip> {
public:
    NoCameraClip() : ModuleBase<NoCameraClip>("NoCameraClip", "Отключает клипинг камеры (спасибо ASM лол)", ModuleCategory::Visual, 0, false) {
        mNames = {
            {Lowercase, "nocameraclip"},
            {LowercaseSpaced, "no camera clip"},
            {Normal, "NoCameraClip"},
            {NormalSpaced, "No Camera Clip"}
        };
    }

    void onEnable() override;
    void onDisable() override;
};