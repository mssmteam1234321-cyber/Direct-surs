#pragma once

#include <Features/Modules/Module.hpp>
#include <Utils/Structs.hpp>
#include <vector>




class JumpCircles : public ModuleBase<JumpCircles>
{
public:

    struct Circle {
        glm::vec3 position;
        float radius;
        ImVec4 color;
        float glowAmount;
        float opacity;
        uint64_t startTime;
    };

    NumberSetting mSize = NumberSetting("Скорость", "Как быстро будут проигрываться анимации", 0.02f, 0.01f, 0.20f, 0.01f);
    NumberSetting mGlowAmount = NumberSetting("Свечение", "Сила свечения круга", 24, 0, 100, 1);
    NumberSetting mOpacity = NumberSetting("Прозрачность", "Прозрачность круга", 0.6f, 0.f, 1.f, 0.01f);
    NumberSetting mTime = NumberSetting("Время жизни (мс)", "Время отображения круга", 9000, 0, 5000, 1);

    JumpCircles() : ModuleBase("JumpCircles", "Рисует круги при прыжке", ModuleCategory::Visual, 0, false) {

        addSetting(&mSize);
        addSetting(&mGlowAmount);
        addSetting(&mOpacity);
        addSetting(&mTime);

        mNames = {
            {Lowercase, "jumpcircles"},
            {LowercaseSpaced, "jump circles"},
            {Normal, "JumpCircles"},
            {NormalSpaced, "Jump Circles"}
        };
    }

    std::vector<Circle> circles;
    int mTicks = 0;
    uint64_t lastAddTime = 0;
    float ringSpacing = 0.08; 

    float toRadians(float deg);
    void addCircle(const glm::vec3& pos, float radius, const ImVec4& color, float opacity, float glowAmount);

    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(class RenderEvent& event);
};
