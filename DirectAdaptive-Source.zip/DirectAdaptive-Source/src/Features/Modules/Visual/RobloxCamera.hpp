#pragma once




#include <Features/Modules/Module.hpp>
#include <Features/Events/BaseTickEvent.hpp>

class RobloxCamera : public ModuleBase<RobloxCamera> {
public:
    NumberSetting mRadius = NumberSetting("Радиус", "Радиус камеры", 4.0f, 1.0f, 20.0f, 1.0f);
    BoolSetting mScroll = BoolSetting("Скролл", "Приближение/отдаление скроллом (с Ctrl)", true);
    NumberSetting mScrollIncrement = NumberSetting("Шаг скролла", "Насколько приближать/отдалять", 1.0f, 0.1f, 10.0f, 0.1f);
    BoolSetting mNoClip = BoolSetting("Без клипинга", "Камера проходит сквозь блоки", false);

    RobloxCamera() : ModuleBase("RobloxCamera", "Изменяет камеру, как в Roblox", ModuleCategory::Visual, 0, false) {
        addSetting(&mRadius);
        addSetting(&mScroll);
        addSetting(&mScrollIncrement);
        addSetting(&mNoClip);

        VISIBILITY_CONDITION(mScrollIncrement, mScroll.mValue);

        mNames = {
            {Lowercase, "robloxcamera"},
            {LowercaseSpaced, "roblox camera"},
            {Normal, "RobloxCamera"},
            {NormalSpaced, "Roblox Camera"}
        };

        gFeatureManager->mDispatcher->listen<BaseTickInitEvent, &RobloxCamera::onBaseTickInitEvent>(this);
        gFeatureManager->mDispatcher->listen<ModuleStateChangeEvent, &RobloxCamera::onModuleStateChangeEvent>(this);
    }

    void onModuleStateChangeEvent(ModuleStateChangeEvent& event);

    void onBaseTickInitEvent(BaseTickInitEvent& event);

    bool mHasComponents = false;
    float mCurrentDistance = 4.f;

    void onEnable() override;
    void onDisable() override;
    void onActorRenderEvent(class ActorRenderEvent& event);
    void onMouseEvent(class MouseEvent& event);
    void onBaseTickEvent(class BaseTickEvent& event);
    void onLookInputEvent(class LookInputEvent& event);
};