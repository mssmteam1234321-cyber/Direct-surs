#pragma once
#include <Features/Events/ActorRenderEvent.hpp>
#include <Features/Events/BaseTickEvent.hpp>
#include <Features/Events/ModuleStateChangeEvent.hpp>
#include <Features/Events/DrawImageEvent.hpp>
#include <Features/Events/PreGameCheckEvent.hpp>





class Interface : public ModuleBase<Interface>
{
public:
    enum class UiTheme {
        Dark,
        Light
    };

    enum ColorTheme {
        Everlast,
        Sunset,
        Ocean,
        Aurora,
        Inferno,
        Glacier,
        Pink,
        Crimson,
        Sapphire,
        Sky,
        Violet,
        Amber,
        Snow,
        Emerald,
        Rainbow,
        Custom
    };

    enum class FontType {
        Mojangles,
        ProductSans,
        OpenSans,
        Comfortaa,
        SFProDisplay
    };

    EnumSettingT<NamingStyle> mNamingStyle = EnumSettingT<NamingStyle>("Стиль имени", "Стиль отображения названия модулей.", NamingStyle::NormalSpaced, "строчные", "строчные с пробелом", "Обычный", "С пробелом");
    EnumSettingT<ColorTheme> mMode = EnumSettingT<ColorTheme>("Тема", "Тема интерфейса.", ColorTheme::Everlast, "Everlast", "Закат", "Океан", "Аврора", "Инферно", "Ледник", "Розовый", "Багровый", "Сапфир", "Небо", "Фиолетовый", "Янтарь", "Снег", "Изумруд");
    EnumSettingT<UiTheme> mUiTheme = EnumSettingT<UiTheme>("Стиль UI", "Выбор между светлой и темной темой (бета).", UiTheme::Dark, "Темная", "Светлая");
    EnumSettingT<FontType> mFont = EnumSettingT<FontType>("Шрифт", "Шрифт интерфейса.", FontType::SFProDisplay, "Mojangles", "Product Sans", "Open Sans", "Comfortaa", "SF Pro Display");
    NumberSetting mColorSpeed = NumberSetting("Скорость цвета", "Скорость смены цветов.", 3.00f, 0.01f, 20.f, 0.01);
    NumberSetting mSaturation = NumberSetting("Насыщенность", "Насыщенность интерфейса.", 1.00f, 0.f, 1.f, 0.01);
    BoolSetting mSlotEasing = BoolSetting("Плавность слотов", "Плавное переключение слотов", true);
    NumberSetting mColors = NumberSetting("Количество цветов", "Количество цветов в интерфейсе.", 3, 1, 6, 1);
    ColorSetting mColor1 = ColorSetting("Цвет 1", "Первый цвет интерфейса.", 0xFFFF0000);
    ColorSetting mColor2 = ColorSetting("Цвет 2", "Второй цвет интерфейса.", 0xFFFF7F00);
    ColorSetting mColor3 = ColorSetting("Цвет 3", "Третий цвет интерфейса.", 0xFFFFD600);
    ColorSetting mColor4 = ColorSetting("Цвет 4", "Четвёртый цвет интерфейса.", 0xFF00FF00);
    ColorSetting mColor5 = ColorSetting("Цвет 5", "Пятый цвет интерфейса.", 0xFF0000FF);
    ColorSetting mColor6 = ColorSetting("Цвет 6", "Шестой цвет интерфейса.", 0xFF8B00FF);
    BoolSetting mHoveredItem = BoolSetting("Кастомный ховер", "Изменяет вид выделенного предмета.", false);
    NumberSetting mSlotEasingSpeed = NumberSetting("Скорость плавности", "Скорость анимации слотов", 20.f, 0.1f, 20.f, 0.01f);
    


    Interface() : ModuleBase("Interface", "Кастомизация интерфейса!", ModuleCategory::Visual, 0, true) {
        gFeatureManager->mDispatcher->listen<ModuleStateChangeEvent, &Interface::onModuleStateChange, nes::event_priority::FIRST>(this);
        gFeatureManager->mDispatcher->listen<RenderEvent, &Interface::onRenderEvent, nes::event_priority::NORMAL>(this);
        gFeatureManager->mDispatcher->listen<ActorRenderEvent, &Interface::onActorRenderEvent, nes::event_priority::NORMAL>(this);
        gFeatureManager->mDispatcher->listen<BaseTickEvent, &Interface::onBaseTickEvent>(this);
        gFeatureManager->mDispatcher->listen<PacketOutEvent, &Interface::onPacketOutEvent, nes::event_priority::ABSOLUTE_LAST>(this);
        gFeatureManager->mDispatcher->listen<DrawImageEvent, &Interface::onDrawImageEvent>(this);
        gFeatureManager->mDispatcher->listen<PreGameCheckEvent, &Interface::onPregameCheckEvent>(this);

        addSetting(&mMode);
        addSetting(&mUiTheme);

        mNames = {
            {Lowercase, "interface"},
            {LowercaseSpaced, "interface"},
            {Normal, "Interface"},
            {NormalSpaced, "Interface"}
        };
    }

    static inline std::unordered_map<int, std::vector<ImColor>> ColorThemes = {
        {Everlast, {
            ImColor(195, 208, 214, 255),
            ImColor(130, 158, 171, 255),
            ImColor(120, 145, 158, 255),
            ImColor(104, 132, 145, 255),
            ImColor(88, 116, 128, 255),
            ImColor(72, 100, 112, 255)
        }},
        {Sunset, {
            ImColor(204, 147, 147, 255),
            ImColor(168, 110, 110, 255),
            ImColor(145, 84, 84, 255),
            ImColor(245, 174, 174, 255),
            ImColor(220, 150, 150, 255),
            ImColor(56, 33, 33, 255)
        }},
        {Ocean, {
            ImColor(0, 168, 232, 255),
            ImColor(0, 199, 190, 255),
            ImColor(0, 153, 255, 255),
            ImColor(0, 102, 204, 255),
            ImColor(0, 64, 128, 255),
            ImColor(0, 48, 96, 255)
        }},
        {Aurora, {
            ImColor(110, 231, 183, 255),
            ImColor(52, 211, 153, 255),
            ImColor(59, 130, 246, 255),
            ImColor(147, 197, 253, 255),
            ImColor(196, 181, 253, 255),
            ImColor(100, 100, 255, 255)
        }},
        {Inferno, {
            ImColor(255, 71, 87, 255),
            ImColor(255, 107, 53, 255),
            ImColor(255, 159, 28, 255),
            ImColor(255, 94, 0, 255),
            ImColor(191, 54, 12, 255),
            ImColor(140, 35, 8, 255)
        }},
        {Glacier, {
            ImColor(125, 211, 252, 255),
            ImColor(59, 130, 246, 255),
            ImColor(29, 78, 216, 255),
            ImColor(165, 243, 252, 255),
            ImColor(103, 232, 249, 255),
            ImColor(82, 186, 225, 255)
        }},
        {Pink, {
            ImColor(255, 105, 180, 255),
            ImColor(255, 140, 198, 255),
            ImColor(255, 182, 193, 255),
            ImColor(255, 212, 218, 255),
            ImColor(255, 166, 192, 255),
            ImColor(255, 130, 172, 255)
        }},
        {Crimson, {
            ImColor(220, 20, 60, 255),
            ImColor(255, 77, 77, 255),
            ImColor(178, 34, 34, 255),
            ImColor(150, 25, 25, 255),
            ImColor(120, 20, 20, 255),
            ImColor(255, 110, 110, 255)
        }},
        {Sapphire, {
            ImColor(13, 71, 161, 255),
            ImColor(25, 118, 210, 255),
            ImColor(66, 165, 245, 255),
            ImColor(100, 181, 246, 255),
            ImColor(33, 150, 243, 255),
            ImColor(21, 101, 192, 255)
        }},
        {Sky, {
            ImColor(0, 191, 255, 255),
            ImColor(135, 206, 250, 255),
            ImColor(30, 144, 255, 255),
            ImColor(70, 130, 180, 255),
            ImColor(176, 196, 222, 255),
            ImColor(0, 105, 148, 255)
        }},
        {Violet, {
            ImColor(138, 43, 226, 255),
            ImColor(160, 102, 255, 255),
            ImColor(218, 166, 255, 255),
            ImColor(186, 85, 211, 255),
            ImColor(147, 112, 219, 255),
            ImColor(106, 90, 205, 255)
        }},
        {Amber, {
            ImColor(255, 191, 0, 255),
            ImColor(255, 140, 0, 255),
            ImColor(255, 165, 0, 255),
            ImColor(255, 215, 0, 255),
            ImColor(255, 180, 0, 255),
            ImColor(255, 130, 0, 255)
        }},
        {Snow, {
            ImColor(255, 255, 255, 255),
            ImColor(237, 237, 237, 255),
            ImColor(220, 220, 220, 255),
            ImColor(200, 200, 200, 255),
            ImColor(180, 180, 180, 255),
            ImColor(160, 160, 160, 255)
        }},
        {Emerald, {
            ImColor(46, 204, 113, 255),
            ImColor(39, 174, 96, 255),
            ImColor(26, 188, 156, 255),
            ImColor(22, 160, 133, 255),
            ImColor(17, 128, 106, 255),
            ImColor(14, 102, 85, 255)
        }}
    };

    std::vector<ImColor> getCustomColors() {
        auto result = std::vector<ImColor>();
        if (mColors.mValue >= 1) result.push_back(mColor1.getAsImColor());
        if (mColors.mValue >= 2) result.push_back(mColor2.getAsImColor());
        if (mColors.mValue >= 3) result.push_back(mColor3.getAsImColor());
        if (mColors.mValue >= 4) result.push_back(mColor4.getAsImColor());
        if (mColors.mValue >= 5) result.push_back(mColor5.getAsImColor());
        if (mColors.mValue >= 6) result.push_back(mColor6.getAsImColor());
        return result;
    }

    static ImColor getBlurBgColor() {
        auto interfaceModule = gFeatureManager->mModuleManager->getModule<Interface>();
        if (interfaceModule) {
            
            if (interfaceModule->mUiTheme.mValue == UiTheme::Light) {
                return ImColor(245, 245, 245, 80);
            }
            else {
                return ImColor(5, 5, 5, 150);
            }
        }
        return ImColor(0, 0, 0, 80);
    }

    static ImColor getSettingBgColor() {
        auto interfaceModule = gFeatureManager->mModuleManager->getModule<Interface>();
        if (interfaceModule) {
            if (interfaceModule->mUiTheme.mValue == UiTheme::Light) {
                return ImColor(240, 240, 240, 80);
            }
            else {
                return ImColor(18, 18, 18, 80);
            }
        }
        return ImColor(25, 25, 25, 80);
    }

    static ImColor getTextColor() {
        auto interfaceModule = gFeatureManager->mModuleManager->getModule<Interface>();
        if (interfaceModule) {
            if (interfaceModule->mUiTheme.mValue == UiTheme::Light) {
                return ImColor(0, 0, 0, 255);
            }
            else {
                return ImColor(255, 255, 255, 255);
            }
        }
        return ImColor(255, 255, 255, 255);
    }

    void onEnable() override;
    void onDisable() override;
    void renderHoverText();
    void onModuleStateChange(ModuleStateChangeEvent& event);
    void onPregameCheckEvent(class PreGameCheckEvent& event);
    void onRenderEvent(class RenderEvent& event);
    void onActorRenderEvent(class ActorRenderEvent& event);
    void onDrawImageEvent(class DrawImageEvent& event);
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);
};

class BodyYaw
{
public:
    static inline float bodyYaw = 0.f;
    static inline glm::vec3 posOld = glm::vec3(0, 0, 0);
    static inline glm::vec3 pos = glm::vec3(0, 0, 0);

    static inline void updateRenderAngles(Actor* plr, float headYaw)
    {
        posOld = pos;
        pos = *plr->getPos();

        float diffX = pos.x - posOld.x;
        float diffZ = pos.z - posOld.z;
        float diff = diffX * diffX + diffZ * diffZ;

        float body = bodyYaw;
        if (diff > 0.0025000002F)
        {
            float anglePosDiff = atan2f(diffZ, diffX) * 180.f / 3.14159265358979323846f - 90.f;
            float degrees = abs(wrapAngleTo180_float(headYaw) - anglePosDiff);
            if (95.f < degrees && degrees < 265.f)
            {
                body = anglePosDiff - 180.f;
            }
            else
            {
                body = anglePosDiff;
            }
        }

        turnBody(body, headYaw);
    };

    static inline void turnBody(float bodyRot, float headYaw)
    {
        float amazingDegreeDiff = wrapAngleTo180_float(bodyRot - bodyYaw);
        bodyYaw += amazingDegreeDiff * 0.3f;
        float bodyDiff = wrapAngleTo180_float(headYaw - bodyYaw);
        if (bodyDiff < -75.f)
            bodyDiff = -75.f;

        if (bodyDiff >= 75.f)
            bodyDiff = 75.f;

        bodyYaw = headYaw - bodyDiff;
        if (bodyDiff * bodyDiff > 2500.f)
        {
            bodyYaw += bodyDiff * 0.2f;
        }
    };

    static inline float wrapAngleTo180_float(float value)
    {
        value = fmodf(value, 360.f);

        if (value >= 180.0F)
        {
            value -= 360.0F;
        }

        if (value < -180.0F)
        {
            value += 360.0F;
        }

        return value;
    };
};
