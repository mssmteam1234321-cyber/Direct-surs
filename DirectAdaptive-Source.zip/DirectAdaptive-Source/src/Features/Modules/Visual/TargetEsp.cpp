#include "TargetEsp.hpp"
#include <Features/Modules/Combat/Aura.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>
#include <Hook/Hooks/RenderHooks/D3DHook.hpp>
#include <SDK/Minecraft/Rendering/GuiData.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>
#include <Utils/MiscUtils/RenderUtils.hpp>
#include <Utils/Resources.hpp>
#include <chrono>

static ID3D11ShaderResourceView* gGlowTex = nullptr;
static int gGlowW = 0, gGlowH = 0;
static ID3D11ShaderResourceView* gDiamondTex = nullptr; 
static int gDiamondW = 0, gDiamondH = 0;
static ID3D11ShaderResourceView* gOrbTex = nullptr; 
static int gOrbW = 0, gOrbH = 0;


static inline void ReleaseTexture(ID3D11ShaderResourceView*& tex)
{
    if (tex)
    {
        tex->Release();
        tex = nullptr;
    }
}

static inline void AddRotatedImage(ImDrawList* dl, ImTextureID tex, ImVec2 center, ImVec2 size, float angle, ImU32 col)
{
    float c = cosf(angle);
    float s = sinf(angle);
    float hx = size.x * 0.5f;
    float hy = size.y * 0.5f;
    ImVec2 pts[4] = {
        {-hx, -hy}, {+hx, -hy}, {+hx, +hy}, {-hx, +hy}
    };
    for (int i = 0; i < 4; ++i)
    {
        float x = pts[i].x, y = pts[i].y;
        pts[i].x = center.x + (x * c - y * s);
        pts[i].y = center.y + (x * s + y * c);
    }
    dl->AddImageQuad(tex,
        pts[0], pts[1], pts[2], pts[3],
        ImVec2(0, 0), ImVec2(1, 0), ImVec2(1, 1), ImVec2(0, 1), col);
}

void TargetEsp::ensureTextureLoaded()
{
    
    D3DHook::loadTextureFromEmbeddedResource("glowes", &gGlowTex, &gGlowW, &gGlowH);
}

void TargetEsp::onEnable()
{
    gFeatureManager->mDispatcher->listen<RenderEvent, &TargetEsp::onRenderEvent>(this);
    ensureTextureLoaded();
    D3DHook::loadTextureFromEmbeddedResource("marker", &gDiamondTex, &gDiamondW, &gDiamondH);
    D3DHook::loadTextureFromEmbeddedResource("krug", &gOrbTex, &gOrbW, &gOrbH);
    mPngAlpha = 0.0f;
    mPendingFadeOut = false;
    mSubscribed = true;
    mWasPngVisible = false;
    mHoldTimeMs = 0.0f;
    
    if (!mWorkerRunning.load()) {
        mWorkerRunning.store(true);
        mPhase.store(0.0f);
        mPulseScale.store(1.0f);
        mWorker = std::thread([this]() {
            using clock = std::chrono::high_resolution_clock;
            auto last = clock::now();
            while (mWorkerRunning.load()) {
                auto now = clock::now();
                std::chrono::duration<float> dt = now - last;
                last = now;

                float speed = mSpeed.mValue; 
                float phase = mPhase.load();
                phase += dt.count() * speed * 2.5f;
                if (phase > 1000.0f) phase = fmodf(phase, 6.2831853f);
                mPhase.store(phase);

                float pulse = 1.0f + 0.10f * sinf(phase * 2.0f);
                mPulseScale.store(pulse);

                std::this_thread::sleep_for(std::chrono::milliseconds(8));
            }
        });
    }
}

void TargetEsp::onDisable()
{
    if (mMode.mValue == Mode::Nursultan || mMode.mValue == Mode::Orb) {
        mPendingFadeOut = true;
        mFadeWorld = mSmoothedWorld;
        mFadeMode = mMode.mValue;
        mWasPngVisible = true;
        mHoldTimeMs = 0.0f;
        return;
    }
    gFeatureManager->mDispatcher->deafen<RenderEvent, &TargetEsp::onRenderEvent>(this);
    mGhostAlpha = 0.0f;
    mHasSmoothed = false;
    mLastTarget = nullptr;

    
    mWorkerRunning.store(false);
    if (mWorker.joinable()) mWorker.join();
    mPulseScale.store(1.0f);
    mPhase.store(0.0f);

    
    
    
}

void TargetEsp::onRenderEvent(RenderEvent&)
{
    auto aura = gFeatureManager->mModuleManager->getModule<Aura>();
    bool auraEnabled = (aura && aura->mEnabled);
    if (!auraEnabled && !mPendingFadeOut) return;
    auto ci = ClientInstance::get();
    if (!ci) return;
    auto player = ci->getLocalPlayer();
    if (!player) return;

    Actor* target = Aura::sTarget;
    bool targetValid = target && target->isValid() && !target->isDead();
    if (!targetValid) {
        mGhostAlpha = MathUtils::lerp(mGhostAlpha, 0.0f, ImGui::GetIO().DeltaTime * 6.0f);
    }

    glm::vec3 pos = glm::vec3(0.0f);
    if (targetValid) {
        glm::vec3 rawPos = *target->getPos();
        float height = target->getAABBShapeComponent() ? target->getAABBShapeComponent()->mHeight : 1.8f;
        rawPos.y += height * 0.5f + mYOffset.mValue - 1.50f;
        if (mLastTarget != target) {
            mSmoothedWorld = rawPos;
            mHasSmoothed = true;
            mLastTarget = target;
            if (mMode.mValue == Mode::Nursultan || mMode.mValue == Mode::Orb) {
                mPngAlpha = 0.0f;
                mWasPngVisible = false;
                mHoldTimeMs = 0.0f;
            }
        }
        if (!mHasSmoothed) {
            mSmoothedWorld = rawPos;
            mHasSmoothed = true;
        }
        else {
            float followSpeed = 10.0f;
            mSmoothedWorld = MathUtils::lerp(mSmoothedWorld, rawPos, ImGui::GetIO().DeltaTime * followSpeed);
        }
        pos = mSmoothedWorld;
    }

    bool isPngMode = (mMode.mValue == Mode::Nursultan || mMode.mValue == Mode::Orb);
    if (isPngMode || mPendingFadeOut) {
        const float dt = ImGui::GetIO().DeltaTime;
        if (targetValid && isPngMode) {
            mFadeWorld = pos;
            mFadeMode = mMode.mValue;
            mPngAlpha = MathUtils::lerp(mPngAlpha, 1.0f, dt * 8.0f);
        } else {
            if (mPendingFadeOut && mWasPngVisible && mHoldTimeMs < mMinShowMs) {
                mPngAlpha = MathUtils::lerp(mPngAlpha, 1.0f, dt * 10.0f);
            } else {
                mPngAlpha = MathUtils::lerp(mPngAlpha, 0.0f, dt * 6.0f);
            }
        }

        if (!ci->getGuiData()) return;
        glm::vec2 sp_png;
        glm::vec3 world_png = (targetValid && isPngMode) ? pos : mFadeWorld;
        if (!RenderUtils::transform.mMatrix.OWorldToScreen(RenderUtils::transform.mOrigin, world_png, sp_png, MathUtils::fov, ci->getGuiData()->mResolution)) {
            if (mPendingFadeOut && (mPngAlpha <= 0.01f) && (!mWasPngVisible || mHoldTimeMs >= mMinShowMs)) {
                gFeatureManager->mDispatcher->deafen<RenderEvent, &TargetEsp::onRenderEvent>(this);
                mSubscribed = false;
                mWorkerRunning.store(false);
                if (mWorker.joinable()) mWorker.join();
                mPulseScale.store(1.0f);
                mPhase.store(0.0f);
                mPendingFadeOut = false;
            }
            return;
        }

        float selfRotate = mPhase.load();
        float base = 64.0f * mScale.mValue;
        float pulse = mPulseScale.load();
        float a = mPngAlpha;
        float smooth = a * a * (3.0f - 2.0f * a);
        float appearScale = 0.85f + 0.15f * smooth;
        ImVec2 size(base * pulse * appearScale, base * pulse * appearScale);
        ImColor themed = mThemeColor.mValue ? ColorUtils::getThemedColor(0) : ImColor(1.0f, 1.0f, 1.0f, 1.0f);
        float baseAlpha = 0.9f;
        themed.Value.w = baseAlpha * MathUtils::clamp(a, 0.0f, 1.0f);
        ImU32 col = ImGui::ColorConvertFloat4ToU32(themed.Value);

        bool drawn = false;
        if (mFadeMode == Mode::Nursultan) {
            D3DHook::loadTextureFromEmbeddedResource("marker", &gDiamondTex, &gDiamondW, &gDiamondH);
            if (gDiamondTex) {
                AddRotatedImage(ImGui::GetBackgroundDrawList(), (ImTextureID)gDiamondTex, ImVec2(sp_png.x, sp_png.y), size, selfRotate, col);
                drawn = true;
            }
        } else if (mFadeMode == Mode::Orb) {
            D3DHook::loadTextureFromEmbeddedResource("krug", &gOrbTex, &gOrbW, &gOrbH);
            if (gOrbTex) {
                AddRotatedImage(ImGui::GetBackgroundDrawList(), (ImTextureID)gOrbTex, ImVec2(sp_png.x, sp_png.y), size, selfRotate, col);
                drawn = true;
            }
        }

        if (mPendingFadeOut) {
            mHoldTimeMs += dt * 1000.0f;
        }

        if (mPendingFadeOut && (mPngAlpha <= 0.01f) && (!mWasPngVisible || mHoldTimeMs >= mMinShowMs)) {
            gFeatureManager->mDispatcher->deafen<RenderEvent, &TargetEsp::onRenderEvent>(this);
            mSubscribed = false;
            mWorkerRunning.store(false);
            if (mWorker.joinable()) mWorker.join();
            mPulseScale.store(1.0f);
            mPhase.store(0.0f);
            mPendingFadeOut = false;
        }
        return;
    }

    if (!targetValid) {
        mHasSmoothed = false;
        mLastTarget = nullptr;
        return;
    }

    glm::vec2 sp;
    if (!ci->getGuiData()) return;
    if (!RenderUtils::transform.mMatrix.OWorldToScreen(RenderUtils::transform.mOrigin, pos, sp, MathUtils::fov, ci->getGuiData()->mResolution)) return;

    if (mMode.mValue == Mode::Ghost)
    {
        ensureTextureLoaded();
        if (!gGlowTex) return;
        static float animTime = 0.0f;
        animTime += ImGui::GetIO().DeltaTime * mSpeed.mValue;
        float t = animTime;

        auto* dl = ImGui::GetBackgroundDrawList();
        const int trailLen = 160;
        const float worldRadius = mRadius.mValue;
        const float speed = 30.0f;
        const float distanceStep = 1.5f;

        glm::vec3 cam = RenderUtils::transform.mOrigin;
        mGhostAlpha = MathUtils::lerp(mGhostAlpha, 1.0f, ImGui::GetIO().DeltaTime * 6.0f);
        for (int i = 0; i < trailLen; ++i)
        {
            double angle = 0.1 * ((t * 1000.0) - i * distanceStep) / speed;
            double s = sin(angle) * worldRadius;
            double c = cos(angle) * worldRadius;

            glm::vec3 points[3] = {
                {pos.x + (float)s, pos.y + (float)c, pos.z - (float)c},
                {pos.x - (float)s, pos.y + (float)s, pos.z - (float)c},
                {pos.x - (float)s, pos.y - (float)s, pos.z + (float)c}
            };

            float progress = (float)i / trailLen;
            float sizeFactor = powf(1.0f - progress, 1.1f);
            for (auto& wp : points)
            {
                glm::vec2 screen;
                if (!RenderUtils::transform.mMatrix.OWorldToScreen(RenderUtils::transform.mOrigin, wp, screen, MathUtils::fov, ClientInstance::get()->getGuiData()->mResolution)) continue;

                double dist = glm::distance(cam, wp);
                float distanceScale = (float)(85.0f / std::max(0.0001, dist));
                float finalSize = distanceScale * sizeFactor * mScale.mValue;

                float rotation = fmodf((float)(t * 200.0 + i * 5.0), 180.0f);
                ImColor themed = mThemeColor.mValue ? ColorUtils::getThemedColor(i * 20) : ImColor(1.0f, 1.0f, 1.0f, 1.0f);
                float tailAlpha = (120.0f / 255.0f) * (1.0f - progress * progress);
                themed.Value.w = MathUtils::clamp(tailAlpha * mGhostAlpha, 0.0f, 1.0f);
                ImU32 col = ImGui::ColorConvertFloat4ToU32(themed.Value);
                AddRotatedImage(dl, (ImTextureID)gGlowTex, ImVec2(screen.x, screen.y), ImVec2(finalSize, finalSize), rotation, col);
            }
        }
        return;
    }

    float selfRotate = mPhase.load();
    float base = 64.0f * mScale.mValue;
    float pulse = mPulseScale.load();
    ImVec2 size(base * pulse, base * pulse);
    ImColor themed = mThemeColor.mValue ? ColorUtils::getThemedColor(0) : ImColor(1.0f, 1.0f, 1.0f, 1.0f);
    themed.Value.w = 0.9f;
    ImU32 col = ImGui::ColorConvertFloat4ToU32(themed.Value);

    if (mMode.mValue == Mode::Nursultan)
    {
        
        D3DHook::loadTextureFromEmbeddedResource("marker", &gDiamondTex, &gDiamondW, &gDiamondH);
        if (!gDiamondTex) return;
        AddRotatedImage(ImGui::GetBackgroundDrawList(), (ImTextureID)gDiamondTex, ImVec2(sp.x, sp.y), size, selfRotate, col);
        return;
    }

    if (mMode.mValue == Mode::Orb)
    {
        
        D3DHook::loadTextureFromEmbeddedResource("krug", &gOrbTex, &gOrbW, &gOrbH);
        if (!gOrbTex) return;
        AddRotatedImage(ImGui::GetBackgroundDrawList(), (ImTextureID)gOrbTex, ImVec2(sp.x, sp.y), size, selfRotate, col);
        return;
    }

    if (mMode.mValue == Mode::Crystal)
    {
        ensureTextureLoaded();
        if (!gGlowTex) return;
        static float animTime = 0.0f;
        animTime += ImGui::GetIO().DeltaTime * mSpeed.mValue;
        float t = animTime;

        auto* dl = ImGui::GetBackgroundDrawList();
        const int trailLen = 120;
        const float worldRadius = mRadius.mValue;
        const float speed = 25.0f;
        const float distanceStep = 2.0f;

        glm::vec3 cam = RenderUtils::transform.mOrigin;
        mGhostAlpha = MathUtils::lerp(mGhostAlpha, 1.0f, ImGui::GetIO().DeltaTime * 6.0f);

        for (int i = 0; i < trailLen; ++i)
        {
            double angle = 0.15 * ((t * 800.0) - i * distanceStep) / speed;
            double s = sin(angle) * worldRadius;
            double c = cos(angle) * worldRadius;

            glm::vec3 points[4] = {
                {pos.x + (float)s, pos.y + (float)c, pos.z - (float)c},
                {pos.x - (float)s, pos.y + (float)s, pos.z - (float)c},
                {pos.x - (float)s, pos.y - (float)s, pos.z + (float)c},
                {pos.x + (float)c, pos.y - (float)c, pos.z + (float)s}
            };

            float progress = (float)i / trailLen;
            float sizeFactor = powf(1.0f - progress, 0.8f);

            for (auto& wp : points)
            {
                glm::vec2 screen;
                if (!RenderUtils::transform.mMatrix.OWorldToScreen(RenderUtils::transform.mOrigin, wp, screen, MathUtils::fov, ClientInstance::get()->getGuiData()->mResolution)) continue;

                double dist = glm::distance(cam, wp);
                float distanceScale = (float)(85.0f / std::max(0.0001, dist));
                float finalSize = distanceScale * sizeFactor * mScale.mValue;

                float rotation = fmodf((float)(t * 150.0 + i * 8.0), 360.0f);
                ImColor themed = mThemeColor.mValue ? ColorUtils::getThemedColor(i * 15) : ImColor(1.0f, 1.0f, 1.0f, 1.0f);
                float tailAlpha = (140.0f / 255.0f) * (1.0f - progress * progress * progress);
                themed.Value.w = MathUtils::clamp(tailAlpha * mGhostAlpha, 0.0f, 1.0f);
                ImU32 col = ImGui::ColorConvertFloat4ToU32(themed.Value);
                AddRotatedImage(dl, (ImTextureID)gGlowTex, ImVec2(screen.x, screen.y), ImVec2(finalSize, finalSize), rotation, col);
            }
        }
        return;
    }

    if (mMode.mValue == Mode::Circle)
    {
        float radius = mRadius.mValue;
        int points = 60;
        float fullHeight = target->getAABBShapeComponent() ? target->getAABBShapeComponent()->mHeight : 1.8f;
        using namespace std::chrono;
        static const int yAnimationMSForward = 1800;
        auto now = duration_cast<milliseconds>(high_resolution_clock::now().time_since_epoch()).count();
        float t = (now % yAnimationMSForward) / (float)yAnimationMSForward;
        float wave = t < 0.5f ? 2.0f * t : 2.0f * (1.0f - t);
        float ease = wave < 0.5f ? 2.0f * wave * wave : 1.0f - powf(-2.0f * wave + 2.0f, 2.0f) / 2.0f;
        float y = fullHeight * 0.5f * ease;
        glm::vec3 center = *target->getPos();
        center.y += y + mYOffset.mValue - 1.50f;
        std::vector<ImVec2> screenPoints;
        std::vector<ImColor> colors;
        for (int i = 0; i <= points; ++i) {
            float angle = (float)i / points * 2.0f * 3.14159265f;
            float x = center.x + sinf(angle) * radius;
            float z = center.z + cosf(angle) * radius;
            glm::vec3 pos = { x, center.y, z };
            glm::vec2 screen;
            if (RenderUtils::transform.mMatrix.OWorldToScreen(RenderUtils::transform.mOrigin, pos, screen, MathUtils::fov, ci->getGuiData()->mResolution)) {
                screenPoints.emplace_back(screen.x, screen.y);
                ImColor color = mThemeColor.mValue ? ColorUtils::getThemedColor((float)i * 6) : ImColor(255, 255, 255);
                color.Value.w = 0.9f;
                colors.push_back(color);
            }
        }
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        glm::vec2 centerScreen2d;
        bool centerOk = RenderUtils::transform.mMatrix.OWorldToScreen(RenderUtils::transform.mOrigin, center, centerScreen2d, MathUtils::fov, ci->getGuiData()->mResolution);
        if (centerOk && screenPoints.size() > 2) {
            std::vector<ImVec2> fanPoints;
            fanPoints.push_back(ImVec2(centerScreen2d.x, centerScreen2d.y));
            for (const auto& pt : screenPoints) fanPoints.push_back(pt);
            ImColor fillCol = colors.empty() ? ImColor(255, 255, 255, 40) : ImColor(colors[0].Value.x, colors[0].Value.y, colors[0].Value.z, 0.18f);
            dl->AddConvexPolyFilled(fanPoints.data(), fanPoints.size(), fillCol);
        }
        if (screenPoints.size() > 2) {
            std::vector<ImVec2> shadowPoints;
            std::vector<ImColor> shadowColors;
            float shadowOffset = 32.0f;
            for (size_t i = 0; i < screenPoints.size(); ++i) {
                shadowPoints.push_back(screenPoints[i]);
                shadowColors.push_back(ImColor(colors[i].Value.x, colors[i].Value.y, colors[i].Value.z, 0.08f));
            }
            for (size_t i = 0; i < screenPoints.size(); ++i) {
                ImVec2 p = screenPoints[i];
                shadowPoints.push_back(ImVec2(p.x, p.y + shadowOffset));
                shadowColors.push_back(ImColor(colors[i].Value.x, colors[i].Value.y, colors[i].Value.z, 0.0f));
            }
            for (size_t i = 0; i + 1 < screenPoints.size(); ++i) {
                ImVec2 a = screenPoints[i];
                ImVec2 b = screenPoints[i + 1];
                ImVec2 a2 = ImVec2(a.x, a.y + shadowOffset);
                ImVec2 b2 = ImVec2(b.x, b.y + shadowOffset);
                ImU32 col1 = ImColor(colors[i].Value.x, colors[i].Value.y, colors[i].Value.z, 0.08f);
                ImU32 col2 = ImColor(colors[i].Value.x, colors[i].Value.y, colors[i].Value.z, 0.0f);
                ImU32 col3 = ImColor(colors[i + 1].Value.x, colors[i + 1].Value.y, colors[i + 1].Value.z, 0.08f);
                ImU32 col4 = ImColor(colors[i + 1].Value.x, colors[i + 1].Value.y, colors[i + 1].Value.z, 0.0f);
                ImVec2 quad[4] = { a, b, b2, a2 };
                ImU32 quadCol[4] = { col1, col3, col4, col2 };
                dl->AddConvexPolyFilled(quad, 4, col1);
            }
        }
        if (screenPoints.size() > 1) {
            dl->AddPolyline(screenPoints.data(), screenPoints.size(), colors[0], false, 2.0f);
        }
        static struct Spark {
            ImVec2 pos;
            ImVec2 vel;
            ImColor color;
            float alpha;
            float life;
        } sparks[64];
        static int sparkCount = 0;
        for (size_t i = 0; i < screenPoints.size(); ++i) {
            if (rand() % 100 < 2 && sparkCount < 64) {
                ImVec2 p = screenPoints[i];
                ImColor c = colors[i];
                sparks[sparkCount++] = { p, ImVec2(0, -0.5f - (rand() % 100) * 0.01f), c, 1.0f, 0.0f };
            }
        }
        for (int i = 0; i < sparkCount; ) {
            sparks[i].pos.x += sparks[i].vel.x;
            sparks[i].pos.y += sparks[i].vel.y;
            sparks[i].alpha -= 0.025f;
            sparks[i].life += 0.016f;
            if (sparks[i].alpha <= 0.01f) {
                sparks[i] = sparks[--sparkCount];
                continue;
            }
            ImColor c = sparks[i].color;
            c.Value.w = sparks[i].alpha * 0.7f;
            dl->AddCircleFilled(sparks[i].pos, 2.0f, c, 8);
            ++i;
        }
        return;
    }
}


