#include "KeyBinds.hpp"

#include <Features/FeatureManager.hpp>
#include <Utils/MiscUtils/ImRenderUtils.hpp>
#include <Utils/Keyboard.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <Utils/FontHelper.hpp>
#include <Features/Modules/Visual/Interface.hpp>
#include <Features/Modules/Visual/ClickGui.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>
#include <Hook/Hooks/RenderHooks/D3DHook.hpp>
#include <unordered_map>
#include <algorithm>
#include <cmath>

static bool gKeyBindsResetVisuals = false;

void KeyBinds::onEnable()
{
    gFeatureManager->mDispatcher->listen<RenderEvent, &KeyBinds::onRenderEvent>(this);
    if (mElement) mElement->mVisible = true;
}

void KeyBinds::onDisable()
{
    gFeatureManager->mDispatcher->deafen<RenderEvent, &KeyBinds::onRenderEvent>(this);
    if (mElement) mElement->mVisible = false;
    gKeyBindsResetVisuals = true;
}

void KeyBinds::onRenderEvent(RenderEvent&)
{
    auto clickGui = gFeatureManager->mModuleManager->getModule<ClickGui>();
    if (clickGui && clickGui->mEnabled) return;
    auto ci = ClientInstance::get();
    if (!ci) return;
    if (ci->getScreenName() != "hud_screen") return;
    struct Row { std::string name; std::string key; };
    std::vector<Row> rows;
    const auto& modules = gFeatureManager->mModuleManager->getModules();
    rows.reserve(modules.size());
    for (const auto& mod : modules)
    {
        if (!mod->mEnabled || mod->mKey == 0) continue;
        
        const std::string name = mod->getName();
        const std::string key = Keyboard::getKey(mod->mKey);
        if (!name.empty() && !key.empty()) {
            rows.push_back(Row{name, key});
        }
    }
    static std::unordered_map<std::string, float> alphaByName;
    static std::unordered_map<std::string, std::string> keyByName;
    static std::unordered_map<std::string, float> slideYByName;
    static std::unordered_map<std::string, float> rowPositionByName;
    static std::vector<std::string> stableOrder;
    static float animatedBgH = 0.0f;
    static float bgAlpha = 0.0f;
    if (gKeyBindsResetVisuals)
    {
        alphaByName.clear();
        keyByName.clear();
        slideYByName.clear();
        rowPositionByName.clear();
        stableOrder.clear();
        animatedBgH = 0.0f;
        bgAlpha = 0.0f;
        gKeyBindsResetVisuals = false;
    }
    const float dt = ImGui::GetIO().DeltaTime > 0.f ? ImGui::GetIO().DeltaTime : 1.0f / 60.0f;
    const float appearSpeed = 50.0f;
    const float disappearSpeed = 25.0f;
    std::unordered_map<std::string, std::string> currentKeys;
    currentKeys.reserve(rows.size());
    std::unordered_map<std::string, bool> present;
    present.reserve(rows.size());
    for (const auto& r : rows) {
        currentKeys[r.name] = r.key;
        present[r.name] = true;
    }
    for (const auto& r : rows)
    {
        if (alphaByName.find(r.name) == alphaByName.end()) {
            alphaByName[r.name] = 0.0f;
            slideYByName[r.name] = 20.0f;
            rowPositionByName[r.name] = 0.0f;
            stableOrder.push_back(r.name);
        }
        keyByName[r.name] = r.key;
    }
    std::vector<std::string> names;
    names.reserve(alphaByName.size());
    for (const auto& kv : alphaByName) names.push_back(kv.first);
    for (const auto& name : names)
    {
        const bool isPresent = present.find(name) != present.end();
        float& alpha = alphaByName[name];
        float& slideY = slideYByName[name];
        const float target = isPresent ? 1.0f : 0.0f;
        const float speed = isPresent ? appearSpeed : disappearSpeed;
        alpha += (target - alpha) * std::clamp(speed * dt, 0.0f, 1.0f);
        alpha = std::clamp(alpha, 0.0f, 1.0f);
        const float slideTarget = isPresent ? 0.0f : slideY;
        const float slideSpeed = 25.0f;
        slideY += (slideTarget - slideY) * std::clamp(slideSpeed * dt, 0.0f, 1.0f);
        slideY = std::clamp(slideY, 0.0f, 20.0f);
        if (!isPresent && alpha <= 0.01f)
        {
            alphaByName.erase(name);
            slideYByName.erase(name);
            rowPositionByName.erase(name);
            keyByName.erase(name);
            auto it = std::find(stableOrder.begin(), stableOrder.end(), name);
            if (it != stableOrder.end()) stableOrder.erase(it);
        }
    }
    const float animLineH = ImGui::GetFont()->CalcTextSizeA(20.f, FLT_MAX, -1, "A").y + 4.f * 2.f;
    int currentRowIndex = 0;
    for (const auto& name : stableOrder)
    {
        auto itAlpha = alphaByName.find(name);
        if (itAlpha == alphaByName.end()) continue;
        if (present.find(name) != present.end())
        {
            float& targetPos = rowPositionByName[name];
            float newTarget = currentRowIndex * animLineH;
            const float posSpeed = 18.0f;
            targetPos += (newTarget - targetPos) * std::clamp(posSpeed * dt, 0.0f, 1.0f);
            currentRowIndex++;
        }
    }
    struct RRow { std::string name; std::string key; float alpha; };
    std::vector<RRow> renderRows;
    renderRows.reserve(rows.size() + alphaByName.size());
    for (const auto& name : stableOrder)
    {
        auto itAlpha = alphaByName.find(name);
        if (itAlpha == alphaByName.end()) continue;
        const float a = itAlpha->second;
        if (present.find(name) != present.end())
        {
            auto itKey = currentKeys.find(name);
            renderRows.push_back({ name, itKey != currentKeys.end() ? itKey->second : std::string("") , a });
        }
        else if (a > 0.01f)
        {
            auto itKey = keyByName.find(name);
            renderRows.push_back({ name, itKey != keyByName.end() ? itKey->second : std::string("") , a });
        }
    }
    if (renderRows.empty() && alphaByName.empty()) {
        if (!(HudEditor::gInstance && HudEditor::gInstance->mEnabled)) {
            return;
        }
        renderRows.push_back({ "No active binds", std::string(""), 1.0f });
    }
    auto daInterface = gFeatureManager->mModuleManager->getModule<Interface>();
    if (!daInterface) return;
    const char* logoPath = "keybindslogo.png";
    ID3D11ShaderResourceView* logoTexture = nullptr;
    int logoWidth = 0, logoHeight = 0;
    if (D3DHook::loadTextureFromEmbeddedResource(logoPath, &logoTexture, &logoWidth, &logoHeight))
    {
        float scale = 1.0f;
        logoWidth = logoWidth > 20 ? static_cast<int>(20 * scale) : logoWidth;
        logoHeight = logoHeight > 20 ? static_cast<int>(20 * scale) : logoHeight;
    }
    FontHelper::Fonts["comfortaa"] ? ImGui::PushFont(FontHelper::Fonts["comfortaa"]) : FontHelper::pushPrefFont(false, false);
    const float titleSize = 22.f;               
    const float textSize = 20.f;                
    const float padX = 8.f;
    const float padY = 2.f;
    const float titlePadY = 4.f;                
    const float rowPadY = 4.f;                  
    const float moduleNameX = 10.f;              
    ImVec2 origin = mElement ? mElement->getPos() : ImVec2(20.f, 120.f);
    const float titleH = ImGui::GetFont()->CalcTextSizeA(titleSize, FLT_MAX, -1, "KeyBinds").y + titlePadY * 2.f;
    const float lineH = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, "A").y + rowPadY * 2.f;
    const float bgW = 180.f;
    int effectiveRowCount = 0;
    for (const auto& r : renderRows) if (r.alpha > 0.95f) effectiveRowCount++;
    float targetBgH = padY + titleH + (lineH * effectiveRowCount) + padY;
    if (animatedBgH <= 0.0f) animatedBgH = targetBgH;
    const float bgAnimSpeed = 25.0f;
    animatedBgH += (targetBgH - animatedBgH) * std::clamp(bgAnimSpeed * dt, 0.0f, 1.0f);
    float bgProgress = targetBgH > 0.01f ? std::clamp(animatedBgH / targetBgH, 0.0f, 1.0f) : 1.0f;
    const bool anyVisible = effectiveRowCount > 0;
    const float bgTarget = anyVisible ? 1.0f : 0.0f;
    const float bgAppearSpeed = 8.0f;
    const float bgDisappearSpeed = 12.0f;
    const float bgSpeed = (bgTarget > bgAlpha) ? bgAppearSpeed : bgDisappearSpeed;
    bgAlpha += (bgTarget - bgAlpha) * std::clamp(bgSpeed * dt, 0.0f, 1.0f);
    bgAlpha = std::clamp(bgAlpha, 0.0f, 1.0f);
    ImVec4 bgRect = ImVec4(origin.x, origin.y, origin.x + bgW, origin.y + animatedBgH);
    ImRenderUtils::addBlur(bgRect, 10.0f, 12.0f, ImGui::GetBackgroundDrawList(), true);
    ImRenderUtils::fillRectangle(bgRect, Interface::getBlurBgColor(), 0.55f * bgAlpha, 12.f);
    if (mElement) mElement->mSize = { bgW, animatedBgH };
    ImVec2 cursor = ImVec2(origin.x + padX, origin.y + padY + titlePadY - 1.f);
    ImColor titleColor = ColorUtils::getThemedColor(0);
    if (logoTexture)
    {
        const ImVec2 logoPos = ImVec2(cursor.x + 2.f, cursor.y + 2.f);
        const ImVec2 logoEndPos = ImVec2(logoPos.x + logoWidth, logoPos.y + logoHeight);
        const ImVec2 logoCenterPos = ImVec2(logoPos.x + logoWidth / 2, logoPos.y + logoHeight / 2);
        ImGui::GetBackgroundDrawList()->AddShadowCircle(logoCenterPos, logoWidth / 2.f * 1.8f, 
            ImColor(titleColor.Value.x, titleColor.Value.y, titleColor.Value.z, 0.25f * bgAlpha), 90, ImVec2(0.f, 0.f), 0, 28);
        ImGui::GetBackgroundDrawList()->AddImage(logoTexture, logoPos, logoEndPos, ImVec2(0, 0), ImVec2(1, 1), titleColor);
        cursor.x += logoWidth + 20.f;
    }
    if (bgProgress >= 0.3f)
    {
        const ImVec2 titlePos = ImVec2(cursor.x, cursor.y);
        ImRenderUtils::drawText(titlePos, "KeyBinds", titleColor, titleSize / 18.0f, 0.9f * bgAlpha, true, 0, ImGui::GetBackgroundDrawList());
    }
    float rowStartY = origin.y + padY + titleH - 2.f;
    cursor.y = rowStartY;

    int colorIndex = 1;
    for (size_t i = 0; i < renderRows.size(); i++)
    {
        const auto& r = renderRows[i];
        const float rowAlpha = r.alpha;
        if (rowAlpha <= 0.01f) continue;
        const float slideOffset = slideYByName.find(r.name) != slideYByName.end() ? slideYByName[r.name] : 0.0f;
        const float rowPosOffset = rowPositionByName.find(r.name) != rowPositionByName.end() ? rowPositionByName[r.name] : 0.0f;
        const float yPos = rowStartY + rowPosOffset + slideOffset + 4.0f;
        const ImVec2 moduleNamePos = ImVec2(origin.x + moduleNameX, yPos);
        ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), textSize, moduleNamePos, 
            ImColor(255, 255, 255, static_cast<int>(230 * rowAlpha)), r.name.c_str());
        const float keyW = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, r.key.c_str()).x;
        const float keyX = (origin.x + bgW) - padX - keyW;
        const ImVec2 keyPos = ImVec2(keyX, yPos);
        const ImColor keyColor = ColorUtils::getThemedColor(colorIndex * 50);
        const float keyAlpha = 0.9f * rowAlpha;
        const ImVec2 keyTextSize = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, r.key.c_str());
        const ImVec2 keyCenterPos = ImVec2(keyPos.x + keyTextSize.x / 2, keyPos.y + keyTextSize.y / 2);
        ImGui::GetBackgroundDrawList()->AddShadowCircle(keyCenterPos, textSize / 2.8f,
            ImColor(keyColor.Value.x, keyColor.Value.y, keyColor.Value.z, 0.45f * rowAlpha), 70, ImVec2(0.f, 0.f), 0, 24);
        ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), textSize, keyPos, 
            ImColor(keyColor.Value.x, keyColor.Value.y, keyColor.Value.z, keyAlpha), r.key.c_str());
        colorIndex++;
    }
    FontHelper::Fonts["comfortaa"] ? ImGui::PopFont() : FontHelper::popPrefFont();
}