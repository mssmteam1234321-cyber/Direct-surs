#pragma once




#include <Features/Events/BaseTickEvent.hpp>

class Nametags : public ModuleBase<Nametags>
{
public:
    enum class Style {
        Solstice
    };

    EnumSettingT<Style> mStyle = EnumSettingT<Style>("Стиль", "Стиль неймтегов.", Style::Solstice, "Solstice");
    BoolSetting mShowFriends = BoolSetting("Друзья", "Показывать неймтеги на друзьях.", true);
    BoolSetting mRenderLocal = BoolSetting("На себе", "Рисовать неймтег на локальном игроке.", false);
    BoolSetting mDistanceScaledFont = BoolSetting("Масштаб от дист.", "Менять размер шрифта в зависимости от дистанции", true);
    BoolSetting mShowIrcUsers = BoolSetting("IRC юзеры", "Показывать пользователей IRC", true);
    NumberSetting mBlurStrength = NumberSetting("Сила размытия", "Сила размытия фона.", 0.f, 0.f, 10.f, 0.1f);
    NumberSetting mFontSize = NumberSetting("Размер шрифта", "Размер шрифта", 23, 1, 40, 0.01);;
    NumberSetting mScalingMultiplier = NumberSetting("Множитель масштаба", "Множитель для масштабирования шрифта", 0, 0.f, 5.f, 0.01f);
    NumberSetting mMinScale = NumberSetting("Мин. масштаб", "Минимальный масштаб шрифта", 20.f, 0.01f, 20.f, 0.01f);
    BoolSetting mShowBps = BoolSetting("Показывать BPS", "Отображать количество блоков в секунду", false);
    BoolSetting mAverageBps = BoolSetting("Средний BPS", "Показывать среднее значение BPS", true);

    Nametags() : ModuleBase("Nametags", "Рисует неймтеги над сущностями", ModuleCategory::Visual, 0, false) {
        addSettings(
            &mStyle,
            &mShowFriends,
            &mRenderLocal,
            
            &mShowIrcUsers,
            &mBlurStrength,
            /*&mFontSize,
            &mScalingMultiplier,
            &mMinScale*/
            &mShowBps,
            &mAverageBps

        );

        VISIBILITY_CONDITION(mFontSize, !mDistanceScaledFont.mValue);
        VISIBILITY_CONDITION(mScalingMultiplier, mDistanceScaledFont.mValue);
        VISIBILITY_CONDITION(mMinScale, mDistanceScaledFont.mValue);
        VISIBILITY_CONDITION(mAverageBps, mShowBps.mValue);

        mNames = {
            {Lowercase, "nametags"},
            {LowercaseSpaced, "nametags"},
            {Normal, "Nametags"},
            {NormalSpaced, "Nametags"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(BaseTickEvent& event);
    void onRenderEvent(class RenderEvent& event);
    void onNametagRenderEvent(class NametagRenderEvent& event);
};