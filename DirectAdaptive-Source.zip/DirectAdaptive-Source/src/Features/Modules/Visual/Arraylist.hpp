#pragma once
#include <Features/Modules/Module.hpp>





class Arraylist : public ModuleBase<Arraylist>
{
public:

    enum class BackgroundStyle {
        Opacity,
        Shadow,
        Both
    };

    enum class Display {
        Outline,
        Bar,
        Split,
        None
    };

    enum class ModuleVisibility {
        All,
        Bound,
    };

    EnumSettingT<BackgroundStyle> mBackground = EnumSettingT("Фон", "Стиль фона", BackgroundStyle::Shadow, "Прозрачность", "Тень", "Оба");
    NumberSetting mBackgroundOpacity = NumberSetting("Прозрачность", "Прозрачность фона", 1.f, 0.0f, 1.f, 0.01f);
    NumberSetting mBackgroundValue = NumberSetting("Яркость фона", "Значение яркости фона", 0.0f, 0.0f, 1.f, 0.01f);
    NumberSetting mBlurStrength = NumberSetting("Сила размытия", "Сила размытия.", 0.f, 0.f, 10.f, 0.1f);
    EnumSettingT<Display> mDisplay = EnumSettingT("Отображение", "Стиль обводки", Display::Split, "Обводка", "Полоска", "Разделитель", "Нет");
    EnumSettingT<ModuleVisibility> mVisibility = EnumSettingT("Видимость", "Видимость модулей", ModuleVisibility::All, "Все", "С биндом");
    BoolSetting mRenderMode = BoolSetting("Показывать режим", "Отображать режим модуля рядом с именем", true);
    BoolSetting mGlow = BoolSetting("Свечение", "Включить свечение", true);
    NumberSetting mGlowStrength = NumberSetting("Сила свечения", "Сила свечения", 1.f, 0.5f, 1.f, 0.1f);
    BoolSetting mBoldText = BoolSetting("Жирный текст", "Делает текст жирным", true);
    NumberSetting mFontSize = NumberSetting("Размер шрифта", "Размер шрифта", 25.f, 10.f, 40.f, 0.01f);

    Arraylist() : ModuleBase("Arraylist", "Отображает список модулей", ModuleCategory::Visual, 0, true) {
        addSettings(
            
            
            
            &mBlurStrength,
            &mDisplay,
            &mVisibility,
            &mRenderMode,
            &mGlow,
            &mGlowStrength
            
            
        );

        mNames = {
            {Lowercase, "arraylist"},
            {LowercaseSpaced, "array list"},
            {Normal, "Arraylist"},
            {NormalSpaced, "Array List"}
        };
    }
    void onEnable() override;
    void onDisable() override;

    void onRenderEvent(class RenderEvent& event);
    std::string getSettingDisplay() override {
          return mDisplay.mValues[mDisplay.as<int>()];
    }
};