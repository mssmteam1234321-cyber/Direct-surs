#pragma once





class ViewModel : public ModuleBase<ViewModel>
{
public:
    NumberSetting mX = NumberSetting("Ось X", "Смещение по X", 0, -4, 4, 0.01);
    NumberSetting mY = NumberSetting("Ось Y", "Смещение по Y", 0, -4, 4, 0.01);
    NumberSetting mZ = NumberSetting("Ось Z", "Смещение по Z", 0, -4, 4, 0.01);

    ViewModel() : ModuleBase("ViewModel", "Изменяет положение рук (viewmodel)", ModuleCategory::Visual, 0, false)
    {
        addSettings(
            &mX,
            &mY,
            &mZ
        );

        mNames = {
            {Lowercase, "viewmodel"},
            {LowercaseSpaced, "view model"},
            {Normal, "ViewModel"},
            {NormalSpaced, "View Model"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onBobHurtEvent(class BobHurtEvent& event);
};