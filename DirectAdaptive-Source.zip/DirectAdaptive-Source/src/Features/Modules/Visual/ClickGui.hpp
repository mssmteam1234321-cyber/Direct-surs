#pragma once





#include <Features/FeatureManager.hpp>
#include <Features/Modules/Setting.hpp>

class ClickGui : public ModuleBase<ClickGui>
{
public:
    enum class ClickGuiStyle {
        Modern,
    };
    enum class ClickGuiAnimation {
        Zoom,
        Bounce
    };
    EnumSettingT<ClickGuiStyle> mStyle = EnumSettingT<ClickGuiStyle>("Стиль", "Стиль ClickGui.", ClickGuiStyle::Modern, "Modern");
    EnumSettingT<ClickGuiAnimation> mAnimation = EnumSettingT<ClickGuiAnimation>("Анимация", "Анимация открытия ClickGui.", ClickGuiAnimation::Bounce, "Зум", "Отскок");
    NumberSetting mBlurStrength = NumberSetting("Сила размытия", "Сила размытия.", 7.f, 0.f, 20.f, 0.1f);
    NumberSetting mEaseSpeed = NumberSetting("Скорость плавности", "Скорость анимации.", 18.f, 5.f, 20.f, 0.1f);
    NumberSetting mMidclickRounding = NumberSetting("Округление ср. клика", "Значение округления при нажатии колесиком мыши на настройку числа.", 1.f, 0.01f, 1.f, 0.01f);

    ClickGui() : ModuleBase("ClickGui", "Настраиваемое меню для включения модулей.", ModuleCategory::Visual, VK_TAB, false) {
        
        gFeatureManager->mDispatcher->listen<RenderEvent, &ClickGui::onRenderEvent, nes::event_priority::LAST>(this);
        gFeatureManager->mDispatcher->listen<WindowResizeEvent, &ClickGui::onWindowResizeEvent>(this);
        addSetting(&mStyle);
        addSetting(&mAnimation);
        addSetting(&mBlurStrength);
        
        addSetting(&mMidclickRounding);

        mNames = {
            {Lowercase, "clickgui"},
            {LowercaseSpaced, "click gui"},
            {Normal, "ClickGui"},
            {NormalSpaced, "Click Gui"}
        };
    }

    void onEnable() override;
    void onDisable() override;

    void onWindowResizeEvent(class WindowResizeEvent& event);
    void onMouseEvent(class MouseEvent& event);
    void onKeyEvent(class KeyEvent& event);
    float getEaseAnim(EasingUtil ease, int mode);
    void onRenderEvent(class RenderEvent& event);

    std::string getSettingDisplay() override {
        return mStyle.mValues[mStyle.as<int>()];
    }
};
