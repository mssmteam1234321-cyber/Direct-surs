#include "HUD.hpp"

#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>
#include <SDK/Minecraft/World/Level.hpp>
#include <Hook/Hooks/RenderHooks/D3DHook.hpp>
#include <Features/Events/RenderEvent.hpp>
#include <Features/Events/PacketInEvent.hpp>
#include <Features/Events/ChatEvent.hpp>
#include <Features/Modules/Visual/Interface.hpp>
#include <Utils/FontHelper.hpp>
#include <Utils/MiscUtils/ImRenderUtils.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>
#include <Features/Modules/Visual/ClickGui.hpp>
#include <Features/Modules/Misc/Friends.hpp>
#include <Features/Modules/Misc/AntiBot.hpp>
#include <Features/Modules/Combat/Aura.hpp>
#include <Utils/GameUtils/ChatUtils.hpp>
#include <Utils/FileUtils.hpp>
#include <Utils/MiscUtils/EasingUtil.hpp>
#include <Utils/MiscUtils/D2D.hpp>

#include <format>
#include <algorithm>
#include <fstream>
#include <ranges>
#include <nlohmann/json.hpp>


static std::string GetEffectNameEnglish(EffectType type, int amplifier) {
    std::string base;
    switch (type) {
    case EffectType::Speed:           base = "Speed"; break;
    case EffectType::Slowness:        base = "Slowness"; break;
    case EffectType::Haste:           base = "Haste"; break;
    case EffectType::MiningFatigue:   base = "Mining Fatigue"; break;
    case EffectType::Strength:        base = "Strength"; break;
    case EffectType::InstantHealth:   base = "Instant Health"; break;
    case EffectType::InstantDamage:   base = "Instant Damage"; break;
    case EffectType::JumpBoost:       base = "Jump Boost"; break;
    case EffectType::Regeneration:    base = "Regeneration"; break;
    case EffectType::Resistance:      base = "Resistance"; break;
    case EffectType::FireResistance:  base = "Fire Resistance"; break;
    case EffectType::WaterBreathing:  base = "Water Breathing"; break;
    case EffectType::Invisibility:    base = "Invisibility"; break;
    case EffectType::NightVision:     base = "Night Vision"; break;
    case EffectType::Hunger:          base = "Hunger"; break;
    case EffectType::Weakness:        base = "Weakness"; break;
    case EffectType::Poison:          base = "Poison"; break;
    case EffectType::Wither:          base = "Wither"; break;
    case EffectType::Absorption:      base = "Absorption"; break;
    case EffectType::SlowFalling:     base = "Slow Falling"; break;
    case EffectType::ConduitPower:    base = "Conduit Power"; break;
    default:
        base = std::format("Effect {}", static_cast<int>(type));
        break;
    }

    int level = amplifier + 1;
    if (level > 1) {
        base += " " + std::to_string(level);
    }
    return base;
}

static std::string GetEffectTextureName(EffectType type) {
    switch (type) {
    case EffectType::Speed:           return "Speed";
    case EffectType::Slowness:        return "Slowness";
    case EffectType::Haste:           return "Haste";
    case EffectType::MiningFatigue:   return "MiningFatigue";
    case EffectType::Strength:        return "Strength";
    case EffectType::InstantHealth:   return "HealthBoost";
    case EffectType::InstantDamage:   return "Harming";
    case EffectType::JumpBoost:       return "JumpBoost";
    case EffectType::Regeneration:    return "Regeneration";
    case EffectType::Resistance:      return "Resistance";
    case EffectType::FireResistance:  return "FireResistance";
    case EffectType::WaterBreathing:  return "WaterBreathing";
    case EffectType::Invisibility:    return "Invisibility";
    case EffectType::NightVision:     return "NightVision";
    case EffectType::Hunger:          return "Hunger";
    case EffectType::Weakness:        return "Weakness";
    case EffectType::Poison:          return "Poison";
    case EffectType::Wither:          return "Wither";
    case EffectType::Absorption:      return "Absorption";
    case EffectType::SlowFalling:     return "SlowFalling";
    default: return "";
    }
}


static bool gPotionsResetVisuals = false;
static bool gLocalPlayersResetVisuals = false;
static bool gStaffListResetVisuals = false;

void HUD::initElements() {
    
    mPotionsElement = std::make_unique<HudElement>();
    mPotionsElement->mPos = { 10, 380 };
    mPotionsElement->mAnchor = HudElement::Anchor::TopLeft;
    mPotionsElement->mParentTypeIdentifier = const_cast<char*>("HUD_Potions");
    mPotionsElement->mSize = glm::vec2(220, 40);
    HudEditor::gInstance->registerElement(mPotionsElement.get());

    
    mLocalPlayersElement = std::make_unique<HudElement>();
    mLocalPlayersElement->mPos = { 10, 120 };
    mLocalPlayersElement->mAnchor = HudElement::Anchor::TopLeft;
    mLocalPlayersElement->mParentTypeIdentifier = const_cast<char*>("HUD_LocalPlayers");
    mLocalPlayersElement->mSize = glm::vec2(220, 40);
    HudEditor::gInstance->registerElement(mLocalPlayersElement.get());

    
    mStaffListElement = std::make_unique<HudElement>();
    mStaffListElement->mPos = { 10, 250 };
    mStaffListElement->mAnchor = HudElement::Anchor::TopLeft;
    mStaffListElement->mParentTypeIdentifier = const_cast<char*>("HUD_StaffList");
    mStaffListElement->mSize = glm::vec2(220, 40);
    HudEditor::gInstance->registerElement(mStaffListElement.get());
}

void HUD::onEnable() {
    gFeatureManager->mDispatcher->listen<BaseTickEvent, &HUD::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->listen<RenderEvent, &HUD::onRenderEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketInEvent, &HUD::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->listen<ChatEvent, &HUD::onChatEvent>(this);
    
    if (mPotionsElement) mPotionsElement->mVisible = mPotionsEnabled.mValue;
    if (mLocalPlayersElement) mLocalPlayersElement->mVisible = mLocalPlayersEnabled.mValue;
    if (mStaffListElement) mStaffListElement->mVisible = mStaffListEnabled.mValue;

    loadStaffList();
}

void HUD::onDisable() {
    gFeatureManager->mDispatcher->deafen<BaseTickEvent, &HUD::onBaseTickEvent>(this);
    gFeatureManager->mDispatcher->deafen<RenderEvent, &HUD::onRenderEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketInEvent, &HUD::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->deafen<ChatEvent, &HUD::onChatEvent>(this);

    if (mPotionsElement) mPotionsElement->mVisible = false;
    if (mLocalPlayersElement) mLocalPlayersElement->mVisible = false;
    if (mStaffListElement) mStaffListElement->mVisible = false;

    mEffects.clear();
    mNearbyPlayers.clear();
    
    gPotionsResetVisuals = true;
    gLocalPlayersResetVisuals = true;
    gStaffListResetVisuals = true;
}

void HUD::onBaseTickEvent(class BaseTickEvent& event) {
    
    uint64_t now = NOW;
    for (auto it = mEffects.begin(); it != mEffects.end();) {
        if (!it->second.infinite && it->second.endTime != 0 && now > it->second.endTime) {
            it = mEffects.erase(it);
        }
        else {
            ++it;
        }
    }

    
    updateNearbyPlayers();

    
    updateOnlineStaff();

    
    if (mPotionsElement) mPotionsElement->mVisible = mPotionsEnabled.mValue;
    if (mLocalPlayersElement) mLocalPlayersElement->mVisible = mLocalPlayersEnabled.mValue;
    if (mStaffListElement) mStaffListElement->mVisible = mStaffListEnabled.mValue;
}

void HUD::onRenderEvent(class RenderEvent& event) {
    if (mPotionsEnabled.mValue) renderPotions(event);
    if (mLocalPlayersEnabled.mValue) renderLocalPlayers(event);
    if (mStaffListEnabled.mValue) renderStaffList(event);
}

void HUD::onPacketInEvent(class PacketInEvent& event) {
    if (!event.mPacket || event.mPacket->getId() != PacketID::MobEffect) return;

    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) return;

    auto mep = event.getPacket<MobEffectPacket>();
    if (!mep) return;

    if (mep->mRuntimeId != player->getRuntimeID()) return;

    uint64_t now = NOW;
    bool infinite = false;
    uint64_t endTime = 0;

    if (mep->mEffectDurationTicks <= 0) {
        infinite = true;
    }
    else {
        endTime = now + static_cast<uint64_t>(mep->mEffectDurationTicks) * 50ull;
    }

    if (mep->mEventId == MobEffectPacket::Event::Add ||
        mep->mEventId == MobEffectPacket::Event::Update) {
        ActiveEffect eff{ static_cast<EffectType>(mep->mEffectId), mep->mEffectAmplifier, endTime, infinite };
        mEffects[static_cast<int>(mep->mEffectId)] = eff;
    }
    else if (mep->mEventId == MobEffectPacket::Event::Remove) {
        mEffects.erase(static_cast<int>(mep->mEffectId));
    }
}


void HUD::renderPotions(class RenderEvent& event) {
    auto clickGui = gFeatureManager->mModuleManager->getModule<ClickGui>();
    if (clickGui && clickGui->mEnabled) return;
    auto ci = ClientInstance::get();
    if (!ci) return;
    if (ci->getScreenName() != "hud_screen" && ci->getScreenName() != "chat_screen") return;
    if (!mPotionsElement) return;

    struct Row { std::string name; std::string time; std::string textureName; };
    std::vector<Row> rows;

    for (const auto& [id, eff] : mEffects) {
        std::string name = GetEffectNameEnglish(eff.type, eff.amplifier);
        std::string timerText;
        if (eff.infinite) {
            timerText = "∞";
        }
        else if (eff.endTime == 0) {
            timerText = "0:00";
        }
        else {
            uint64_t now = NOW;
            uint64_t remainingMs = (eff.endTime > now) ? (eff.endTime - now) : 0;
            int totalSec = static_cast<int>(remainingMs / 1000ull);
            int minutes = totalSec / 60;
            int seconds = totalSec % 60;
            timerText = std::format("{}:{:02}", minutes, seconds);
        }
        rows.push_back({ name, timerText, GetEffectTextureName(eff.type) });
    }

    static std::unordered_map<std::string, float> alphaByName;
    static std::unordered_map<std::string, std::string> timeByName;
    static std::unordered_map<std::string, std::string> textureByName;
    static std::unordered_map<std::string, float> slideYByName;
    static std::unordered_map<std::string, float> rowPositionByName;
    static std::vector<std::string> stableOrder;
    static float animatedBgH = 0.0f;
    static float bgAlpha = 0.0f;

    if (gPotionsResetVisuals) {
        alphaByName.clear(); timeByName.clear(); textureByName.clear(); slideYByName.clear(); rowPositionByName.clear(); stableOrder.clear(); animatedBgH = 0.0f; bgAlpha = 0.0f; gPotionsResetVisuals = false;
    }

    const float dt = ImGui::GetIO().DeltaTime > 0.f ? ImGui::GetIO().DeltaTime : 1.0f / 60.0f;
    const float appearSpeed = 50.0f;
    const float disappearSpeed = 25.0f;

    std::unordered_map<std::string, std::string> currentTimes;
    std::unordered_map<std::string, std::string> currentTextures;
    std::unordered_map<std::string, bool> present;

    for (const auto& r : rows) {
        currentTimes[r.name] = r.time;
        currentTextures[r.name] = r.textureName;
        present[r.name] = true;
    }

    for (const auto& r : rows) {
        if (alphaByName.find(r.name) == alphaByName.end()) {
            alphaByName[r.name] = 0.0f;
            slideYByName[r.name] = 20.0f;
            rowPositionByName[r.name] = 0.0f;
            stableOrder.push_back(r.name);
        }
        timeByName[r.name] = r.time;
        textureByName[r.name] = r.textureName;
    }

    std::vector<std::string> names;
    for (const auto& kv : alphaByName) names.push_back(kv.first);

    for (const auto& name : names) {
        const bool isPresent = present.find(name) != present.end();
        float& alpha = alphaByName[name];
        float& slideY = slideYByName[name];
        const float target = isPresent ? 1.0f : 0.0f;
        const float speed = isPresent ? appearSpeed : disappearSpeed;
        alpha += (target - alpha) * std::clamp(speed * dt, 0.0f, 1.0f);
        alpha = std::clamp(alpha, 0.0f, 1.0f);
        const float slideTarget = isPresent ? 0.0f : slideY;
        const float slideSpeed = 25.0f;
        slideY += (slideTarget - slideY) * std::clamp(slideSpeed * dt, 0.0f, 1.0f);
        slideY = std::clamp(slideY, 0.0f, 20.0f);

        if (!isPresent && alpha <= 0.01f) {
            alphaByName.erase(name); slideYByName.erase(name); rowPositionByName.erase(name); timeByName.erase(name); textureByName.erase(name);
            auto it = std::find(stableOrder.begin(), stableOrder.end(), name);
            if (it != stableOrder.end()) stableOrder.erase(it);
        }
    }

    const float animLineH = ImGui::GetFont()->CalcTextSizeA(20.f, FLT_MAX, -1, "A").y + 4.f * 2.f;
    int currentRowIndex = 0;
    for (const auto& name : stableOrder) {
        auto itAlpha = alphaByName.find(name);
        if (itAlpha == alphaByName.end()) continue;
        if (present.find(name) != present.end()) {
            float& targetPos = rowPositionByName[name];
            float newTarget = currentRowIndex * animLineH;
            targetPos += (newTarget - targetPos) * std::clamp(18.0f * dt, 0.0f, 1.0f);
            currentRowIndex++;
        }
    }

    struct RRow { std::string name; std::string time; std::string texture; float alpha; };
    std::vector<RRow> renderRows;
    for (const auto& name : stableOrder) {
        auto itAlpha = alphaByName.find(name);
        if (itAlpha == alphaByName.end()) continue;
        const float a = itAlpha->second;
        if (present.find(name) != present.end()) {
            renderRows.push_back({ name, currentTimes[name], currentTextures[name], a });
        }
        else if (a > 0.01f) {
            renderRows.push_back({ name, timeByName[name], textureByName[name], a });
        }
    }

    if (renderRows.empty() && alphaByName.empty()) {
        if (!(HudEditor::gInstance && HudEditor::gInstance->mEnabled)) {
            mPotionsElement->mSize = { 0,0 };
            return;
        }
        renderRows.push_back({ "No Active Potions", "", "", 1.0f });
    }

    FontHelper::Fonts["comfortaa"] ? ImGui::PushFont(FontHelper::Fonts["comfortaa"]) : FontHelper::pushPrefFont(false, false);
    const float titleSize = 22.f * mPotionsScale.mValue;
    const float textSize = 20.f * mPotionsScale.mValue;
    const float padX = 8.f;
    const float padY = 2.f;
    const float titlePadY = 4.f;
    const float rowPadY = 4.f;
    const float moduleNameX = 10.f;
    ImVec2 origin = mPotionsElement->getPos();

    const float titleH = ImGui::GetFont()->CalcTextSizeA(titleSize, FLT_MAX, -1, "Potions").y + titlePadY * 2.f;
    const float lineH = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, "A").y + rowPadY * 2.f;
    const float bgW = 200.f * mPotionsScale.mValue;

    int effectiveRowCount = 0;
    for (const auto& r : renderRows) if (r.alpha > 0.05f) effectiveRowCount++;
    float targetBgH = padY + titleH + (lineH * effectiveRowCount) + padY;

    if (animatedBgH <= 0.0f) animatedBgH = targetBgH;
    animatedBgH += (targetBgH - animatedBgH) * std::clamp(25.0f * dt, 0.0f, 1.0f);
    float bgProgress = targetBgH > 0.01f ? std::clamp(animatedBgH / targetBgH, 0.0f, 1.0f) : 1.0f;

    const bool anyVisible = effectiveRowCount > 0;
    const float bgTarget = anyVisible ? 1.0f : 0.0f;
    const float bgSpeed = (bgTarget > bgAlpha) ? 8.0f : 12.0f;
    bgAlpha += (bgTarget - bgAlpha) * std::clamp(bgSpeed * dt, 0.0f, 1.0f);
    bgAlpha = std::clamp(bgAlpha, 0.0f, 1.0f);

    ImVec4 bgRect = ImVec4(origin.x, origin.y, origin.x + bgW, origin.y + animatedBgH);
    ImRenderUtils::addBlur(bgRect, 10.0f, 12.0f, ImGui::GetBackgroundDrawList(), true);
    ImRenderUtils::fillRectangle(bgRect, Interface::getBlurBgColor(), (mPotionsBgAlpha.mValue / 255.0f) * bgAlpha, mPotionsRounding.mValue);

    mPotionsElement->mSize = { bgW, animatedBgH };

    ImVec2 cursor = ImVec2(origin.x + padX, origin.y + padY + titlePadY - 1.f);

    if (bgProgress >= 0.3f) {
        ImRenderUtils::drawModuleText(ImVec2(cursor.x, cursor.y), "Potions", titleSize / 18.0f, 0.9f * bgAlpha, true, ImGui::GetBackgroundDrawList());
    }

    float rowStartY = origin.y + padY + titleH - 2.f;
    cursor.y = rowStartY;
    int colorIndex = 1;

    for (size_t i = 0; i < renderRows.size(); i++) {
        const auto& r = renderRows[i];
        const float rowAlpha = r.alpha;
        if (rowAlpha <= 0.01f) continue;
        const float slideOffset = slideYByName.find(r.name) != slideYByName.end() ? slideYByName[r.name] : 0.0f;
        const float rowPosOffset = rowPositionByName.find(r.name) != rowPositionByName.end() ? rowPositionByName[r.name] : 0.0f;
        const float yPos = rowStartY + rowPosOffset + slideOffset + 4.0f;

        float currentX = origin.x + moduleNameX;

        if (!r.texture.empty()) {
            ID3D11ShaderResourceView* tex = nullptr;
            int w = 0, h = 0;
            std::string path = FileUtils::getSolsticeDir() + "\\resources\\effects\\" + r.texture + ".png";
            if (D3DHook::createTextureFromFile(path.c_str(), &tex, &w, &h) && tex) {
                float scale = (16.0f * mPotionsScale.mValue) / (float)h;
                float iconW = w * scale;
                float iconH = h * scale;
                ImGui::GetBackgroundDrawList()->AddImage((void*)tex,
                    ImVec2(currentX, yPos + (textSize - iconH) / 2),
                    ImVec2(currentX + iconW, yPos + (textSize - iconH) / 2 + iconH),
                    ImVec2(0, 0), ImVec2(1, 1),
                    ImColor(255, 255, 255, static_cast<int>(255 * rowAlpha)));
                currentX += iconW + 4.0f;
            }
        }

        const ImVec2 moduleNamePos = ImVec2(currentX, yPos);
        ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), textSize, moduleNamePos,
            ImColor(255, 255, 255, static_cast<int>(230 * rowAlpha)), r.name.c_str());

        if (!r.time.empty()) {
            const float keyW = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, r.time.c_str()).x;
            const float keyX = (origin.x + bgW) - padX - keyW;
            const ImVec2 keyPos = ImVec2(keyX, yPos);
            const ImColor keyColor = ColorUtils::getThemedColor(colorIndex * 50);
            const float keyAlpha = 0.9f * rowAlpha;

            const ImVec2 keyTextSize = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, r.time.c_str());
            const ImVec2 keyCenterPos = ImVec2(keyPos.x + keyTextSize.x / 2, keyPos.y + keyTextSize.y / 2);

            ImGui::GetBackgroundDrawList()->AddShadowCircle(keyCenterPos, textSize / 2.8f,
                ImColor(keyColor.Value.x, keyColor.Value.y, keyColor.Value.z, 0.45f * rowAlpha), 70, ImVec2(0.f, 0.f), 0, 24);
            ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), textSize, keyPos,
                ImColor(keyColor.Value.x, keyColor.Value.y, keyColor.Value.z, keyAlpha), r.time.c_str());
        }
        colorIndex++;
    }

    FontHelper::Fonts["comfortaa"] ? ImGui::PopFont() : FontHelper::popPrefFont();
}


void HUD::updateNearbyPlayers() {
    auto localPlayer = ClientInstance::get()->getLocalPlayer();
    if (!localPlayer) return;
    auto actors = ActorUtils::getActorList(false, true);
    auto localPosPtr = localPlayer->getPos();
    if (!localPosPtr) return;
    glm::vec3 localPos = *localPosPtr;
    mNearbyPlayers.clear();
    auto antiBot = gFeatureManager->mModuleManager->getModule<AntiBot>();

    for (auto actor : actors) {
        if (actor == localPlayer) continue;
        if (!actor->isPlayer()) continue;
        if (antiBot && antiBot->mEnabled && antiBot->isBot(actor)) continue;

        auto actorPosPtr = actor->getPos();
        if (!actorPosPtr) continue;
        glm::vec3 actorPos = *actorPosPtr;
        float distance = glm::distance(localPos, actorPos);

        if (distance <= mLocalPlayersMaxDistance.mValue) {
            std::string playerName = actor->getRawName();
            if (gFriendManager->isFriend(actor)) playerName = "[F] " + playerName;
            mNearbyPlayers.emplace_back(playerName, distance);
        }
    }
    std::sort(mNearbyPlayers.begin(), mNearbyPlayers.end(), [](const auto& a, const auto& b) { return a.second < b.second; });
    if (mNearbyPlayers.size() > static_cast<size_t>(mLocalPlayersMaxPlayers.mValue)) {
        mNearbyPlayers.resize(static_cast<size_t>(mLocalPlayersMaxPlayers.mValue));
    }
}

void HUD::renderLocalPlayers(class RenderEvent& event) {
    auto clickGui = gFeatureManager->mModuleManager->getModule<ClickGui>();
    if (clickGui && clickGui->mEnabled) return;
    auto ci = ClientInstance::get();
    if (!ci) return;
    if (ci->getScreenName() != "hud_screen" && ci->getScreenName() != "chat_screen") return;
    if (!mLocalPlayersElement) return;

    struct Row { std::string name; std::string dist; bool isFriend; bool isTarget; };
    std::vector<Row> rows;

    Actor* auraTarget = nullptr;
    std::string auraTargetName;
    if (auto aura = gFeatureManager->mModuleManager->getModule<Aura>()) {
        if (aura->mEnabled && Aura::sHasTarget && Aura::sTarget) {
            auraTarget = Aura::sTarget;
            auraTargetName = auraTarget->getRawName();
        }
    }

    for (const auto& playerData : mNearbyPlayers) {
        std::string name = playerData.first;
        bool isFriend = name.rfind("[F] ", 0) == 0;
        bool isTarget = (!auraTargetName.empty() && name == auraTargetName) || (!auraTargetName.empty() && name == "[F] " + auraTargetName);
        std::string distText;
        if (mLocalPlayersShowDistance.mValue) {
            distText = std::format("{}m", static_cast<int>(playerData.second));
        }
        rows.push_back({ name, distText, isFriend, isTarget });
    }

    static std::unordered_map<std::string, float> alphaByName;
    static std::unordered_map<std::string, std::string> distByName;
    static std::unordered_map<std::string, bool> isFriendByName;
    static std::unordered_map<std::string, bool> isTargetByName;
    static std::unordered_map<std::string, float> slideYByName;
    static std::unordered_map<std::string, float> rowPositionByName;
    static std::vector<std::string> stableOrder;
    static float animatedBgH = 0.0f;
    static float bgAlpha = 0.0f;

    if (gLocalPlayersResetVisuals) {
        alphaByName.clear(); distByName.clear(); slideYByName.clear(); rowPositionByName.clear(); stableOrder.clear(); isFriendByName.clear(); isTargetByName.clear(); animatedBgH = 0.0f; bgAlpha = 0.0f; gLocalPlayersResetVisuals = false;
    }

    const float dt = ImGui::GetIO().DeltaTime > 0.f ? ImGui::GetIO().DeltaTime : 1.0f / 60.0f;
    const float appearSpeed = 50.0f;
    const float disappearSpeed = 25.0f;

    std::unordered_map<std::string, std::string> currentDist;
    std::unordered_map<std::string, bool> currentFriend;
    std::unordered_map<std::string, bool> currentTarget;
    std::unordered_map<std::string, bool> present;

    for (const auto& r : rows) {
        currentDist[r.name] = r.dist;
        currentFriend[r.name] = r.isFriend;
        currentTarget[r.name] = r.isTarget;
        present[r.name] = true;
    }

    for (const auto& r : rows) {
        if (alphaByName.find(r.name) == alphaByName.end()) {
            alphaByName[r.name] = 0.0f;
            slideYByName[r.name] = 20.0f;
            rowPositionByName[r.name] = 0.0f;
            stableOrder.push_back(r.name);
        }
        distByName[r.name] = r.dist;
        isFriendByName[r.name] = r.isFriend;
        isTargetByName[r.name] = r.isTarget;
    }

    std::vector<std::string> names;
    for (const auto& kv : alphaByName) names.push_back(kv.first);

    for (const auto& name : names) {
        const bool isPresent = present.find(name) != present.end();
        float& alpha = alphaByName[name];
        float& slideY = slideYByName[name];
        alpha += ((isPresent ? 1.0f : 0.0f) - alpha) * std::clamp((isPresent ? appearSpeed : disappearSpeed) * dt, 0.0f, 1.0f);
        alpha = std::clamp(alpha, 0.0f, 1.0f);
        slideY += ((isPresent ? 0.0f : slideY) - slideY) * std::clamp(25.0f * dt, 0.0f, 1.0f);
        slideY = std::clamp(slideY, 0.0f, 20.0f);

        if (!isPresent && alpha <= 0.01f) {
            alphaByName.erase(name); slideYByName.erase(name); rowPositionByName.erase(name); distByName.erase(name); isFriendByName.erase(name); isTargetByName.erase(name);
            auto it = std::find(stableOrder.begin(), stableOrder.end(), name);
            if (it != stableOrder.end()) stableOrder.erase(it);
        }
    }

    const float animLineH = ImGui::GetFont()->CalcTextSizeA(20.f, FLT_MAX, -1, "A").y + 4.f * 2.f;
    int currentRowIndex = 0;
    for (const auto& name : stableOrder) {
        auto itAlpha = alphaByName.find(name);
        if (itAlpha == alphaByName.end()) continue;
        if (present.find(name) != present.end()) {
            float& targetPos = rowPositionByName[name];
            float newTarget = currentRowIndex * animLineH;
            targetPos += (newTarget - targetPos) * std::clamp(18.0f * dt, 0.0f, 1.0f);
            currentRowIndex++;
        }
    }

    struct RRow { std::string name; std::string dist; bool isFriend; bool isTarget; float alpha; };
    std::vector<RRow> renderRows;
    for (const auto& name : stableOrder) {
        auto itAlpha = alphaByName.find(name);
        if (itAlpha == alphaByName.end()) continue;
        const float a = itAlpha->second;
        if (present.find(name) != present.end()) {
            renderRows.push_back({ name, currentDist[name], currentFriend[name], currentTarget[name], a });
        }
        else if (a > 0.01f) {
            renderRows.push_back({ name, distByName[name], isFriendByName[name], isTargetByName[name], a });
        }
    }

    if (renderRows.empty() && alphaByName.empty()) {
        if (!(HudEditor::gInstance && HudEditor::gInstance->mEnabled)) {
            mLocalPlayersElement->mSize = { 0,0 };
            return;
        }
        renderRows.push_back({ "No Players Nearby", "", false, false, 1.0f });
    }

    FontHelper::Fonts["comfortaa"] ? ImGui::PushFont(FontHelper::Fonts["comfortaa"]) : FontHelper::pushPrefFont(false, false);
    const float titleSize = 22.f * mLocalPlayersScale.mValue;
    const float textSize = 20.f * mLocalPlayersScale.mValue;
    const float padX = 8.f;
    const float padY = 2.f;
    const float titlePadY = 4.f;
    const float rowPadY = 4.f;
    const float moduleNameX = 10.f;
    ImVec2 origin = mLocalPlayersElement->getPos();

    const float titleH = ImGui::GetFont()->CalcTextSizeA(titleSize, FLT_MAX, -1, "Local Players").y + titlePadY * 2.f;
    const float lineH = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, "A").y + rowPadY * 2.f;
    const float bgW = 220.f * mLocalPlayersScale.mValue;

    int effectiveRowCount = 0;
    for (const auto& r : renderRows) if (r.alpha > 0.05f) effectiveRowCount++;
    float targetBgH = padY + titleH + (lineH * effectiveRowCount) + padY;

    if (animatedBgH <= 0.0f) animatedBgH = targetBgH;
    animatedBgH += (targetBgH - animatedBgH) * std::clamp(25.0f * dt, 0.0f, 1.0f);
    float bgProgress = targetBgH > 0.01f ? std::clamp(animatedBgH / targetBgH, 0.0f, 1.0f) : 1.0f;

    const bool anyVisible = effectiveRowCount > 0;
    const float bgTarget = anyVisible ? 1.0f : 0.0f;
    bgAlpha += (bgTarget - bgAlpha) * std::clamp(8.0f * dt, 0.0f, 1.0f);
    bgAlpha = std::clamp(bgAlpha, 0.0f, 1.0f);

    ImVec4 bgRect = ImVec4(origin.x, origin.y, origin.x + bgW, origin.y + animatedBgH);
    ImRenderUtils::addBlur(bgRect, 10.0f, 12.0f, ImGui::GetBackgroundDrawList(), true);
    ImRenderUtils::fillRectangle(bgRect, Interface::getBlurBgColor(), (mLocalPlayersBgAlpha.mValue / 255.0f) * bgAlpha, mLocalPlayersRounding.mValue);

    mLocalPlayersElement->mSize = { bgW, animatedBgH };

    ImVec2 cursor = ImVec2(origin.x + padX, origin.y + padY + titlePadY - 1.f);
    if (bgProgress >= 0.3f) {
        ImRenderUtils::drawModuleText(ImVec2(cursor.x, cursor.y), "Local Players", titleSize / 18.0f, 0.9f * bgAlpha, true, ImGui::GetBackgroundDrawList());
    }

    float rowStartY = origin.y + padY + titleH - 2.f;
    cursor.y = rowStartY;
    int colorIndex = 1;

    for (size_t i = 0; i < renderRows.size(); i++) {
        const auto& r = renderRows[i];
        if (r.alpha <= 0.01f) continue;
        const float slideOffset = slideYByName.find(r.name) != slideYByName.end() ? slideYByName[r.name] : 0.0f;
        const float rowPosOffset = rowPositionByName.find(r.name) != rowPositionByName.end() ? rowPositionByName[r.name] : 0.0f;
        const float yPos = rowStartY + rowPosOffset + slideOffset + 4.0f;

        const ImVec2 moduleNamePos = ImVec2(origin.x + moduleNameX, yPos);
        ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), textSize, moduleNamePos,
            ImColor(255, 255, 255, static_cast<int>(230 * r.alpha)), r.name.c_str());

        if (!r.dist.empty()) {
            const float keyW = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, r.dist.c_str()).x;
            const float keyX = (origin.x + bgW) - padX - keyW;
            const ImVec2 keyPos = ImVec2(keyX, yPos);
            ImColor keyColor = ColorUtils::getThemedColor(colorIndex * 50);
            if (r.isFriend) keyColor = ImColor(85, 255, 85);
            if (r.isTarget) keyColor = ImColor(255, 60, 60);

            const ImVec2 keyTextSize = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, r.dist.c_str());
            const ImVec2 keyCenterPos = ImVec2(keyPos.x + keyTextSize.x / 2, keyPos.y + keyTextSize.y / 2);
            ImGui::GetBackgroundDrawList()->AddShadowCircle(keyCenterPos, textSize / 2.8f,
                ImColor(keyColor.Value.x, keyColor.Value.y, keyColor.Value.z, 0.45f * r.alpha), 70, ImVec2(0.f, 0.f), 0, 24);
            ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), textSize, keyPos,
                ImColor(keyColor.Value.x, keyColor.Value.y, keyColor.Value.z, 0.9f * r.alpha), r.dist.c_str());
        }
        colorIndex++;
    }
    FontHelper::Fonts["comfortaa"] ? ImGui::PopFont() : FontHelper::popPrefFont();
}


void HUD::updateOnlineStaff() {
    mOnlineStaff.clear();
    auto localPlayer = ClientInstance::get()->getLocalPlayer();
    if (!localPlayer) return;
    auto level = localPlayer->getLevel();
    if (!level) return;
    auto playerList = level->getPlayerList();
    if (!playerList) return;
    auto actors = ActorUtils::getActorList(false, true);
    auto localPosPtr = localPlayer->getPos();
    if (!localPosPtr) return;
    glm::vec3 localPos = *localPosPtr;

    for (auto& entry : *playerList | std::views::values) {
        std::string playerName = entry.mName;
        const StaffEntry* foundStaff = nullptr;
        for (const auto& staff : mStaffList) {
            if (playerName == staff.name) {
                foundStaff = &staff;
                break;
            }
        }

        if (foundStaff) {
            float distance = -1.0f;
            for (auto actor : actors) {
                if (!actor->isPlayer()) continue;
                std::string actorName = actor->getRawName();
                if (actorName == playerName) {
                    auto actorPosPtr = actor->getPos();
                    if (actorPosPtr) {
                        glm::vec3 actorPos = *actorPosPtr;
                        distance = glm::distance(localPos, actorPos);
                    }
                    break;
                }
            }
            std::string displayName = (!foundStaff->prefix.empty()) ? foundStaff->prefix + " " + playerName : playerName;
            mOnlineStaff.emplace_back(displayName, distance);
        }
    }
    std::sort(mOnlineStaff.begin(), mOnlineStaff.end(), [](const auto& a, const auto& b) { return a.first < b.first; });
}

void HUD::renderStaffList(class RenderEvent& event) {
    auto clickGui = gFeatureManager->mModuleManager->getModule<ClickGui>();
    if (clickGui && clickGui->mEnabled) return;
    auto ci = ClientInstance::get();
    if (!ci) return;
    if (ci->getScreenName() != "hud_screen" && ci->getScreenName() != "chat_screen") return;
    if (!mStaffListElement) return;

    struct Row { std::string name; std::string dist; };
    std::vector<Row> rows;

    for (const auto& staffData : mOnlineStaff) {
        std::string name = staffData.first;
        std::string distText;
        if (mStaffListShowDistance.mValue) {
            distText = staffData.second >= 0 ? std::format("{}m", static_cast<int>(staffData.second)) : "N/A";
        }
        rows.push_back({ name, distText });
    }

    static std::unordered_map<std::string, float> alphaByName;
    static std::unordered_map<std::string, std::string> distByName;
    static std::unordered_map<std::string, float> slideYByName;
    static std::unordered_map<std::string, float> rowPositionByName;
    static std::vector<std::string> stableOrder;
    static float animatedBgH = 0.0f;
    static float bgAlpha = 0.0f;

    if (gStaffListResetVisuals) {
        alphaByName.clear(); distByName.clear(); slideYByName.clear(); rowPositionByName.clear(); stableOrder.clear(); animatedBgH = 0.0f; bgAlpha = 0.0f; gStaffListResetVisuals = false;
    }

    const float dt = ImGui::GetIO().DeltaTime > 0.f ? ImGui::GetIO().DeltaTime : 1.0f / 60.0f;
    const float appearSpeed = 50.0f;
    const float disappearSpeed = 25.0f;

    std::unordered_map<std::string, std::string> currentDist;
    std::unordered_map<std::string, bool> present;

    for (const auto& r : rows) {
        currentDist[r.name] = r.dist;
        present[r.name] = true;
    }

    for (const auto& r : rows) {
        if (alphaByName.find(r.name) == alphaByName.end()) {
            alphaByName[r.name] = 0.0f;
            slideYByName[r.name] = 20.0f;
            rowPositionByName[r.name] = 0.0f;
            stableOrder.push_back(r.name);
        }
        distByName[r.name] = r.dist;
    }

    std::vector<std::string> names;
    for (const auto& kv : alphaByName) names.push_back(kv.first);

    for (const auto& name : names) {
        const bool isPresent = present.find(name) != present.end();
        float& alpha = alphaByName[name];
        float& slideY = slideYByName[name];
        alpha += ((isPresent ? 1.0f : 0.0f) - alpha) * std::clamp((isPresent ? appearSpeed : disappearSpeed) * dt, 0.0f, 1.0f);
        alpha = std::clamp(alpha, 0.0f, 1.0f);
        slideY += ((isPresent ? 0.0f : slideY) - slideY) * std::clamp(25.0f * dt, 0.0f, 1.0f);
        slideY = std::clamp(slideY, 0.0f, 20.0f);

        if (!isPresent && alpha <= 0.01f) {
            alphaByName.erase(name); slideYByName.erase(name); rowPositionByName.erase(name); distByName.erase(name);
            auto it = std::find(stableOrder.begin(), stableOrder.end(), name);
            if (it != stableOrder.end()) stableOrder.erase(it);
        }
    }

    const float animLineH = ImGui::GetFont()->CalcTextSizeA(20.f, FLT_MAX, -1, "A").y + 4.f * 2.f;
    int currentRowIndex = 0;
    for (const auto& name : stableOrder) {
        auto itAlpha = alphaByName.find(name);
        if (itAlpha == alphaByName.end()) continue;
        if (present.find(name) != present.end()) {
            float& targetPos = rowPositionByName[name];
            float newTarget = currentRowIndex * animLineH;
            targetPos += (newTarget - targetPos) * std::clamp(18.0f * dt, 0.0f, 1.0f);
            currentRowIndex++;
        }
    }

    struct RRow { std::string name; std::string dist; float alpha; };
    std::vector<RRow> renderRows;
    for (const auto& name : stableOrder) {
        auto itAlpha = alphaByName.find(name);
        if (itAlpha == alphaByName.end()) continue;
        const float a = itAlpha->second;
        if (present.find(name) != present.end()) {
            renderRows.push_back({ name, currentDist[name], a });
        }
        else if (a > 0.01f) {
            renderRows.push_back({ name, distByName[name], a });
        }
    }

    if (renderRows.empty() && alphaByName.empty()) {
        if (!(HudEditor::gInstance && HudEditor::gInstance->mEnabled)) {
            mStaffListElement->mSize = { 0,0 };
            return;
        }
        renderRows.push_back({ "No Staff Online", "", 1.0f });
    }

    FontHelper::Fonts["comfortaa"] ? ImGui::PushFont(FontHelper::Fonts["comfortaa"]) : FontHelper::pushPrefFont(false, false);
    const float titleSize = 22.f * mStaffListScale.mValue;
    const float textSize = 20.f * mStaffListScale.mValue;
    const float padX = 8.f;
    const float padY = 2.f;
    const float titlePadY = 4.f;
    const float rowPadY = 4.f;
    const float moduleNameX = 10.f;
    ImVec2 origin = mStaffListElement->getPos();

    const float titleH = ImGui::GetFont()->CalcTextSizeA(titleSize, FLT_MAX, -1, "StaffList").y + titlePadY * 2.f;
    const float lineH = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, "A").y + rowPadY * 2.f;
    const float bgW = 200.f * mStaffListScale.mValue;

    int effectiveRowCount = 0;
    for (const auto& r : renderRows) if (r.alpha > 0.05f) effectiveRowCount++;
    float targetBgH = padY + titleH + (lineH * effectiveRowCount) + padY;

    if (animatedBgH <= 0.0f) animatedBgH = targetBgH;
    animatedBgH += (targetBgH - animatedBgH) * std::clamp(25.0f * dt, 0.0f, 1.0f);
    float bgProgress = targetBgH > 0.01f ? std::clamp(animatedBgH / targetBgH, 0.0f, 1.0f) : 1.0f;

    const bool anyVisible = effectiveRowCount > 0;
    const float bgTarget = anyVisible ? 1.0f : 0.0f;
    bgAlpha += (bgTarget - bgAlpha) * std::clamp(8.0f * dt, 0.0f, 1.0f);
    bgAlpha = std::clamp(bgAlpha, 0.0f, 1.0f);

    ImVec4 bgRect = ImVec4(origin.x, origin.y, origin.x + bgW, origin.y + animatedBgH);
    ImRenderUtils::addBlur(bgRect, 10.0f, 12.0f, ImGui::GetBackgroundDrawList(), true);
    ImRenderUtils::fillRectangle(bgRect, Interface::getBlurBgColor(), (mStaffListBgAlpha.mValue / 255.0f) * bgAlpha, mStaffListRounding.mValue);

    mStaffListElement->mSize = { bgW, animatedBgH };

    ImVec2 cursor = ImVec2(origin.x + padX, origin.y + padY + titlePadY - 1.f);
    if (bgProgress >= 0.3f) {
        ImRenderUtils::drawModuleText(ImVec2(cursor.x, cursor.y), "StaffList", titleSize / 18.0f, 0.9f * bgAlpha, true, ImGui::GetBackgroundDrawList());
    }

    float rowStartY = origin.y + padY + titleH - 2.f;
    cursor.y = rowStartY;
    int colorIndex = 1;

    for (size_t i = 0; i < renderRows.size(); i++) {
        const auto& r = renderRows[i];
        if (r.alpha <= 0.01f) continue;
        const float slideOffset = slideYByName.find(r.name) != slideYByName.end() ? slideYByName[r.name] : 0.0f;
        const float rowPosOffset = rowPositionByName.find(r.name) != rowPositionByName.end() ? rowPositionByName[r.name] : 0.0f;
        const float yPos = rowStartY + rowPosOffset + slideOffset + 4.0f;

        const ImVec2 moduleNamePos = ImVec2(origin.x + moduleNameX, yPos);
        ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), textSize, moduleNamePos,
            ImColor(255, 255, 255, static_cast<int>(230 * r.alpha)), r.name.c_str());

        if (!r.dist.empty()) {
            const float keyW = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, r.dist.c_str()).x;
            const float keyX = (origin.x + bgW) - padX - keyW;
            const ImVec2 keyPos = ImVec2(keyX, yPos);
            const ImColor keyColor = ColorUtils::getThemedColor(colorIndex * 50);
            const float keyAlpha = 0.9f * r.alpha;
            const ImVec2 keyTextSize = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, -1, r.dist.c_str());
            const ImVec2 keyCenterPos = ImVec2(keyPos.x + keyTextSize.x / 2, keyPos.y + keyTextSize.y / 2);
            ImGui::GetBackgroundDrawList()->AddShadowCircle(keyCenterPos, textSize / 2.8f,
                ImColor(keyColor.Value.x, keyColor.Value.y, keyColor.Value.z, 0.45f * r.alpha), 70, ImVec2(0.f, 0.f), 0, 24);
            ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), textSize, keyPos,
                ImColor(keyColor.Value.x, keyColor.Value.y, keyColor.Value.z, keyAlpha), r.dist.c_str());
        }
        colorIndex++;
    }

    FontHelper::Fonts["comfortaa"] ? ImGui::PopFont() : FontHelper::popPrefFont();
}

void HUD::loadStaffList() {
    mStaffList.clear();
    std::string filePath = FileUtils::getSolsticeDir() + "\\staff_list.json";
    if (FileUtils::fileExists(filePath)) {
        try {
            std::ifstream file(filePath);
            nlohmann::json jsonData;
            file >> jsonData;
            file.close();

            if (jsonData.contains("staff") && jsonData["staff"].is_array()) {
                for (const auto& staffEntry : jsonData["staff"]) {
                    if (staffEntry.is_string()) {
                        StaffEntry entry{};
                        entry.name = staffEntry.get<std::string>();
                        entry.prefix = "";
                        if (!entry.name.empty()) mStaffList.push_back(std::move(entry));
                        continue;
                    }
                    if (staffEntry.is_object()) {
                        StaffEntry entry{};
                        if (staffEntry.contains("name") && staffEntry["name"].is_string()) entry.name = staffEntry["name"].get<std::string>();
                        if (staffEntry.contains("prefix") && staffEntry["prefix"].is_string()) entry.prefix = staffEntry["prefix"].get<std::string>();
                        if (!entry.name.empty()) mStaffList.push_back(std::move(entry));
                    }
                }
            }
        }
        catch (const std::exception& e) {
            spdlog::error("Failed to load staff list: {}", e.what());
        }
    }
}

void HUD::saveStaffList() {
    try {
        std::string filePath = FileUtils::getSolsticeDir() + "\\staff_list.json";
        nlohmann::json jsonData;
        nlohmann::json staffArray = nlohmann::json::array();
        for (const auto& staff : mStaffList) {
            nlohmann::json obj;
            obj["name"] = staff.name;
            obj["prefix"] = staff.prefix;
            staffArray.push_back(std::move(obj));
        }
        jsonData["staff"] = std::move(staffArray);
        std::ofstream file(filePath);
        file << jsonData.dump(4);
        file.close();
    }
    catch (const std::exception& e) {
        spdlog::error("Failed to save staff list: {}", e.what());
    }
}

void HUD::addStaff(const std::string& name, const std::string& prefix) {
    for (const auto& staff : mStaffList) {
        if (staff.name == name) {
            ChatUtils::displayClientMessage("Staff " + name + " is already in the list!");
            return;
        }
    }
    StaffEntry entry{};
    entry.name = name;
    entry.prefix = prefix;
    mStaffList.push_back(std::move(entry));
    saveStaffList();
    if (!prefix.empty()) ChatUtils::displayClientMessage("Added " + name + " to staff list with prefix '" + prefix + "'!");
    else ChatUtils::displayClientMessage("Added " + name + " to staff list!");
}

void HUD::removeStaff(const std::string& name) {
    for (auto it = mStaffList.begin(); it != mStaffList.end(); ++it) {
        if (it->name == name) {
            mStaffList.erase(it);
            saveStaffList();
            ChatUtils::displayClientMessage("Removed " + name + " from staff list!");
            return;
        }
    }
    ChatUtils::displayClientMessage("Staff " + name + " not found in list!");
}

void HUD::onChatEvent(ChatEvent& event) {
    std::string message = event.mMessage;
    if (message.starts_with(".stafflist")) {
        event.cancel();
        if (message == ".stafflist") {
            ChatUtils::displayClientMessage("Use .stafflist add/remove/list/help");
            ChatUtils::displayClientMessage(".stafflist add <nickname> <prefix> - Add staff member with custom prefix");
            return;
        }
        std::string command = message.substr(11);
        if (command.starts_with("add ")) {
            std::string args = command.substr(4);
            while (!args.empty() && args.front() == ' ') args.erase(args.begin());
            if (args.empty()) {
                ChatUtils::displayClientMessage("Usage: .stafflist add <nickname> <prefix>");
                return;
            }
            std::string staffName;
            std::string prefix;
            size_t spacePos = args.find(' ');
            if (spacePos == std::string::npos) {
                staffName = args;
                prefix.clear();
            }
            else {
                staffName = args.substr(0, spacePos);
                prefix = args.substr(spacePos + 1);
                while (!prefix.empty() && prefix.front() == ' ') prefix.erase(prefix.begin());
            }
            if (staffName.empty()) {
                ChatUtils::displayClientMessage("Usage: .stafflist add <nickname> <prefix>");
                return;
            }
            addStaff(staffName, prefix);
        }
        else if (command.starts_with("remove ")) {
            std::string staffName = command.substr(7);
            removeStaff(staffName);
        }
        else if (command == "list") {
            if (mStaffList.empty()) {
                ChatUtils::displayClientMessage("Staff list is empty!");
            }
            else {
                ChatUtils::displayClientMessage("Staff list:");
                for (const auto& staff : mStaffList) {
                    std::string displayName = (!staff.prefix.empty()) ? staff.prefix + " " + staff.name : staff.name;
                    ChatUtils::displayClientMessage(" - " + displayName);
                }
            }
        }
        else if (command == "help") {
            ChatUtils::displayClientMessage("StaffList commands:");
            ChatUtils::displayClientMessage(".stafflist add <nickname> <prefix> - Add staff member with custom prefix");
            ChatUtils::displayClientMessage(".stafflist remove <nickname> - Remove staff member");
            ChatUtils::displayClientMessage(".stafflist list - Show staff list");
            ChatUtils::displayClientMessage(".stafflist help - Show this help");
        }
        else {
            ChatUtils::displayClientMessage("Unknown command. Use .stafflist help for help.");
        }
    }
}
