#pragma once

#include <Features/Modules/Module.hpp>
#include <Features/Modules/Setting.hpp>
#include <Features/Events/RenderEvent.hpp>
#include <thread>
#include <atomic>
class Actor;

class TargetEsp : public ModuleBase<TargetEsp>
{
public:
    enum class Mode { Ghost, Nursultan, Orb, Crystal, Circle };

    EnumSettingT<Mode> mMode = EnumSettingT<Mode>(
        "Режим",
        "Визуальный режим",
        Mode::Ghost,
        "Ghost",
        "Nursultan",
        "Orb",
        "Crystal",
        "Circle"
    );
    NumberSetting mScale = NumberSetting("Размер", "Размер", 1.6f, 0.5f, 4.0f, 0.05f);
    NumberSetting mRadius = NumberSetting("Радиус", "Радиус", 0.55f, 0.1f, 3.0f, 0.01f);
    NumberSetting mSpeed = NumberSetting("Скорость", "Скорость анимации", 1.0f, 0.1f, 5.0f, 0.05f);
    NumberSetting mYOffset = NumberSetting("Смещение Y", "Смещение по высоте", 0.0f, -2.0f, 2.0f, 0.01f);
    BoolSetting mThemeColor = BoolSetting("Цвет темы", "Использовать цвет темы для TargetESP", true);

    TargetEsp() : ModuleBase("TargetEsp", "TargetESP для существ", ModuleCategory::Visual, 0, false)
    {
        addSettings(&mMode, &mScale, &mRadius, &mSpeed, &mYOffset, &mThemeColor);

        mNames = {
            {Lowercase, "targetesp"},
            {LowercaseSpaced, "target esp"},
            {Normal, "TargetEsp"},
            {NormalSpaced, "Target Esp"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(RenderEvent& event);

private:
    void ensureTextureLoaded();
    float mGhostAlpha = 0.0f;
    bool mHasSmoothed = false;
    glm::vec3 mSmoothedWorld = glm::vec3(0.0f);
    Actor* mLastTarget = nullptr;

    
    std::atomic<bool> mWorkerRunning{ false };
    std::thread mWorker;
    std::atomic<float> mPulseScale{ 1.0f };
    std::atomic<float> mPhase{ 0.0f };

    float mPngAlpha = 0.0f;
    bool mPendingFadeOut = false;
    glm::vec3 mFadeWorld = glm::vec3(0.0f);
    Mode mFadeMode = Mode::Nursultan;
    bool mSubscribed = false;
    bool mWasPngVisible = false;
    float mHoldTimeMs = 0.0f;
    float mMinShowMs = 180.0f;
};


