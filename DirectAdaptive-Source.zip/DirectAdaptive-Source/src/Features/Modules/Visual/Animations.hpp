#pragma once




#include <Features/Modules/Module.hpp>

class Animations : public ModuleBase<Animations> {
public:
    enum class Animation {
        Default,
        Blocking,
        Test
    };
    EnumSettingT<Animation> mAnimation = EnumSettingT("Анимация", "Используемая анимация", Animation::Blocking, "Обычная", "Блокировка", "Тест");
    NumberSetting mSwingTime = NumberSetting("Время удара", "Время взмаха рукой", 6.f, 0.f, 20.0f, 1.f);
    BoolSetting mNoSwitchAnimation = BoolSetting("Без смены предмета", "Отключает анимацию смены предмета", true);
    BoolSetting mFluxSwing = BoolSetting("Стиль Flux", "Стиль взмаха как во Flux Client", true);
    BoolSetting mThirdPersonBlock = BoolSetting("3-е лицо", "Отображает анимации от 3-го лица", false);
    
    NumberSetting mXRot = NumberSetting("Вращение по X", "Кастомное вращение по X. (по умолчанию: 0)", -57.f, -360.f, 360.f, 0.01f);
    NumberSetting mYRot = NumberSetting("Вращение по Y", "Кастомное вращение по Y. (по умолчанию: 0)", -45.16f, -360.f, 360.f, 0.01f);
    NumberSetting mZRot = NumberSetting("Вращение по Z", "Кастомное вращение по Z. (по умолчанию: 0)", 13.14f, -360.f, 360.f, 0.01f);
    BoolSetting mCustomSwingAngle = BoolSetting("Свой угол удара", "Изменяет угол взмаха", true);
    BoolSetting mOnlyOnBlock = BoolSetting("Только при блоке", "Изменяет угол только при блокировании", false);
    NumberSetting mSwingAngleSetting = NumberSetting("Угол удара", "Значение угла взмаха. (по умолчанию: -80)", -31.f, -360.f, 360.f, 0.01f);
    BoolSetting mSmallItems = BoolSetting("Маленькие предметы", "Делает предметы меньше", true);

    Animations() : ModuleBase("Animations", "Изменяет ваши анимации!", ModuleCategory::Visual, 0, false)
    {
        addSettings(
            &mAnimation,
            &mSwingTime,
            &mNoSwitchAnimation,
            &mFluxSwing,
            &mThirdPersonBlock,
            
            
            
            &mCustomSwingAngle,
            &mOnlyOnBlock,
            &mSwingAngleSetting,
            &mSmallItems
        );

        VISIBILITY_CONDITION(mOnlyOnBlock, mCustomSwingAngle.mValue);
        VISIBILITY_CONDITION(mSwingAngleSetting, mCustomSwingAngle.mValue);

        mNames = {
            {Lowercase, "animations"},
            {LowercaseSpaced, "animations"},
            {Normal, "Animations"},
            {NormalSpaced, "Animations"}
        };
    }

    int mSwingDuration = 0.f;
    int mOldSwingDuration = 0.f;
    float* mSwingAngle = nullptr;
    bool mShouldBlock = false;

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onSwingDurationEvent(class SwingDurationEvent& event);
    void onBoneRenderEvent(class BoneRenderEvent& event);
    void onBobHurtEvent(class BobHurtEvent& event);
};