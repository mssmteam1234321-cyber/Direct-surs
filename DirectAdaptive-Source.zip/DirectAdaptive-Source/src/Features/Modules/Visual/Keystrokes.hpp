#pragma once





class Keystrokes : public ModuleBase<Keystrokes> {
public:
    BoolSetting mUseInterfaceColor = BoolSetting("Цвет интерфейса", "Использовать цвет интерфейса", true);

    Keystrokes();

    std::unique_ptr<class HudElement> mElement;

    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(class RenderEvent& event);
};