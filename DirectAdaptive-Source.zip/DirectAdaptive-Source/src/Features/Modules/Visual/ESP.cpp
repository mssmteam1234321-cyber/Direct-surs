
#include "ESP.hpp"

#include <Features/FeatureManager.hpp>
#include <Features/Events/ActorRenderEvent.hpp>
#include <Features/Modules/Misc/Friends.hpp>
#include <Features/Modules/Combat/Aura.hpp>
#include <Features/Modules/Misc/AntiBot.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Options.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>
#include <SDK/Minecraft/Rendering/GuiData.hpp>
#include <Hook/Hooks/RenderHooks/D3DHook.hpp>
#include <SDK/Minecraft/Actor/SerializedSkin.hpp>
#include <Utils/MiscUtils/ImRenderUtils.hpp>

void ESP::onEnable()
{
    gFeatureManager->mDispatcher->listen<RenderEvent, &ESP::onRenderEvent>(this);
}

void ESP::onDisable()
{
    gFeatureManager->mDispatcher->deafen<RenderEvent, &ESP::onRenderEvent>(this);
}


void ESP::onRenderEvent(RenderEvent& event)
{
    if (!ClientInstance::get()->getLevelRenderer()) return;

    auto actors = ActorUtils::getActorList(false, true);
    auto localPlayer = ClientInstance::get()->getLocalPlayer();

    if (mDebug.mValue)
    {
        auto botActors = ActorUtils::getActorList(false, false);
        std::erase_if(botActors, [actors](Actor* actor) {
            return std::ranges::find(actors, actor) != actors.end();
            });
        auto drawList = ImGui::GetBackgroundDrawList();
        for (auto actor : botActors)
        {
            if (actor == localPlayer && ClientInstance::get()->getOptions()->mThirdPerson->value == 0 && !localPlayer->getFlag<RenderCameraComponent>()) continue;
            if (actor == localPlayer && !mRenderLocal.mValue) continue;
            auto shape = actor->getAABBShapeComponent();
            if (!shape) continue;

            auto themeColor = ImColor(1.0f, 0.0f, 0.0f);

            if (actor->isPlayer())
            {
                bool isFriend = gFriendManager->isFriend(actor);
                if (isFriend)
                {
                    if (mShowFriends.mValue) themeColor = ImColor(0.0f, 1.0f, 0.0f);
                    else continue;
                }
                if (mArmorBasedColors.mValue && !isFriend)
                {
                    auto antiBotModule = gFeatureManager->mModuleManager->getModule<AntiBot>();
                    if (antiBotModule && antiBotModule->hasArmor(actor))
                    {
                        themeColor = ImColor(0.0f, 0.0f, 1.0f);
                    }
                    else
                    {
                        themeColor = ImColor(1.0f, 0.0f, 0.0f);
                    }
                }
            }

            AABB aabb = actor->getAABB();

            if (mStyle.mValue == Style::Style3D)
            {
                std::vector<ImVec2> imPoints = MathUtils::getImBoxPoints(aabb);

                if (mRenderFilled.mValue) drawList->AddConvexPolyFilled(imPoints.data(), imPoints.size(), ImColor(themeColor.Value.x, themeColor.Value.y, themeColor.Value.z, 0.25f));
                drawList->AddPolyline(imPoints.data(), imPoints.size(), themeColor, 0, 2.0f);
            }
            else if (mStyle.mValue == Style::Style2D)
            {
                ImVec4 rect = RenderUtils::transform.mMatrix.getRectForAABB(aabb, RenderUtils::transform.mOrigin, RenderUtils::transform.mFov, ClientInstance::get()->getGuiData()->mResolution);

                if (rect.x != 0.0f || rect.y != 0.0f || rect.z != 0.0f || rect.w != 0.0f)
                {
                    if (mShowBox.mValue)
                    {
                        if (mGradientBox.mValue)
                        {
                            float thickness = 1.5f;
                            ImColor firstColor = ImColor(0, 0, 0);
                            ImColor secondColor = themeColor;
                            ImVec4 topRect(rect.x, rect.y, rect.z, rect.y + thickness);
                            ImRenderUtils::fillGradientOpaqueRectangle(topRect, firstColor, secondColor, 1.0f, 1.0f);
                            ImVec4 rightRect(rect.z - thickness, rect.y, rect.z, rect.w);
                            ImRenderUtils::fillGradientOpaqueRectangle(rightRect, firstColor, secondColor, 1.0f, 1.0f);
                            ImVec4 bottomRect(rect.x, rect.w - thickness, rect.z, rect.w);
                            ImRenderUtils::fillGradientOpaqueRectangle(bottomRect, firstColor, secondColor, 1.0f, 1.0f);
                            ImVec4 leftRect(rect.x, rect.y, rect.x + thickness, rect.w);
                            ImRenderUtils::fillGradientOpaqueRectangle(leftRect, firstColor, secondColor, 1.0f, 1.0f);
                        }
                        else
                        {
                            drawList->AddRect(
                                ImVec2(rect.x - 1, rect.y - 1),
                                ImVec2(rect.z + 1, rect.w + 1),
                                ImColor(0.0f, 0.0f, 0.0f, 1.0f),
                                0.0f,
                                0,
                                1.0f
                            );

                            drawList->AddRect(
                                ImVec2(rect.x, rect.y),
                                ImVec2(rect.z, rect.w),
                                themeColor,
                                0.0f,
                                0,
                                1.0f
                            );

                            drawList->AddRect(
                                ImVec2(rect.x + 1, rect.y + 1),
                                ImVec2(rect.z - 1, rect.w - 1),
                                ImColor(0.0f, 0.0f, 0.0f, 0.7f),
                                0.0f,
                                0,
                                0.5f
                            );
                        }
                    }
                    if (mShowDistance.mValue && localPlayer)
                    {
                        float distance = localPlayer->distanceTo(actor);
                        std::string distanceText = std::to_string((int)distance) + "m";

                        ImVec2 textPos = ImVec2(rect.z + 5, rect.y);
                        ImRenderUtils::drawShadowText(drawList, distanceText, textPos, ImColor(1.0f, 1.0f, 1.0f, 1.0f), 14.0f);
                    }
                }
            }
            else if (mStyle.mValue == Style::StyleCorner)
            {
                ImVec4 rect = RenderUtils::transform.mMatrix.getRectForAABB(aabb, RenderUtils::transform.mOrigin, RenderUtils::transform.mFov, ClientInstance::get()->getGuiData()->mResolution);

                if (rect.x != 0.0f || rect.y != 0.0f || rect.z != 0.0f || rect.w != 0.0f)
                {
                    if (mShowBox.mValue)
                    {
                        float thickness = 1.5f;
                        float len = 6.0f;
                        ImVec2 tl(rect.x, rect.y);
                        ImVec2 tr(rect.z, rect.y);
                        ImVec2 bl(rect.x, rect.w);
                        ImVec2 br(rect.z, rect.w);

                        ImU32 black = ImColor(0.0f, 0.0f, 0.0f, 1.0f);
                        
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(tl.x, tl.y), ImVec2(tl.x + len, tl.y), black, thickness + 1.0f);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(tl.x, tl.y), ImVec2(tl.x, tl.y + len), black, thickness + 1.0f);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(tr.x - len, tr.y), ImVec2(tr.x, tr.y), black, thickness + 1.0f);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(tr.x, tr.y), ImVec2(tr.x, tr.y + len), black, thickness + 1.0f);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(bl.x, bl.y - len), ImVec2(bl.x, bl.y), black, thickness + 1.0f);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(bl.x, bl.y), ImVec2(bl.x + len, bl.y), black, thickness + 1.0f);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(br.x - len, br.y), ImVec2(br.x, br.y), black, thickness + 1.0f);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(br.x, br.y - len), ImVec2(br.x, br.y), black, thickness + 1.0f);

                        
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(tl.x, tl.y), ImVec2(tl.x + len, tl.y), themeColor, thickness);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(tl.x, tl.y), ImVec2(tl.x, tl.y + len), themeColor, thickness);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(tr.x - len, tr.y), ImVec2(tr.x, tr.y), themeColor, thickness);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(tr.x, tr.y), ImVec2(tr.x, tr.y + len), themeColor, thickness);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(bl.x, bl.y - len), ImVec2(bl.x, bl.y), themeColor, thickness);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(bl.x, bl.y), ImVec2(bl.x + len, bl.y), themeColor, thickness);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(br.x - len, br.y), ImVec2(br.x, br.y), themeColor, thickness);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(br.x, br.y - len), ImVec2(br.x, br.y), themeColor, thickness);
                    }
                    if (mShowDistance.mValue && localPlayer)
                    {
                        float distance = localPlayer->distanceTo(actor);
                        std::string distanceText = std::to_string((int)distance) + "m";
                        ImVec2 textPos = ImVec2(rect.z + 5, rect.y);
                        ImRenderUtils::drawShadowText(ImGui::GetBackgroundDrawList(), distanceText, textPos, ImColor(1.0f, 1.0f, 1.0f, 1.0f), 14.0f);
                    }
                }
            }
            else if (mStyle.mValue == Style::Style3DNew)
            {
                glm::vec3 mins = aabb.mMin;
                glm::vec3 maxs = aabb.mMax;
                glm::vec3 corners[8] = {
                    {mins.x, mins.y, mins.z}, {mins.x, mins.y, maxs.z}, {maxs.x, mins.y, mins.z}, {maxs.x, mins.y, maxs.z},
                    {mins.x, maxs.y, mins.z}, {mins.x, maxs.y, maxs.z}, {maxs.x, maxs.y, mins.z}, {maxs.x, maxs.y, maxs.z}
                };
                ImVec2 screen[8];
                bool vis[8];
                bool any = false;
                for (int i = 0; i < 8; ++i) {
                    vis[i] = RenderUtils::worldToScreen(corners[i], screen[i]);
                    any |= vis[i];
                }
                if (any)
                {
                    static const int edges[12][2] = {
                        {0,1},{0,2},{0,4},{1,3},{1,5},{2,3},{2,6},{3,7},{4,5},{4,6},{5,7},{6,7}
                    };
                    float outline = 3.0f;
                    float line = 1.5f;
                    ImU32 black = ImColor(0, 0, 0, 255);
                    for (auto& e : edges) {
                        int a = e[0], b = e[1];
                        if (vis[a] && vis[b]) {
                            drawList->AddLine(screen[a], screen[b], black, outline);
                        }
                    }
                    for (auto& e : edges) {
                        int a = e[0], b = e[1];
                        if (vis[a] && vis[b]) {
                            drawList->AddLine(screen[a], screen[b], themeColor, line);
                        }
                    }
                }
            }
        }
    }

    auto drawList = ImGui::GetBackgroundDrawList();

    for (auto actor : actors)
    {
        if (actor == localPlayer && ClientInstance::get()->getOptions()->mThirdPerson->value == 0 && !localPlayer->getFlag<RenderCameraComponent>()) continue;
        if (actor == localPlayer && !mRenderLocal.mValue) continue;
        auto shape = actor->getAABBShapeComponent();
        if (!shape) continue;

        auto themeColor = ColorUtils::getThemedColor(0);

        if (actor->isPlayer())
        {
            bool isFriend = gFriendManager->isFriend(actor);
            if (isFriend)
            {
                if (mShowFriends.mValue) themeColor = ImColor(0.0f, 1.0f, 0.0f);
                else continue;
            }

            if (mArmorBasedColors.mValue && !isFriend)
            {
                auto antiBotModule = gFeatureManager->mModuleManager->getModule<AntiBot>();
                if (antiBotModule && antiBotModule->hasArmor(actor))
                {
                    themeColor = ImColor(0.0f, 0.0f, 1.0f);
                }
                else
                {
                    themeColor = ImColor(1.0f, 0.0f, 0.0f);
                }
            }
        }

        AABB aabb = actor->getAABB();

        if (mStyle.mValue == Style::Style3D)
        {
            std::vector<ImVec2> imPoints = MathUtils::getImBoxPoints(aabb);

            if (mRenderFilled.mValue) drawList->AddConvexPolyFilled(imPoints.data(), imPoints.size(), ImColor(themeColor.Value.x, themeColor.Value.y, themeColor.Value.z, 0.25f));
            drawList->AddPolyline(imPoints.data(), imPoints.size(), themeColor, 0, 2.0f);
        }
        else if (mStyle.mValue == Style::Style2D)
        {
            ImVec4 rect = RenderUtils::transform.mMatrix.getRectForAABB(aabb, RenderUtils::transform.mOrigin, RenderUtils::transform.mFov, ClientInstance::get()->getGuiData()->mResolution);

            if (rect.x != 0.0f || rect.y != 0.0f || rect.z != 0.0f || rect.w != 0.0f)
            {
                if (mShowBox.mValue)
                {
                    if (mGradientBox.mValue)
                    {
                        float thickness = 1.5f;
                        ImColor firstColor = ImColor(0, 0, 0);
                        ImColor secondColor = themeColor;
                        ImVec4 topRect(rect.x, rect.y, rect.z, rect.y + thickness);
                        ImRenderUtils::fillGradientOpaqueRectangle(topRect, firstColor, secondColor, 1.0f, 1.0f);
                        ImVec4 rightRect(rect.z - thickness, rect.y, rect.z, rect.w);
                        ImRenderUtils::fillGradientOpaqueRectangle(rightRect, firstColor, secondColor, 1.0f, 1.0f);
                        ImVec4 bottomRect(rect.x, rect.w - thickness, rect.z, rect.w);
                        ImRenderUtils::fillGradientOpaqueRectangle(bottomRect, firstColor, secondColor, 1.0f, 1.0f);
                        ImVec4 leftRect(rect.x, rect.y, rect.x + thickness, rect.w);
                        ImRenderUtils::fillGradientOpaqueRectangle(leftRect, firstColor, secondColor, 1.0f, 1.0f);
                    }
                    else
                    {
                        drawList->AddRect(
                            ImVec2(rect.x - 1, rect.y - 1),
                            ImVec2(rect.z + 1, rect.w + 1),
                            ImColor(0.0f, 0.0f, 0.0f, 1.0f),
                            0.0f,
                            0,
                            0.5f
                        );
                        drawList->AddRect(
                            ImVec2(rect.x, rect.y),
                            ImVec2(rect.z, rect.w),
                            themeColor,
                            0.0f,
                            0,
                            1.5f
                        );
                        drawList->AddRect(
                            ImVec2(rect.x + 1, rect.y + 1),
                            ImVec2(rect.z - 1, rect.w - 1),
                            ImColor(0.0f, 0.0f, 0.0f, 0.7f),
                            0.0f,
                            0,
                            0.5f
                        );
                    }
                }

                if (mShowDistance.mValue && localPlayer)
                {
                    float distance = localPlayer->distanceTo(actor);
                    std::string distanceText = std::to_string((int)distance) + "m";
                    ImVec2 textPos = ImVec2(rect.z + 5, rect.y);
                    ImRenderUtils::drawShadowText(drawList, distanceText, textPos, ImColor(1.0f, 1.0f, 1.0f, 1.0f), 14.0f);
                }
                if (mGradientHealth.mValue && actor->isPlayer())
                {
                    bool isTarget = (Aura::sTarget == actor);
                    float health = actor->getHealth();
                    float maxHealth = actor->getMaxHealth();
                    float healthPercentage = health / maxHealth;
                    float barWidth = 4.0f;
                    float barHeight = rect.w - rect.y;
                    float barX = rect.x - 7.0f;
                    float barY = rect.y;
                    ImColor grayColor = ImColor(0.0f, 0.0f, 0.0f, 0.7f);
                    ImColor healthColor = themeColor;
                    drawList->AddRectFilled(
                        ImVec2(barX, barY),
                        ImVec2(barX + barWidth, barY + barHeight),
                        grayColor
                    );
                    float healthBarHeight = barHeight * healthPercentage;
                    if (healthBarHeight > 0.0f)
                    {
                        ImVec4 healthBarRect = ImVec4(barX, barY + barHeight - healthBarHeight, barX + barWidth, barY + barHeight);
                        ImRenderUtils::fillGradientOpaqueRectangle(healthBarRect, grayColor, healthColor, 0.0f, 1.0f);
                    }
                    drawList->AddRect(
                        ImVec2(barX, barY),
                        ImVec2(barX + barWidth, barY + barHeight),
                        ImColor(0.0f, 0.0f, 0.0f, 0.8f),
                        0.0f,
                        0,
                        1.0f
                    );
                }
            }
        }
        else if (mStyle.mValue == Style::StyleCorner)
        {
            ImVec4 rect = RenderUtils::transform.mMatrix.getRectForAABB(aabb, RenderUtils::transform.mOrigin, RenderUtils::transform.mFov, ClientInstance::get()->getGuiData()->mResolution);

            if (rect.x != 0.0f || rect.y != 0.0f || rect.z != 0.0f || rect.w != 0.0f)
            {
                if (mShowBox.mValue)
                {
                    float thickness = 1.5f;
                    float len = 6.0f;
                    ImVec2 tl(rect.x, rect.y);
                    ImVec2 tr(rect.z, rect.y);
                    ImVec2 bl(rect.x, rect.w);
                    ImVec2 br(rect.z, rect.w);

                    ImU32 black = ImColor(0.0f, 0.0f, 0.0f, 1.0f);
                    drawList->AddLine(ImVec2(tl.x, tl.y), ImVec2(tl.x + len, tl.y), black, thickness + 1.0f);
                    drawList->AddLine(ImVec2(tl.x, tl.y), ImVec2(tl.x, tl.y + len), black, thickness + 1.0f);
                    drawList->AddLine(ImVec2(tr.x - len, tr.y), ImVec2(tr.x, tr.y), black, thickness + 1.0f);
                    drawList->AddLine(ImVec2(tr.x, tr.y), ImVec2(tr.x, tr.y + len), black, thickness + 1.0f);
                    drawList->AddLine(ImVec2(bl.x, bl.y - len), ImVec2(bl.x, bl.y), black, thickness + 1.0f);
                    drawList->AddLine(ImVec2(bl.x, bl.y), ImVec2(bl.x + len, bl.y), black, thickness + 1.0f);
                    drawList->AddLine(ImVec2(br.x - len, br.y), ImVec2(br.x, br.y), black, thickness + 1.0f);
                    drawList->AddLine(ImVec2(br.x, br.y - len), ImVec2(br.x, br.y), black, thickness + 1.0f);

                    drawList->AddLine(ImVec2(tl.x, tl.y), ImVec2(tl.x + len, tl.y), themeColor, thickness);
                    drawList->AddLine(ImVec2(tl.x, tl.y), ImVec2(tl.x, tl.y + len), themeColor, thickness);
                    drawList->AddLine(ImVec2(tr.x - len, tr.y), ImVec2(tr.x, tr.y), themeColor, thickness);
                    drawList->AddLine(ImVec2(tr.x, tr.y), ImVec2(tr.x, tr.y + len), themeColor, thickness);
                    drawList->AddLine(ImVec2(bl.x, bl.y - len), ImVec2(bl.x, bl.y), themeColor, thickness);
                    drawList->AddLine(ImVec2(bl.x, bl.y), ImVec2(bl.x + len, bl.y), themeColor, thickness);
                    drawList->AddLine(ImVec2(br.x - len, br.y), ImVec2(br.x, br.y), themeColor, thickness);
                    drawList->AddLine(ImVec2(br.x, br.y - len), ImVec2(br.x, br.y), themeColor, thickness);
                }

                if (mShowDistance.mValue && localPlayer)
                {
                    float distance = localPlayer->distanceTo(actor);
                    std::string distanceText = std::to_string((int)distance) + "m";
                    ImVec2 textPos = ImVec2(rect.z + 5, rect.y);
                    ImRenderUtils::drawShadowText(drawList, distanceText, textPos, ImColor(1.0f, 1.0f, 1.0f, 1.0f), 14.0f);
                }

                if (mGradientHealth.mValue && actor->isPlayer())
                {
                    float health = actor->getHealth();
                    float maxHealth = actor->getMaxHealth();
                    float healthPercentage = health / maxHealth;
                    float barWidth = 4.0f;
                    float barHeight = rect.w - rect.y;
                    float barX = rect.x - 7.0f;
                    float barY = rect.y;
                    ImColor grayColor = ImColor(0.0f, 0.0f, 0.0f, 0.7f);
                    ImColor healthColor = themeColor;
                    drawList->AddRectFilled(
                        ImVec2(barX, barY),
                        ImVec2(barX + barWidth, barY + barHeight),
                        grayColor
                    );
                    float healthBarHeight = barHeight * healthPercentage;
                    if (healthBarHeight > 0.0f)
                    {
                        ImVec4 healthBarRect = ImVec4(barX, barY + barHeight - healthBarHeight, barX + barWidth, barY + barHeight);
                        ImRenderUtils::fillGradientOpaqueRectangle(healthBarRect, grayColor, healthColor, 0.0f, 1.0f);
                    }
                    drawList->AddRect(
                        ImVec2(barX, barY),
                        ImVec2(barX + barWidth, barY + barHeight),
                        ImColor(0.0f, 0.0f, 0.0f, 0.8f),
                        0.0f,
                        0,
                        1.0f
                    );
                }
            }
        }
        else if (mStyle.mValue == Style::Style3DNew)
        {
            glm::vec3 mins = aabb.mMin;
            glm::vec3 maxs = aabb.mMax;
            glm::vec3 corners[8] = {
                {mins.x, mins.y, mins.z}, {mins.x, mins.y, maxs.z}, {maxs.x, mins.y, mins.z}, {maxs.x, mins.y, maxs.z},
                {mins.x, maxs.y, mins.z}, {mins.x, maxs.y, maxs.z}, {maxs.x, maxs.y, mins.z}, {maxs.x, maxs.y, maxs.z}
            };
            ImVec2 screen[8];
            bool vis[8];
            bool any = false;
            for (int i = 0; i < 8; ++i) {
                vis[i] = RenderUtils::worldToScreen(corners[i], screen[i]);
                any |= vis[i];
            }
            if (any)
            {
                static const int edges[12][2] = {
                    {0,1},{0,2},{0,4},{1,3},{1,5},{2,3},{2,6},{3,7},{4,5},{4,6},{5,7},{6,7}
                };
                float outline = 3.0f;
                float line = 1.5f;
                ImU32 black = ImColor(0, 0, 0, 255);
                for (auto& e : edges) {
                    int a = e[0], b = e[1];
                    if (vis[a] && vis[b]) {
                        drawList->AddLine(screen[a], screen[b], black, outline);
                    }
                }
                for (auto& e : edges) {
                    int a = e[0], b = e[1];
                    if (vis[a] && vis[b]) {
                        drawList->AddLine(screen[a], screen[b], themeColor, line);
                    }
                }
            }
        }
    }
}