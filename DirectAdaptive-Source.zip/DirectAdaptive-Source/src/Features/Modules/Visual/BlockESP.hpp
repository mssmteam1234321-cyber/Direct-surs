#pragma once




#include <Features/Modules/Module.hpp>


class BlockESP : public ModuleBase<BlockESP>
{
public:
    enum class BlockRenderMode {
        Filled,
        Outline,
        Both
    };

    EnumSettingT<BlockRenderMode> mRenderMode = EnumSettingT("Режим рендера", "Способ отображения блоков", BlockRenderMode::Outline, "Заливка", "Обводка", "Оба");
    NumberSetting mRadius = NumberSetting("Радиус", "Радиус BlockESP", 20.f, 1.f, 100.f, 0.01f);
    NumberSetting mChunkRadius = NumberSetting("Радиус чанков", "Максимальный радиус чанков для поиска блоков", 4.f, 1.f, 32.f, 1.f);
    NumberSetting mUpdateFrequency = NumberSetting("Частота обновления", "Частота обновления блоков (в тиках)", 1.f, 1.f, 40.f, 0.01f);
    NumberSetting mChunkUpdatesPerTick = NumberSetting("Чанков за тик", "Количество обновляемых сабчанков за тик", 5.f, 1.f, 24.f, 1.f);
    BoolSetting mRenderCurrentChunk = BoolSetting("Рендер текущего чанка", "Рендерить текущий чанк", false);
    BoolSetting mEmerald = BoolSetting("Изумруд", "Рисует вокруг изумрудной руды", true);
    BoolSetting mDiamond = BoolSetting("Алмаз", "Рисует вокруг алмазной руды", true);
    BoolSetting mGold = BoolSetting("Золото", "Рисует вокруг золотой руды", true);
    BoolSetting mIron = BoolSetting("Железо", "Рисует вокруг железной руды", true);
    BoolSetting mCoal = BoolSetting("Уголь", "Рисует вокруг угольной руды", true);
    BoolSetting mRedstone = BoolSetting("Редстоун", "Рисует вокруг редстоун руды", true);
    BoolSetting mLapis = BoolSetting("Лазурит", "Рисует вокруг лазуритной руды", true);
    BoolSetting mPortal = BoolSetting("Портал", "Рисует вокруг блоков портала", true);
    BoolSetting mChests = BoolSetting("Сундуки", "Рисует вокруг сундуков", false);
    BoolSetting mOnlyExposedOres = BoolSetting("Только видимые руды", "Показывать только руды, контактирующие с воздухом", false);

    BlockESP() : ModuleBase("BlockESP", "Рисует коробку вокруг выбранных блоков", ModuleCategory::Visual, 0, false) {
        addSettings(
                &mRenderMode,
            &mRadius,
            &mChunkRadius,
            &mUpdateFrequency,
            &mChunkUpdatesPerTick,
            &mRenderCurrentChunk,
            &mDiamond,
            &mEmerald,
            &mGold,
            &mIron,
            &mCoal,
            &mRedstone,
            &mLapis,
            &mPortal,
            &mChests,
            &mOnlyExposedOres
        );

        mNames = {
            {Lowercase, "blockesp"},
            {LowercaseSpaced, "block esp"},
            {Normal, "BlockESP"},
            {NormalSpaced, "Block ESP"}
        };
    }

    ChunkPos mSearchCenter;
    ChunkPos mCurrentChunkPos;
    int mSubChunkIndex = 0;
    int mDirectionIndex = 0;
    int mSteps = 1;
    int mStepsCount = 0;
    int64_t mSearchStart = 0;

    struct FoundBlock
    {
        const Block* block;
        AABB aabb;
        ImColor color;
    };

    std::unordered_map<BlockPos, FoundBlock> mFoundBlocks = {};

    void moveToNext();
    void tryProcessSub(bool& processed, ChunkPos currentChunkPos, int subChunkIndex);
    bool processSub(ChunkPos processChunk, int subChunk);
    void reset();

    void onEnable() override;
    void onDisable() override;
    std::vector<int> getEnabledBlocks();
    void onBlockChangedEvent(class BlockChangedEvent& event);
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onRenderEvent(class RenderEvent& event);
};