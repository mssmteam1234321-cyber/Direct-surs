#pragma once
#include <Features/Modules/Module.hpp>





class LevelInfo : public ModuleBase<LevelInfo>
{
public:
    BoolSetting mShowFPS = BoolSetting("Показать FPS", "Показывать текущий FPS.", true);
    BoolSetting mShowPing = BoolSetting("Показать пинг", "Показывать текущий пинг.", true);
    BoolSetting mShowBPS = BoolSetting("Показать BPS", "Показывать текущий BPS.", true);
    BoolSetting mShowXYZ = BoolSetting("Показать XYZ", "Показывать текущие координаты XYZ.", true);
    BoolSetting mShowArrows = BoolSetting("Показать стрелы", "Показывать количество стрел в инвентаре.", false);
    BoolSetting mShowEnderPearls = BoolSetting("Показать эндер-жемчуг", "Показывать количество эндер-жемчугов в инвентаре.", false);
    BoolSetting mShowSpells = BoolSetting("Показать заклинания", "Показывать заклинания в инвентаре.", false);
    BoolSetting mShowHealthSpells = BoolSetting("Показать заклинания здоровья", "Показывать количество заклинаний здоровья.", false);
    BoolSetting mShowSpeedSpells = BoolSetting("Показать заклинания скорости", "Показывать количество заклинаний скорости.", false);
    BoolSetting mShowFireTrailSpells = BoolSetting("Показать заклинания огненного следа", "Показывать количество заклинаний огненного следа.", false);
    BoolSetting mShowKicksAmount = BoolSetting("Счетчик киков", "Показывает сколько раз вас кикнуло (полезно для избежания банов в Flareon v2).", false);

    LevelInfo() : ModuleBase("LevelInfo", "Отображает общую информацию.", ModuleCategory::Visual, 0, false) {
        addSetting(&mShowFPS);
        addSetting(&mShowPing);
        addSetting(&mShowBPS);
        addSetting(&mShowXYZ);
        addSetting(&mShowArrows);
        addSetting(&mShowEnderPearls);
        addSettings(&mShowSpells, &mShowHealthSpells, &mShowSpeedSpells, &mShowFireTrailSpells);
        addSetting(&mShowKicksAmount);

        VISIBILITY_CONDITION(mShowHealthSpells, mShowSpells.mValue);
        VISIBILITY_CONDITION(mShowSpeedSpells, mShowSpells.mValue);
        VISIBILITY_CONDITION(mShowFireTrailSpells, mShowSpells.mValue);

        mNames = {
            {Lowercase, "levelinfo"},
            {LowercaseSpaced, "level info"},
            {Normal, "LevelInfo"},
            {NormalSpaced, "Level Info"}
        };
    }

    int mArrows = 0;
    int mPearls = 0;
    int mHealthSpells = 0;
    int mHearts = 0;
    int mSpeedSpells = 0;
    int mSeconds = 0;
    int mFireTrailSpells = 0;
    int mBlocks = 0;
    int mKicksAmount = 0;
    float mBps = 0.f;
    float mAveragedBps = 0.f;
    std::map<uint64_t, float> mBpsHistory;
    __int64 mPing = 0;
    __int64 mEventDelay = 0;

    int getPearlsAmount();
    int getArrowsAmount();
    int getSpellsAmount(int mSpellIndex); 
    void calculateValue(int mSpellIndex); 
    void spellsUpdate();
    void onEnable() override;
    void onDisable() override;
    void onSendImmediateEvent(class SendImmediateEvent& event);
    void onPingUpdateEvent(class PingUpdateEvent& event);
    void onBaseTickEvent(class BaseTickEvent& event);
    void onRenderEvent(class RenderEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
};