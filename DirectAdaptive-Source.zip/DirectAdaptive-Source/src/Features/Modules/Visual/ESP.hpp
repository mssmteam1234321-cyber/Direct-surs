#pragma once



#include <Features/Modules/Module.hpp>
#include <d3d11.h>
#include <unordered_map>
#include <mutex>
#include <Features/Modules/Module.hpp>
#include <Features/Modules/Misc/AntiBot.hpp>


class ESP : public ModuleBase<ESP>
{
public:
    enum class Style {
        Style3D,
        Style2D,
        StyleCorner,
        Style3DNew
    };

    EnumSettingT<Style> mStyle = EnumSettingT<Style>("Стиль", "Стиль ESP.", Style::Style3D, "3D", "2D", "Углы", "3D Новый");
    BoolSetting mRenderFilled = BoolSetting("Заливка", "Рисовать заливку ESP.", true);
    BoolSetting mRenderLocal = BoolSetting("На себе", "Рисовать ESP на локальном игроке.", false);
    BoolSetting mShowFriends = BoolSetting("Показывать друзей", "Рисовать ESP на друзьях.", true);
    BoolSetting mDebug = BoolSetting("Отладка", "Показывать ботов и NPC.", false);
    BoolSetting mShowDistance = BoolSetting("Дистанция", "Показывать дистанцию до игроков.", true);
    BoolSetting mGradientHealth = BoolSetting("Градиент HP", "Градиентная полоска здоровья.", true);
    BoolSetting mShowBox = BoolSetting("Показывать бокс", "Рисовать обводку (коробку) в 2D режиме.", true);
    BoolSetting mGradientBox = BoolSetting("Градиент бокса", "Использовать градиент для обводки в 2D.", false);
    BoolSetting mArmorBasedColors = BoolSetting("Цвет от брони", "Менять цвет в зависимости от наличия брони.", false);

    ESP() : ModuleBase("ESP", "Рисует коробку вокруг сущностей", ModuleCategory::Visual, 0, false) {
        addSetting(&mStyle);
        addSetting(&mRenderFilled);
        addSetting(&mRenderLocal);
        addSetting(&mShowFriends);
        addSetting(&mDebug);
        addSetting(&mShowDistance);
        addSetting(&mGradientHealth);
        addSetting(&mShowBox);
        addSetting(&mGradientBox);
        addSetting(&mArmorBasedColors);

        mNames = {
            {Lowercase, "esp"},
            {LowercaseSpaced, "esp"},
            {Normal, "ESP"},
            {NormalSpaced, "ESP"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(class RenderEvent& event);
};