#pragma once




struct BonePair {
    class Bone* mBone;
    class ActorPartModel* mPartModel;
};

class BoneEsp : public ModuleBase<BoneEsp>
{
public:
    enum class Style {
        Default
    };

    EnumSettingT<Style> mStyle = EnumSettingT<Style>("Стиль", "Стиль ESP.", Style::Default, "Default");
    BoolSetting mRenderLocal = BoolSetting("Локальный игрок", "Рендерить ESP на локальном игроке.", false);
    BoolSetting mShowFriends = BoolSetting("Показывать друзей", "Рендерить ESP на друзьях.", true);
    BoolSetting mDebug = BoolSetting("Отладка", "Отладочная информация", false);

    BoneEsp() : ModuleBase("BoneEsp", "Рисует скелет сущностей", ModuleCategory::Visual, 0, false) {
        addSetting(&mStyle);
        addSetting(&mRenderLocal);
        addSetting(&mShowFriends);
        addSetting(&mDebug);

        mNames = {
            {Lowercase, "boneesp"},
            {LowercaseSpaced, "bone esp"},
            {Normal, "BoneEsp"},
            {NormalSpaced, "Bone Esp"}
        };
    }

    
    std::map<class Actor*, std::vector<BonePair>> mBoneMap;


    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(class RenderEvent& event);
    void onBoneRenderEvent(class BoneRenderEvent& event);
};
