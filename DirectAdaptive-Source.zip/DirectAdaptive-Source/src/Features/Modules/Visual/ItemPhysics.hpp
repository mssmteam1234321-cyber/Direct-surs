
#pragma once

#include <Features/Modules/Module.hpp>

class ItemPhysics : public ModuleBase<ItemPhysics> {
    uint32_t origPosRel = 0;
    float* newPosRel = nullptr;
public:
    std::unordered_map<Actor*, std::tuple<float, glm::vec3, glm::ivec3>> actorData;
    struct ActorRenderData* renderData = nullptr;

    NumberSetting mSpeed = NumberSetting("Скорость", "Скорость вращения", 8.f, 1, 20, 0.01);
    NumberSetting mX = NumberSetting("Множитель X", "Интенсивность вращения по X", 18.f, 7.f, 30.f, 0.01f);
    NumberSetting mY = NumberSetting("Множитель Y", "Интенсивность вращения по Y", 18.f, 7.f, 30.f, 0.01f);
    NumberSetting mZ = NumberSetting("Множитель Z", "Интенсивность вращения по Z", 18.f, 7.f, 30.f, 0.01f);

    ItemPhysics() : ModuleBase("ItemPhysics", "Добавляет физику предметам", ModuleCategory::Visual, 0, false) {
        addSetting(&mSpeed);
        addSetting(&mX);
        addSetting(&mY);
        addSetting(&mZ);
        mNames = {
            {Lowercase, "itemphysics"},
            {LowercaseSpaced, "item physics"},
            {Normal, "ItemPhysics"},
            {NormalSpaced, "Item Physics"}
        };
    }
    static void glm_rotate(glm::mat4x4& mat, float angle, float x, float y, float z);
    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(class RenderEvent& event);
    void onItemRendererEvent(class ItemRendererEvent& event);
};

