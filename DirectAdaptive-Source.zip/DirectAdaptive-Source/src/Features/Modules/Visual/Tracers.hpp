#pragma once




class Tracers : public ModuleBase<Tracers> {
public:
    enum class CenterPoint {
        Top,
        Center,
        Bottom
    };

    EnumSettingT<CenterPoint> mCenterPoint = EnumSettingT<CenterPoint>("Точка центра", "Точка, откуда рисуются линии.", CenterPoint::Center, "Верх", "Центр", "Низ");
    BoolSetting mRenderFilled = BoolSetting("Заливка", "Заливать ESP.", true);
    BoolSetting mRenderLocal = BoolSetting("На себе", "Рисовать линии на локальном игроке.", false);
    BoolSetting mShowFriends = BoolSetting("Показывать друзей", "Рисовать линии на друзьях.", true);

    Tracers() : ModuleBase("Tracers", "Рисует линии до всех сущностей", ModuleCategory::Visual, 0, false) {
        addSetting(&mCenterPoint);
        addSetting(&mRenderFilled);
        addSetting(&mRenderLocal);
        addSetting(&mShowFriends);

        mNames = {
            {Lowercase, "tracers"},
            {LowercaseSpaced, "tracers"},
            {Normal, "Tracers"},
            {NormalSpaced, "Tracers"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(class RenderEvent& event);
};