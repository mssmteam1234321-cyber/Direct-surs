#pragma once

#include <Features/Modules/Module.hpp>

class InventoryTrail : public ModuleBase<InventoryTrail>
{
public:
    InventoryTrail() : ModuleBase("InventoryTrail", "След от мыши в инвентаре", ModuleCategory::Visual, 0, false)
    {
        mNames = {
            {Lowercase, "inventorytrail"},
            {LowercaseSpaced, "inventory trail"},
            {Normal, "InventoryTrail"},
            {NormalSpaced, "Inventory Trail"}
        };

        addSetting(&mGlow);
        addSetting(&mTrailDurationMs);
        addSetting(&mTrailThickness);
        addSetting(&mParticleCount);
        addSetting(&mParticleSize);
        addSetting(&mParticleLifetimeMs);
    }

    void onEnable() override;
    void onDisable() override;

    void onRenderEvent(class RenderEvent& event);
    void onMouseEvent(class MouseEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onPacketOutEvent(class PacketOutEvent& event);

private:
    struct TrailPoint
    {
        ImVec2 pos;
        uint64_t time;
    };

    struct Particle
    {
        ImVec2 startPos;
        ImVec2 velocity;
        uint64_t startTime;
    };

    std::deque<TrailPoint> mTrailPoints;
    std::vector<Particle> mParticles;

    bool mInventoryOpen = false;
    bool mLeftDown = false;

    BoolSetting   mGlow = BoolSetting("Glow", "Draw glow around the trail and particles", true);
    NumberSetting mTrailDurationMs = NumberSetting("Trail Duration", "How long the trail stays (ms)", 1000.f, 100.f, 3000.f, 50.f);
    NumberSetting mTrailThickness = NumberSetting("Trail Thickness", "Thickness of the trail line", 2.0f, 1.0f, 6.0f, 0.25f);
    NumberSetting mParticleCount = NumberSetting("Particle Count", "How many particles to spawn on click", 20.f, 0.f, 80.f, 1.f);
    NumberSetting mParticleSize = NumberSetting("Particle Size", "Size of the click particles", 3.0f, 1.0f, 8.0f, 0.25f);
    NumberSetting mParticleLifetimeMs = NumberSetting("Particle Lifetime", "How long the particles stay (ms)", 600.f, 100.f, 2000.f, 50.f);
};
