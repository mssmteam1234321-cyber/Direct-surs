﻿#include "PearlWay.hpp"

#include <Features/FeatureManager.hpp>
#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Rendering/GuiData.hpp>
#include <SDK/Minecraft/Actor/Actor.hpp>
#include <SDK/Minecraft/Actor/Components/StateVectorComponent.hpp>
#include <Utils/GameUtils/ActorUtils.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>
#include <Utils/MiscUtils/MathUtils.hpp>
#include <Utils/MiscUtils/RenderUtils.hpp>

#include <imgui.h>

#include <algorithm>
#include <cfloat>
#include <unordered_set>
#include <vector>

void PearlWay::onEnable()
{
    mTracks.clear();
    if (gFeatureManager && gFeatureManager->mDispatcher) {
        gFeatureManager->mDispatcher->listen<RenderEvent, &PearlWay::onRenderEvent>(this);
    }
}

void PearlWay::onDisable()
{
    if (gFeatureManager && gFeatureManager->mDispatcher) {
        gFeatureManager->mDispatcher->deafen<RenderEvent, &PearlWay::onRenderEvent>(this);
    }
    mTracks.clear();
}

void PearlWay::onRenderEvent(RenderEvent& event)
{
    updateTracks();
    renderTracks();
}

void PearlWay::updateTracks()
{
    auto player = ClientInstance::get()->getLocalPlayer();
    if (!player) {
        mTracks.clear();
        return;
    }

    std::unordered_set<int64_t> seen;

    auto pearls = ActorUtils::getActorsOfType(ActorType::Enderpearl);
    for (auto actor : pearls) {
        if (!actor) continue;

        int64_t id = actor->getRuntimeID();
        if (id == 0) continue;
        seen.insert(id);

        auto state = actor->getStateVectorComponent();
        glm::vec3 pos;
        glm::vec3 vel(0.0f);

        if (state) {
            pos = state->mPos;
            vel = state->mVelocity;
        } else {
            auto p = actor->getPos();
            auto po = actor->getPosPrev();
            if (!p || !po) continue;
            pos = *p;
            vel = *p - *po;
        }

        auto it = mTracks.find(id);
        if (it == mTracks.end()) {
            PearlTrack track{};
            track.runtimeId = id;
            track.startPos = pos;
            track.lastPos = pos;
            track.initialVelocity = vel;
            mTracks.emplace(id, track);
        } else {
            it->second.lastPos = pos;
    
        }
    }

    for (auto it = mTracks.begin(); it != mTracks.end();) {
        if (!seen.contains(it->first)) it = mTracks.erase(it);
        else ++it;
    }
}

void PearlWay::renderTracks()
{
    auto ci = ClientInstance::get();
    if (!ci) return;
    auto gui = ci->getGuiData();
    if (!gui) return;

    auto player = ci->getLocalPlayer();
    if (!player) return;

    auto& transform = RenderUtils::transform;
    auto& mat = transform.mMatrix;
    glm::vec2 resolution = gui->mResolution;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    if (!dl) return;

    float maxTime = mMaxTime.mValue;
    float density = mDensity.mValue;
    if (maxTime <= 0.0f) return;

    float width = mWidth.mValue;
    float opacity = mOpacity.mValue;

    ImColor theme = ColorUtils::getThemedColor(0);
    ImVec4 base = theme.Value;
    base.w *= opacity;
    ImU32 col = ImColor(base);

    const float ticksPerSecond = 20.0f;
    const float gravityPerTick = 0.03f;
    const float drag = 0.99f; 

    int totalTicks = static_cast<int>(maxTime * ticksPerSecond);
    if (totalTicks <= 1) return;

    int sampleEvery = 1;
    if (density > 0.0f) {
        int targetSamplesPerSecond = static_cast<int>(density);
        if (targetSamplesPerSecond <= 0) targetSamplesPerSecond = 1;
        sampleEvery = std::max(1, static_cast<int>(ticksPerSecond / static_cast<float>(targetSamplesPerSecond)));
    }

    for (auto& [id, track] : mTracks) {
        
        glm::vec3 simPos = track.lastPos;
        glm::vec3 simVel = track.initialVelocity;

        std::vector<ImVec2> screenPoints;
        screenPoints.reserve(static_cast<size_t>(totalTicks / sampleEvery) + 2);

        float sx = 0.0f;
        float sy = 0.0f;

        
        ImVec2 sPos;
        if (RenderUtils::worldToScreen(simPos, sPos)) {
            screenPoints.emplace_back(sPos);
        }

        
        for (int tick = 0; tick < totalTicks; ++tick) {
            
            simVel.y -= gravityPerTick;
            simVel *= drag; 
            simPos += simVel;

            
            if (simPos.y < -64.0f || simPos.y > 320.0f) {
                break;
            }

            
            if (tick % sampleEvery == 0) {
            if (tick % sampleEvery == 0) {
                ImVec2 sPos;
                if (RenderUtils::worldToScreen(simPos, sPos)) {
                    screenPoints.emplace_back(sPos);
                }
            }
            }
        }

        if (screenPoints.size() < 2) continue;

        
        for (size_t i = 1; i < screenPoints.size(); ++i) {
            dl->AddLine(screenPoints[i - 1], screenPoints[i], col, width);
        }
    }
}
