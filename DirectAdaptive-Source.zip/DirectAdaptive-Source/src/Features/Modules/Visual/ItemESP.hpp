﻿#pragma once





class ItemESP : public ModuleBase<ItemESP> {
public:
    BoolSetting mDistanceLimited = BoolSetting("Ограничение дистанции", "Показывать предметы только в радиусе", true);
    NumberSetting mDistance = NumberSetting("Дистанция", "Дистанция отображения", 100.f, 0.f, 100.f, 1.f);
    BoolSetting mRenderFilled = BoolSetting("Заливка", "Заливать боксы", false);
    BoolSetting mThemedColor = BoolSetting("Цвет темы", "Использовать цвет темы", true);
    BoolSetting mShowNames = BoolSetting("Показывать имена", "Показывать названия предметов", true);
    BoolSetting mDistanceScaledFont = BoolSetting("Масштаб шрифта", "Масштабировать шрифт от дистанции", true);
    NumberSetting mFontSize = NumberSetting("Размер шрифта", "Размер текста", 20, 1, 40, 0.01);;
    NumberSetting mScalingMultiplier = NumberSetting("Множитель", "Множитель масштабирования", 1.25f, 0.f, 5.f, 0.01f);
    BoolSetting mHighlightUsefulItems = BoolSetting("Подсветка полезных", "Подсвечивать важные предметы", true);
    BoolSetting mShowEnchant = BoolSetting("Показывать чары", "Показывать зачарования", true);

    ItemESP () : ModuleBase("ItemESP", "Рисует рамку вокруг предметов", ModuleCategory::Visual, 0, false) {
        addSettings(
            &mDistanceLimited,
            &mDistance,
            &mRenderFilled,
            &mThemedColor,
            &mShowNames,
            &mDistanceScaledFont,
            &mFontSize,
            &mScalingMultiplier,
            &mHighlightUsefulItems,
            &mShowEnchant
        );

        VISIBILITY_CONDITION(mDistance, mDistanceLimited.mValue);
        VISIBILITY_CONDITION(mFontSize, mShowNames.mValue);
        VISIBILITY_CONDITION(mDistanceScaledFont, mShowNames.mValue);
        VISIBILITY_CONDITION(mFontSize, mShowNames.mValue && !mDistanceScaledFont.mValue);
        VISIBILITY_CONDITION(mScalingMultiplier, mShowNames.mValue && mDistanceScaledFont.mValue);

        mNames = {
            {Lowercase, "itemesp"},
            {LowercaseSpaced, "item esp"},
            {Normal, "ItemESP"},
            {NormalSpaced, "Item ESP"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onBaseTickEvent(class BaseTickEvent& event);
    void onRenderEvent(class RenderEvent& event);
};