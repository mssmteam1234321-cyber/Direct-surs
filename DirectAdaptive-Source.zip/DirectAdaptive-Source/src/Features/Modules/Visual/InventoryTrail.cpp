#include "InventoryTrail.hpp"

#include <Features/FeatureManager.hpp>
#include <Features/Events/RenderEvent.hpp>
#include <Features/Events/MouseEvent.hpp>
#include <Features/Events/PacketInEvent.hpp>
#include <Features/Events/PacketOutEvent.hpp>

#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Network/Packets/ContainerClosePacket.hpp>

#include <Utils/MiscUtils/ImRenderUtils.hpp>
#include <Utils/MiscUtils/ColorUtils.hpp>
#include <Utils/MiscUtils/MathUtils.hpp>

void InventoryTrail::onEnable()
{
    mTrailPoints.clear();
    mParticles.clear();
    mInventoryOpen = false;
    mLeftDown = false;

    gFeatureManager->mDispatcher->listen<RenderEvent, &InventoryTrail::onRenderEvent>(this);
    gFeatureManager->mDispatcher->listen<MouseEvent, &InventoryTrail::onMouseEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketInEvent, &InventoryTrail::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->listen<PacketOutEvent, &InventoryTrail::onPacketOutEvent>(this);
}

void InventoryTrail::onDisable()
{
    gFeatureManager->mDispatcher->deafen<RenderEvent, &InventoryTrail::onRenderEvent>(this);
    gFeatureManager->mDispatcher->deafen<MouseEvent, &InventoryTrail::onMouseEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketInEvent, &InventoryTrail::onPacketInEvent>(this);
    gFeatureManager->mDispatcher->deafen<PacketOutEvent, &InventoryTrail::onPacketOutEvent>(this);

    mTrailPoints.clear();
    mParticles.clear();
    mInventoryOpen = false;
    mLeftDown = false;
}

void InventoryTrail::onPacketInEvent(PacketInEvent& event)
{
    auto id = event.mPacket->getId();
    if (id == PacketID::ContainerOpen)
    {
        auto packet = event.getPacket<ContainerOpenPacket>();
        if (packet)
        {
            mInventoryOpen = true;
        }
    }
    else if (id == PacketID::ContainerClose)
    {
        mInventoryOpen = false;
        mTrailPoints.clear();
        mParticles.clear();
    }
}

void InventoryTrail::onPacketOutEvent(PacketOutEvent& event)
{
    auto id = event.mPacket->getId();
    if (id == PacketID::ContainerOpen)
    {
        auto packet = event.getPacket<ContainerOpenPacket>();
        if (packet)
        {
            mInventoryOpen = true;
        }
    }
    else if (id == PacketID::ContainerClose)
    {
        mInventoryOpen = false;
        mTrailPoints.clear();
        mParticles.clear();
    }
}

void InventoryTrail::onMouseEvent(MouseEvent& event)
{
    if (!mEnabled) return;
    if (!mInventoryOpen) return;

    auto ci = ClientInstance::get();
    if (!ci) return;
    if (ci->getMouseGrabbed()) return;

    if (event.mActionButtonId != 1) return;

    bool isDown = event.mButtonData != 0;
    if (isDown && !mLeftDown)
    {
        ImVec2 pos(static_cast<float>(event.mX), static_cast<float>(event.mY));

        int count = static_cast<int>(mParticleCount.mValue);
        count = MathUtils::clamp(count, 0, 200);

        for (int i = 0; i < count; ++i)
        {
            float angle = MathUtils::randomFloat(0.0f, 6.2831853f);
            float speed = MathUtils::randomFloat(40.0f, 120.0f);
            ImVec2 vel(std::cos(angle) * speed, std::sin(angle) * speed);

            Particle p;
            p.startPos = pos;
            p.velocity = vel;
            p.startTime = NOW;
            mParticles.push_back(p);
        }
    }

    mLeftDown = isDown;
}

void InventoryTrail::onRenderEvent(RenderEvent& event)
{
    if (!mEnabled) return;

    if (!ImGui::GetCurrentContext()) return;

    auto ci = ClientInstance::get();
    if (!ci) return;

    uint64_t now = NOW;

    if (mInventoryOpen)
    {
        ImVec2 mousePos = ImRenderUtils::getMousePos();

        if (mTrailPoints.empty() ||
            std::abs(mousePos.x - mTrailPoints.back().pos.x) > 1.0f ||
            std::abs(mousePos.y - mTrailPoints.back().pos.y) > 1.0f)
        {
            TrailPoint pt;
            pt.pos = mousePos;
            pt.time = now;
            mTrailPoints.push_back(pt);
        }
    }

    const uint64_t trailDuration = static_cast<uint64_t>(mTrailDurationMs.mValue);
    const uint64_t particleLifetime = static_cast<uint64_t>(mParticleLifetimeMs.mValue);

    while (!mTrailPoints.empty() && now - mTrailPoints.front().time > trailDuration)
    {
        mTrailPoints.pop_front();
    }

    auto it = mParticles.begin();
    while (it != mParticles.end())
    {
        if (now - it->startTime > particleLifetime)
        {
            it = mParticles.erase(it);
        }
        else
        {
            ++it;
        }
    }

    ImDrawList* dl = ImGui::GetForegroundDrawList();
    ImColor theme = ColorUtils::getThemedColor(0);

    float baseThickness = mTrailThickness.mValue;
    baseThickness = MathUtils::clamp(baseThickness, 0.5f, 10.0f);

    if (mTrailPoints.size() >= 2)
    {
        for (size_t i = 0; i + 1 < mTrailPoints.size(); ++i)
        {
            const auto& a = mTrailPoints[i];
            const auto& b = mTrailPoints[i + 1];

            float ageA = static_cast<float>(now - a.time) / static_cast<float>(trailDuration);
            float ageB = static_cast<float>(now - b.time) / static_cast<float>(trailDuration);
            float alpha = 1.0f - (ageA + ageB) * 0.5f;
            alpha = MathUtils::clamp(alpha, 0.0f, 1.0f);

            ImColor col = theme;
            col.Value.w *= alpha;

            if (mGlow.mValue)
            {
                ImColor glowCol = col;
                glowCol.Value.w *= 0.35f;
                dl->AddLine(a.pos, b.pos, glowCol, baseThickness * 2.5f);
            }

            dl->AddLine(a.pos, b.pos, col, baseThickness);
        }
    }

    for (const auto& p : mParticles)
    {
        float age = static_cast<float>(now - p.startTime) / static_cast<float>(particleLifetime);
        age = MathUtils::clamp(age, 0.0f, 1.0f);

        float dt = static_cast<float>(now - p.startTime) / 1000.0f;
        ImVec2 pos(
            p.startPos.x + p.velocity.x * dt * 0.01f,
            p.startPos.y + p.velocity.y * dt * 0.01f
        );

        ImColor col = theme;
        col.Value.w *= (1.0f - age);

        float radius = mParticleSize.mValue;
        radius = MathUtils::clamp(radius, 0.5f, 16.0f);

        if (mGlow.mValue)
        {
            ImColor glowCol = col;
            glowCol.Value.w *= 0.35f;
            dl->AddCircleFilled(pos, radius * 2.0f, glowCol, 20);
        }

        dl->AddCircleFilled(pos, radius, col, 16);
    }
}
