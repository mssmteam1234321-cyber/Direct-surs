#pragma once




#include <Features/Modules/Module.hpp>

#include "HudEditor.hpp"

class Watermark : public ModuleBase<Watermark> {
public:
    enum class Style {
        Solstice,
        SevenDays
    };
    EnumSettingT<Style> mStyle = EnumSettingT<Style>("Стиль", "Стиль вотермарки.", Style::Solstice, "Solstice", "7 Дней");
    BoolSetting mGlow = BoolSetting("Свечение", "Включить свечение", true);
    BoolSetting mBold = BoolSetting("Жирный", "Жирный текст", true);
    Watermark() : ModuleBase("Watermark", "Отображает вотермарку на экране", ModuleCategory::Visual, 0, true) {
        addSetting(&mStyle);
        addSetting(&mGlow);
        
        gFeatureManager->mDispatcher->listen<RenderEvent, &Watermark::onRenderEvent>(this);

        mNames = {
            {Lowercase, "watermark"},
            {LowercaseSpaced, "watermark"},
            {Normal, "Watermark"},
            {NormalSpaced, "Watermark"}
        };

        mElement = std::make_unique<HudElement>();
        mElement->mPos = { 20, 20 };

        const char* ModuleBaseType = ModuleBase<Watermark>::getTypeID();;
        mElement->mParentTypeIdentifier = const_cast<char*>(ModuleBaseType);
        HudEditor::gInstance->registerElement(mElement.get());
    }

    std::unique_ptr<HudElement> mElement;

    void onEnable() override;
    void onDisable() override;

    void onRenderEvent(class RenderEvent& event);

    std::string getSettingDisplay() override {
        return mStyle.mValues[mStyle.as<int>()];
    }
};
