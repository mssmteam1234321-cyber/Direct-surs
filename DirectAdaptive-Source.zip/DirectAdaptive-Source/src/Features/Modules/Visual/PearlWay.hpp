#pragma once

#include <Features/Modules/Module.hpp>
#include <Features/Events/RenderEvent.hpp>

#include <glm/vec3.hpp>
#include <unordered_map>

class PearlWay : public ModuleBase<PearlWay>
{
public:
    struct PearlTrack {
        int64_t runtimeId;
        glm::vec3 startPos;
        glm::vec3 lastPos;
        glm::vec3 initialVelocity;
    };

    NumberSetting mMaxTime = NumberSetting("Max Time", "Max simulated flight time in seconds.", 3.0f, 0.5f, 6.0f, 0.1f);
    NumberSetting mDensity = NumberSetting("Point Density", "Simulation points per second.", 20.0f, 5.0f, 60.0f, 1.0f);
    NumberSetting mWidth = NumberSetting("Path Width", "Width of the path line.", 2.0f, 1.0f, 5.0f, 0.1f);
    NumberSetting mProgressWidth = NumberSetting("Progress Width", "Width of the flown part of the path.", 3.0f, 1.0f, 6.0f, 0.1f);
    NumberSetting mOpacity = NumberSetting("Opacity", "Opacity of the path.", 0.9f, 0.1f, 1.0f, 0.05f);

    PearlWay() : ModuleBase("PearlWay", "Draws path of ender pearls.", ModuleCategory::Visual, 0, false) {
        addSettings(&mMaxTime, &mDensity, &mWidth, &mProgressWidth, &mOpacity);

        mNames = {
            {Lowercase, "pearlway"},
            {LowercaseSpaced, "pearl way"},
            {Normal, "PearlWay"},
            {NormalSpaced, "Pearl Way"}
        };
    }

    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(class RenderEvent& event);

private:
    std::unordered_map<int64_t, PearlTrack> mTracks;

    void updateTracks();
    void renderTracks();
};
