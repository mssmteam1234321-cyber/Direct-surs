#pragma once




#include <Features/Modules/Module.hpp>

class MotionBlur : public ModuleBase<MotionBlur> {
public:
    NumberSetting mMaxFrames = NumberSetting("Макс. кадров", "Максимальное количество кадров для размытия", 1, 1, 20, 1);
    NumberSetting mIntensity = NumberSetting("Интенсивность", "Интенсивность размытия", 0.90f, 0.01f, 1.0f, 0.01f);

    MotionBlur() : ModuleBase<MotionBlur>("MotionBlur", "Добавляет эффект размытия при движении", ModuleCategory::Visual, 0, false) {
        addSetting(&mMaxFrames);
        addSetting(&mIntensity);

        mNames = {
            {Lowercase, "motionblur"},
            {LowercaseSpaced, "motion blur"},
            {Normal, "MotionBlur"},
            {NormalSpaced, "Motion Blur"}
        };
     }

    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(class RenderEvent& event);
};