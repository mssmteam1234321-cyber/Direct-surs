#pragma once

#include "src/Features/Modules/Visual/HudEditor.hpp"
#include "Features/Modules/Module.hpp"
#include <Features/Events/BaseTickEvent.hpp>
#include <Features/Events/PacketInEvent.hpp>
#include <Features/Events/ChatEvent.hpp>
#include <SDK/Minecraft/Network/Packets/MobEffectPacket.hpp>

class HUD : public ModuleBase<HUD> {
public:
    HUD() : ModuleBase("HUD", "Настройка HUD", ModuleCategory::Visual, 0, false) {
        mNames = {
            {Lowercase, "hud"},
            {LowercaseSpaced, "hud"},
            {Normal, "HUD"},
            {NormalSpaced, "HUD"},
        };

        
        initElements();

        
        addSetting(&mPotionsEnabled);
        addSetting(&mLocalPlayersEnabled);
        addSetting(&mStaffListEnabled);

        // Potions Settings
        addSetting(&mPotionsScale);
        addSetting(&mPotionsRounding);
        addSetting(&mPotionsBgAlpha);

        // LocalPlayers Settings
        addSetting(&mLocalPlayersMaxDistance);
        addSetting(&mLocalPlayersShowDistance);
        addSetting(&mLocalPlayersMaxPlayers);
        addSetting(&mLocalPlayersScale);
        addSetting(&mLocalPlayersRounding);
        addSetting(&mLocalPlayersBgAlpha);

        // StaffList Settings
        addSetting(&mStaffListShowDistance);
        addSetting(&mStaffListScale);
        addSetting(&mStaffListRounding);
        addSetting(&mStaffListBgAlpha);
    }

    
    std::unique_ptr<HudElement> mPotionsElement = nullptr;
    std::unique_ptr<HudElement> mLocalPlayersElement = nullptr;
    std::unique_ptr<HudElement> mStaffListElement = nullptr;

    
    BoolSetting mPotionsEnabled = BoolSetting("Зелья", "Отображать активные эффекты зелий", true);
    BoolSetting mLocalPlayersEnabled = BoolSetting("Игроки рядом", "Отображать игроков поблизости", true);
    BoolSetting mStaffListEnabled = BoolSetting("Персонал", "Отображать персонал онлайн", true);

    // Potions Settings
    NumberSetting mPotionsScale = NumberSetting("Размер (Зелья)", "Размер HUD зелий", 1.0f, 0.5f, 2.0f, 0.05f);
    NumberSetting mPotionsRounding = NumberSetting("Закругление (Зелья)", "Закругление углов HUD зелий", 8.0f, 0.0f, 16.0f, 0.5f);
    NumberSetting mPotionsBgAlpha = NumberSetting("Прозрачность (Зелья)", "Прозрачность фона HUD зелий", 200, 0, 255, 1);

    // LocalPlayers Settings
    NumberSetting mLocalPlayersMaxDistance = NumberSetting("Макс. дист. (Игроки)", "Максимальная дистанция", 100.0f, 10.0f, 500.0f, 10.0f);
    BoolSetting   mLocalPlayersShowDistance = BoolSetting("Пок. дист. (Игроки)", "Показывать дистанцию", true);
    NumberSetting mLocalPlayersMaxPlayers = NumberSetting("Макс. игроков", "Максимальное кол-во игроков", 10, 1, 50, 1);
    NumberSetting mLocalPlayersScale = NumberSetting("Размер (Игроки)", "Размер HUD игроков", 1.0f, 0.5f, 2.0f, 0.05f);
    NumberSetting mLocalPlayersRounding = NumberSetting("Закругление (Игроки)", "Закругление углов HUD игроков", 8.0f, 0.0f, 16.0f, 0.5f);
    NumberSetting mLocalPlayersBgAlpha = NumberSetting("Прозрачность (Игроки)", "Прозрачность фона HUD игроков", 200, 0, 255, 1);

    // StaffList Settings
    BoolSetting   mStaffListShowDistance = BoolSetting("Пок. дист. (Персонал)", "Показывать дистанцию", true);
    NumberSetting mStaffListScale = NumberSetting("Размер (Персонал)", "Размер HUD персонала", 1.0f, 0.5f, 2.0f, 0.05f);
    NumberSetting mStaffListRounding = NumberSetting("Закругление (Персонал)", "Закругление углов HUD персонала", 8.0f, 0.0f, 16.0f, 0.5f);
    NumberSetting mStaffListBgAlpha = NumberSetting("Прозрачность (Персонал)", "Прозрачность фона HUD персонала", 200, 0, 255, 1);

    
    void onEnable() override;
    void onDisable() override;
    void onRenderEvent(class RenderEvent& event);
    void onBaseTickEvent(class BaseTickEvent& event);
    void onPacketInEvent(class PacketInEvent& event);
    void onChatEvent(class ChatEvent& event);

private:
    void initElements();

    
    struct ActiveEffect {
        EffectType type;
        int amplifier;
        uint64_t endTime;
        bool infinite;
    };
    std::unordered_map<int, ActiveEffect> mEffects;
    void renderPotions(class RenderEvent& event);

    
    std::vector<std::pair<std::string, float>> mNearbyPlayers;
    void updateNearbyPlayers();
    void renderLocalPlayers(class RenderEvent& event);

    
    struct StaffEntry {
        std::string name;
        std::string prefix;
    };
    std::vector<std::pair<std::string, float>> mOnlineStaff;
    std::vector<StaffEntry> mStaffList;
    void updateOnlineStaff();
    void loadStaffList();
    void saveStaffList();
    void addStaff(const std::string& name, const std::string& prefix);
    void removeStaff(const std::string& name);
    void renderStaffList(class RenderEvent& event);
};
