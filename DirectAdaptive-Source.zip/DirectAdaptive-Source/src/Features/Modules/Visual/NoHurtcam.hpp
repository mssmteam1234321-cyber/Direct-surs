



#pragma once

class NoHurtcam : public ModuleBase<NoHurtcam> {
public:
    NoHurtcam() : ModuleBase<NoHurtcam>("NoHurtcam", "Отключает тряску камеры при получении урона", ModuleCategory::Visual, 0, false) {
        mNames = {
                {Lowercase, "nohurtcam"},
                {LowercaseSpaced, "no hurtcam"},
                {Normal, "NoHurtcam"},
                {NormalSpaced, "No Hurtcam"}
        };
    }

    void onEnable() override;
    void onDisable() override;
};