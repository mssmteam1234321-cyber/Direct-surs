//
// Created by vastrakai on 6/25/2024.
//

#include "Hook.hpp"

#include <Solstice.hpp>

void Hook::init()
{

}
